[CmdletBinding()]
param(
    [string]$PythonVersion = "3.11",
    [string]$Wheelhouse = "wheelhouse\windows-py311"
)
$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

$Python = Get-Command py -ErrorAction SilentlyContinue
if (-not $Python) { throw "Python Launcher (py.exe) not found. Install 64-bit Python 3.11 from python.org and enable the launcher." }
& py -$PythonVersion -c "import sys,struct; print(sys.version); assert struct.calcsize('P') == 8, '64-bit Python is required'"
if ($LASTEXITCODE -ne 0) { throw "Python $PythonVersion x64 is required." }

$Venv = Join-Path $PSScriptRoot ".windows-build-venv"
if (-not (Test-Path (Join-Path $Venv "Scripts\python.exe"))) {
    & py -$PythonVersion -m venv $Venv
    if ($LASTEXITCODE -ne 0) { throw "Could not create the isolated build environment." }
}
$Py = Join-Path $Venv "Scripts\python.exe"
& $Py -m pip install --upgrade "pip<27" "setuptools<82" "wheel<1" "pip-tools==7.5.0"
if ($LASTEXITCODE -ne 0) { throw "Could not prepare pip-tools." }

# Compile on Windows/Python 3.11 so platform markers and wheel tags are correct.
& $Py -m piptools compile --resolver=backtracking --strip-extras --generate-hashes `
    --output-file requirements-windows.lock.txt requirements-windows.in
if ($LASTEXITCODE -ne 0) { throw "Runtime dependency lock generation failed." }
& $Py -m piptools compile --resolver=backtracking --strip-extras --generate-hashes `
    --output-file requirements-build-windows.lock.txt requirements-build-windows.in
if ($LASTEXITCODE -ne 0) { throw "Build dependency lock generation failed." }

New-Item -ItemType Directory -Force -Path $Wheelhouse | Out-Null
& $Py -m pip download --only-binary=:all: --require-hashes `
    --dest $Wheelhouse -r requirements-windows.lock.txt -r requirements-build-windows.lock.txt
if ($LASTEXITCODE -ne 0) { throw "Wheel download failed. No source distributions are allowed in this offline-ready wheelhouse." }

Write-Host "Wheelhouse ready: $Wheelhouse" -ForegroundColor Green
Write-Host "Dependency locks: requirements-windows.lock.txt and requirements-build-windows.lock.txt"
