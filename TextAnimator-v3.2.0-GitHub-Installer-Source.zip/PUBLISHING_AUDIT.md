# TextAnimator v3.0.1 — Publishing audit and repair notes

## Scope

This patch focuses on the desktop publishing GUI and the YouTube/TikTok connection,
upload, and status workflows. The broader adapters remain available, but this audit's
mocked integration coverage is concentrated on YouTube and TikTok.

## Repairs

- Added **Publish → API Credentials…** so users can enter, reveal, save, and clear
  platform developer-app credentials in the GUI. OAuth connection prompts for missing
  credentials rather than silently failing due to absent environment variables.
- Stores developer credentials in the OS keyring when available. If no keyring backend is
  available, uses an owner-only (`0600`) file fallback and warns the user. Legacy
  environment variables remain supported as a fallback.
- YouTube: strengthened Desktop OAuth/PKCE and callback state handling, added metadata
  validation, improved API error classification, and retries chunks within the active
  resumable-upload session.
- TikTok: uses desktop PKCE OAuth and `video.publish`; performs creator-info preflight;
  offers the creator's actual privacy choices and posting disclosure controls; fixes
  chunk sizing; checks asynchronous post status before reporting completion; and avoids
  automatic duplicate uploads when the remote result is ambiguous.
- Queue/UI: distinguishes processing from completed uploads, adds TikTok status checking,
  protects against false cancellation/success states, and corrects Retry Failed selection.

## Verification

- `python -m pytest -q`: **67 passed**.
- `python -m compileall -q text_animator`: passed.
- GUI and platform modules imported successfully in the audit environment.
- Platform network interactions were validated with mocked API responses. No real
  third-party OAuth login or live publish was performed from this environment.

## Required setup before live publishing

- Install publishing dependencies: `pip install 'text-animator[social]'`.
- YouTube: create a Google OAuth client of type **Desktop app**, enable YouTube Data API v3,
  and enter the client ID and client secret in **Publish → API Credentials…**. A plain API
  key is not sufficient to upload to a user's channel.
- TikTok: register a desktop Login Kit app and enable Content Posting API; enter its Client
  Key and Client Secret in **Publish → API Credentials…**. Request `user.info.basic` and
  `video.publish`, and register the loopback callback URI described in the README. TikTok
  may restrict unaudited apps to private-only posting; public posting requires the relevant
  TikTok app review/approval.

The program cannot bypass provider permissions, app review, account restrictions, quota,
moderation, or platform-side processing. Live behavior must be confirmed with the user's
own developer applications and authorized accounts.


## Batch rendering parity — v3.2.0

- Added an independent **Batch → Batch Render Settings** page with the full Single render-control set: preset, color mode, font, font size, word/gap/end timing, resolution, FPS, outline/shadow switches and dimensions, auto-fit, background image, transition and duration, encoding quality, hardware preference, soundtrack volume and fades.
- Batch settings are stored separately under `batch_render_settings` in the user config. They are not read from the Single controls. A one-time copy action and independent reset/save actions are available.
- Batch CSV rows can override each setting with a non-empty column; blank cells inherit the Batch default.
- Fixed Batch soundtrack assignment is independent of the Single soundtrack. Explicit CSV audio wins; `none` forces silence; the Queue & Output no-fallback mode disables both fixed/random fallback.
- Added focused mapping, inheritance, range-clamping, GUI isolation and batch override tests.
- Verification: 86 tests passed; GUI smoke test passed under a virtual X display with the native ttk fallback. The shipping package declares `ttkbootstrap` as a dependency for the intended themed desktop UI.
