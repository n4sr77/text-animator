# Windows package status — TextAnimator 3.2.0

## Packaging target

A single downloadable `TextAnimator-v3.2.0-Setup.exe` installer, not a portable ZIP.

## Verified in the development workspace

- 89 automated tests pass in the prepared development environment.
- Python source and PyInstaller spec parse/compile successfully.
- GUI smoke test opens the application and confirms Batch settings pages.
- Batch settings remain independent of Single settings.
- MoviePy/Pillow compatibility is constrained to avoid the Pillow 12 conflict.

## Native Windows release verification

The workflow must complete on `windows-latest` before the direct installer release is available. It creates a Python 3.11 x64 isolated builder, downloads Windows binary wheels, validates `pip check`, runs pytest, builds and smoke-tests the PyInstaller app, and compiles the Inno Setup installer. The workflow fails rather than publishing if any of these steps fail.

## Installed app persistence

The Inno Setup installer writes the app under `%LOCALAPPDATA%\Programs\TextAnimator`, creates shortcuts, and registers an uninstaller. App settings, publishing credentials and queue files remain in the user's profile/keyring outside the installation directory.

## Hardware encoding

CPU FFmpeg fallback is bundled. NVENC/QSV depends on installed GPU drivers and an appropriate system FFmpeg on PATH, so hardware-specific encoding must be tested on the target laptop.
