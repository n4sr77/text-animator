[CmdletBinding()]
param(
    [string]$InnoSetupCompiler = ""
)
$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

$AppDir = Join-Path $PSScriptRoot "dist\TextAnimator"
$Exe = Join-Path $AppDir "TextAnimator.exe"
$Iss = Join-Path $PSScriptRoot "installer\TextAnimator.iss"
if (-not (Test-Path $Exe)) {
    throw "Missing $Exe. Run build_windows.ps1 before compiling the installer."
}
if (-not (Test-Path $Iss)) {
    throw "Missing Inno Setup definition: $Iss"
}

if (-not $InnoSetupCompiler) {
    $Candidates = @(
        (Join-Path ${env:ProgramFiles(x86)} "Inno Setup 6\ISCC.exe"),
        (Join-Path $env:ProgramFiles "Inno Setup 6\ISCC.exe"),
        (Join-Path $env:LOCALAPPDATA "Programs\Inno Setup 6\ISCC.exe"),
        (Join-Path ${env:ProgramFiles(x86)} "Inno Setup 7\ISCC.exe"),
        (Join-Path $env:ProgramFiles "Inno Setup 7\ISCC.exe")
    )
    $InnoSetupCompiler = $Candidates | Where-Object { $_ -and (Test-Path $_) } | Select-Object -First 1
}
if (-not $InnoSetupCompiler) {
    $Command = Get-Command ISCC.exe -ErrorAction SilentlyContinue
    if ($Command) { $InnoSetupCompiler = $Command.Source }
}
if (-not $InnoSetupCompiler -or -not (Test-Path $InnoSetupCompiler)) {
    throw "Inno Setup compiler not found. Install Inno Setup 6 or 7, or pass -InnoSetupCompiler."
}

$OutputDir = Join-Path $PSScriptRoot "installer-output"
New-Item -ItemType Directory -Force -Path $OutputDir | Out-Null
& $InnoSetupCompiler "/O$OutputDir" $Iss
if ($LASTEXITCODE -ne 0) { throw "Inno Setup compilation failed with exit code $LASTEXITCODE." }

$SetupExe = Join-Path $OutputDir "TextAnimator-v3.2.0-Setup.exe"
if (-not (Test-Path $SetupExe)) { throw "Installer was not produced: $SetupExe" }
$Size = (Get-Item $SetupExe).Length
if ($Size -lt 10MB) { Write-Warning "Installer is smaller than expected ($Size bytes); confirm PyInstaller bundled all runtime dependencies." }
Write-Host "Windows installer ready: $SetupExe" -ForegroundColor Green
