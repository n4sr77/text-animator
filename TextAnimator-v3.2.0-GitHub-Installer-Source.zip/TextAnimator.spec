# PyInstaller spec for a Windows x64 onedir application.
# Build with CPython 3.11 x64 on Windows (see build_windows.ps1).
from pathlib import Path
from PyInstaller.utils.hooks import collect_all, collect_submodules

ROOT = Path(SPECPATH).resolve()
datas = []
binaries = []
hiddenimports = []

# Collect package data and dynamically imported modules required by MoviePy,
# ttkbootstrap theme assets, bundled FFmpeg, Windows keyring and OAuth clients.
for package in (
    "ttkbootstrap",
    "moviepy",
    "imageio_ffmpeg",
    "PIL",
    "numpy",
    "keyring",
    "googleapiclient",
    "google_auth_oauthlib",
    "google_auth_httplib2",
    "google.auth",
    "google.oauth2",
    "tweepy",
    "requests",
    "requests_toolbelt",
):
    package_datas, package_binaries, package_hidden = collect_all(package)
    datas += package_datas
    binaries += package_binaries
    hiddenimports += package_hidden

hiddenimports += [
    "tkinter",
    "tkinter.ttk",
    "tkinter.filedialog",
    "tkinter.messagebox",
    "tkinter.scrolledtext",
    "text_animator",
    "text_animator.presets",
    "text_animator.social.platforms.youtube",
    "text_animator.social.platforms.tiktok",
    "text_animator.social.platforms.instagram",
    "text_animator.social.platforms.facebook",
    "text_animator.social.platforms.x_twitter",
    "text_animator.social.platforms.linkedin",
    "text_animator.social.platforms.threads",
    "text_animator.social.platforms.pinterest",
    "text_animator.social.platforms.vimeo",
    "googleapiclient.discovery",
    "googleapiclient.http",
    "googleapiclient.errors",
    "google_auth_oauthlib.flow",
    "keyring.backends.Windows",
]
hiddenimports += collect_submodules("text_animator.presets")
hiddenimports += collect_submodules("text_animator.social.platforms")

analysis = Analysis(
    [str(ROOT / "main.py")],
    pathex=[str(ROOT)],
    binaries=binaries,
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=["pytest", "pip", "piptools", "IPython", "matplotlib", "scipy"],
    noarchive=False,
    optimize=1,
)
pyz = PYZ(analysis.pure)
exe = EXE(
    pyz,
    analysis.scripts,
    [],
    exclude_binaries=True,
    name="TextAnimator",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
)
collect = COLLECT(
    exe,
    analysis.binaries,
    analysis.datas,
    strip=False,
    upx=False,
    upx_exclude=[],
    name="TextAnimator",
)
