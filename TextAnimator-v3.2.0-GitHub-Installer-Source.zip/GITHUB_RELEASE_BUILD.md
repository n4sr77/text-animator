# GitHub Actions Windows installer release

This source root is intended to be committed to the `main` branch of the GitHub
repository. A push to `main` or a manual `workflow_dispatch` runs
`.github/workflows/build-windows.yml` on a native Windows runner.

The workflow resolves pinned, hash-locked CPython 3.11 x64 wheels, builds in an
isolated environment, runs `pip check` and the regression suite, bundles the app
with PyInstaller, then creates `installer-output/TextAnimator-v3.2.0-Setup.exe`
using Inno Setup. The installer deploys the entire bundled app under the user's
Local AppData Programs directory, creates shortcuts, and provides a standard
uninstaller. User settings and credentials are outside the installation folder
and persist across upgrades.

After a successful workflow, the direct `.exe` is available from both the run's
Artifacts section and the GitHub Releases page. A failed job does not publish a
release asset.

The Windows runner bundles Python and the project dependencies into the install.
The target PC does not need Python or pip. FFmpeg is bundled through
`imageio-ffmpeg`. Optional NVENC/QSV acceleration still requires compatible
Intel/NVIDIA display drivers and an FFmpeg executable with those encoders enabled.
