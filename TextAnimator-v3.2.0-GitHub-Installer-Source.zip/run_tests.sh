#!/bin/bash
# Run all tests with pytest (or fallback to unittest discover)
set -e
cd "$(dirname "$0")"
if command -v pytest &> /dev/null; then
    pytest tests/ -v --tb=short
else
    python -m unittest discover tests/ -v
fi
