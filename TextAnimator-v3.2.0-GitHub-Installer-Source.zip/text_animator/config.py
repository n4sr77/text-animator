"""Global configuration, constants and defaults."""

from __future__ import annotations

import json
from pathlib import Path

# ---------------------------------------------------------------------------
# Resolutions
# ---------------------------------------------------------------------------
RESOLUTIONS = {
    "640x360 (small)": (640, 360),
    "854x480 (480p)": (854, 480),
    "1280x720 (720p)": (1280, 720),
    "1920x1080 (1080p)": (1920, 1080),
    "1080x1080 (square)": (1080, 1080),
    "1080x1920 (vertical)": (1080, 1920),
    "720x1280 (vertical HD)": (720, 1280),
    "1080x1350 (portrait social)": (1080, 1350),
    "1440x2560 (vertical 2K)": (1440, 2560),
    "2160x3840 (vertical 4K)": (2160, 3840),
    "2560x1440 (1440p)": (2560, 1440),
    "3840x2160 (4K UHD)": (3840, 2160),
}

PREVIEW_SIZE = (640, 360)
PREVIEW_FPS = 20

TRANSITIONS = {
    "Smooth fade": "fade",
    "Clean cut": "cut",
    "Zoom through": "zoom",
}

# ---------------------------------------------------------------------------
# Color modes
# ---------------------------------------------------------------------------
COLOR_MODES = {
    "black_on_white": {"text": "black", "bg": (255, 255, 255)},
    "white_on_black": {"text": "white", "bg": (0, 0, 0)},
}

# ---------------------------------------------------------------------------
# Encoding quality presets (MoviePy → libx264)
# ---------------------------------------------------------------------------
ENCODE_PRESETS = {
    "ultrafast": "ultrafast",
    "fast": "fast",
    "medium (balanced)": "medium",
    "slow (better quality)": "slow",
}

# ---------------------------------------------------------------------------
# Defaults
# ---------------------------------------------------------------------------
DEFAULTS = {
    "word_duration": 0.85,
    "gap": 0.08,
    "end_hold": 1.2,
    "font_size": 90,
    "fps": 30,
    "color_mode": "white_on_black",
    "preset": "classic",
    "outline": False,
    "shadow": False,
    "outline_width": 3,
    "shadow_offset": 4,
    "auto_fit_font": True,
    "encode_preset": "medium (balanced)",
    "resolution": "1280x720 (720p)",
    "transition": "fade",
    "transition_duration": 0.25,
    "audio_volume": 0.85,
    "audio_fade_in": 0.15,
    "audio_fade_out": 0.25,
    "text_margin": 20,
    "skip_existing": True,
    "open_folder_when_done": True,
}

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------
PACKAGE_DIR = Path(__file__).resolve().parent
ROOT_DIR = PACKAGE_DIR.parent
USER_CONFIG_PATH = Path.home() / ".textanimator_config.json"

DEFAULT_OUTPUT = str(Path.home() / "Desktop" / "animated_text.mp4")
if not (Path.home() / "Desktop").exists():
    DEFAULT_OUTPUT = str(Path.home() / "animated_text.mp4")

DEFAULT_BATCH_OUT = str(Path.home() / "Desktop" / "TextAnimator_batch")
if not (Path.home() / "Desktop").exists():
    DEFAULT_BATCH_OUT = str(Path.home() / "TextAnimator_batch")


def load_user_config() -> dict:
    """Load persisted user preferences (paths, last used values)."""
    if not USER_CONFIG_PATH.exists():
        return {}
    try:
        with open(USER_CONFIG_PATH, encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def save_user_config(data: dict) -> None:
    """Persist a subset of user preferences."""
    try:
        existing = load_user_config()
        existing.update(data)
        with open(USER_CONFIG_PATH, "w", encoding="utf-8") as f:
            json.dump(existing, f, indent=2)
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Social publishing defaults
# ---------------------------------------------------------------------------
SOCIAL_DEFAULTS = {
    "keyring_service": "text-animator",
    "default_visibility": "private",          # private | unlisted | public
    "auto_conform": False,
    "max_concurrent_uploads": 2,
    "queue_path": str(Path.home() / ".textanimator_queue.json"),
}

SOCIAL_EXTRAS_PACKAGE = "text-animator[social]"
