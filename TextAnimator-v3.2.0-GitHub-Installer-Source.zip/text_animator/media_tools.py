"""Batch image, video and audio conversion / processing powered by Pillow and FFmpeg."""

from __future__ import annotations

import os
import subprocess
import tempfile
import threading
import time
from pathlib import Path

from .audio_library import RandomAudioPool
from .hardware import encoder_plan, encoder_preset, ffmpeg_binary
from typing import Callable

import imageio_ffmpeg
from PIL import Image, ImageEnhance, ImageFilter, ImageOps


IMAGE_EXTS = {
    ".png", ".jpg", ".jpeg", ".webp", ".bmp", ".tif", ".tiff",
    ".gif", ".ico", ".ppm", ".pgm", ".pbm", ".pnm",
}
VIDEO_EXTS = {
    ".mp4", ".m4v", ".mov", ".mkv", ".avi", ".wmv", ".flv",
    ".webm", ".mpeg", ".mpg", ".m2ts", ".mts", ".ts", ".3gp", ".ogv",
}
AUDIO_EXTS = {
    ".mp3", ".wav", ".aac", ".m4a", ".flac", ".ogg", ".opus", ".wma",
    ".aiff", ".aif",
}
SUPPORTED_INPUT_EXTS = IMAGE_EXTS | VIDEO_EXTS | AUDIO_EXTS

OUTPUT_FORMATS = [
    "Keep source", "mp4", "m4v", "mov", "mkv", "avi", "webm", "ogv", "gif",
    "mp3", "wav", "aac", "m4a", "flac", "ogg", "opus", "aiff", "wma",
    "png", "jpg", "webp", "bmp", "tiff",
]

IMAGE_FORMATS = {
    "png": "PNG", "jpg": "JPEG", "jpeg": "JPEG", "webp": "WEBP",
    "bmp": "BMP", "tif": "TIFF", "tiff": "TIFF", "gif": "GIF",
    "ico": "ICO", "ppm": "PPM", "pgm": "PPM", "pbm": "PPM", "pnm": "PPM",
}

FILTERS = ["None", "Grayscale", "Sepia", "Vintage", "Vivid", "Invert", "Blur", "Sharpen", "Emboss", "Edge"]


class MediaCancelled(Exception):
    """Raised when a media-processing queue is cancelled."""


class MediaProcessor:
    """Process a sequence of media files, writing each output atomically."""

    def __init__(self):
        self._cancel = threading.Event()
        self._process: subprocess.Popen | None = None
        self.last_video_encoder_label = "Not processed yet"
        self.last_audio_selections: dict[str, str] = {}

    def cancel(self):
        self._cancel.set()
        process = self._process
        if process and process.poll() is None:
            try:
                process.terminate()
            except OSError:
                pass

    def reset(self):
        self._cancel.clear()

    @staticmethod
    def media_kind(path: str | Path) -> str:
        ext = Path(path).suffix.lower()
        if ext in IMAGE_EXTS:
            return "image"
        if ext in VIDEO_EXTS:
            return "video"
        if ext in AUDIO_EXTS:
            return "audio"
        return "unknown"

    def process_many(
        self,
        files: list[str],
        output_dir: str,
        *,
        output_format: str = "Keep source",
        audio_replace_mode: str = "keep",
        audio_folder: str | None = None,
        replacement_audio_path: str | None = None,
        hardware_backend: str = "auto",
        width: int | None = None,
        height: int | None = None,
        resize_mode: str = "Fit",
        filter_name: str = "None",
        brightness: float = 0.0,
        contrast: float = 0.0,
        saturation: float = 0.0,
        blur: float = 2.0,
        sharpen: float = 1.0,
        rotation: str = "0°",
        fps: int = 30,
        speed: float = 1.0,
        volume: float = 1.0,
        normalize_audio: bool = False,
        quality: int = 20,
        preserve_metadata: bool = True,
        progress_callback: Callable[[int, int, str], None] | None = None,
        item_callback: Callable[[int, str, str], None] | None = None,
    ) -> list[str]:
        if not files:
            raise ValueError("Add at least one media file to the queue.")
        out_dir = Path(output_dir).expanduser()
        out_dir.mkdir(parents=True, exist_ok=True)
        self.reset()
        results: list[str] = []
        errors = 0
        total = len(files)
        reserved: set[str] = set()
        self.last_audio_selections = {}
        audio_replace_mode = (audio_replace_mode or "keep").strip().lower()
        if audio_replace_mode not in {"keep", "random", "fixed"}:
            raise ValueError("Audio replacement mode must be Keep, Random or Fixed.")
        has_video = any(self.media_kind(f) == "video" for f in files)
        random_audio = RandomAudioPool(audio_folder) if audio_replace_mode == "random" and has_video else None
        if audio_replace_mode == "fixed" and has_video:
            if not replacement_audio_path or not Path(replacement_audio_path).is_file():
                raise ValueError("Choose a valid replacement audio file for Fixed mode.")

        for index, source in enumerate(files, 1):
            if self._cancel.is_set():
                raise MediaCancelled("Processing cancelled")
            src = Path(source).expanduser()
            kind = self.media_kind(src)
            label = src.name
            if item_callback:
                item_callback(index, "running", "Processing…")
            if progress_callback:
                progress_callback(index - 1, total, f"Processing {index}/{total}: {label}")
            try:
                target_format = output_format.lower().strip()
                if target_format in ("", "keep source"):
                    target_format = src.suffix.lstrip(".").lower()
                target = self._make_output_path(src, out_dir, target_format, reserved)
                selected_replacement = None
                if kind == "video":
                    if audio_replace_mode == "random":
                        selected_replacement = random_audio.next() if random_audio else None
                    elif audio_replace_mode == "fixed":
                        selected_replacement = replacement_audio_path
                    if selected_replacement:
                        self.last_audio_selections[str(src)] = selected_replacement
                options = {
                    "replacement_audio_path": selected_replacement,
                    "hardware_backend": hardware_backend,
                    "width": width, "height": height, "resize_mode": resize_mode,
                    "filter_name": filter_name, "brightness": brightness,
                    "contrast": contrast, "saturation": saturation, "blur": blur,
                    "sharpen": sharpen, "rotation": rotation, "fps": fps,
                    "speed": speed, "volume": volume,
                    "normalize_audio": normalize_audio, "quality": quality,
                    "preserve_metadata": preserve_metadata,
                }
                self.process_one(str(src), str(target), **options)
                results.append(str(target))
                if item_callback:
                    item_callback(index, "done", str(target))
            except MediaCancelled:
                if item_callback:
                    item_callback(index, "cancelled", "Cancelled")
                raise
            except Exception as exc:
                errors += 1
                if item_callback:
                    item_callback(index, "error", str(exc)[:180])
            if progress_callback:
                progress_callback(index, total, f"Processed {index}/{total}: {label}")

        if errors and not results:
            raise RuntimeError(f"All {errors} queued files failed to process. Check the queue status for details.")
        return results

    @staticmethod
    def _make_output_path(src: Path, out_dir: Path, extension: str, reserved: set[str]) -> Path:
        ext = extension.lower().lstrip(".")
        candidate = out_dir / f"{src.stem}.{ext}"
        n = 2
        while str(candidate.resolve()).lower() in reserved or candidate.exists():
            candidate = out_dir / f"{src.stem}_{n}.{ext}"
            n += 1
        reserved.add(str(candidate.resolve()).lower())
        return candidate

    def process_one(
        self,
        source: str,
        output: str,
        *,
        width: int | None = None,
        height: int | None = None,
        resize_mode: str = "Fit",
        filter_name: str = "None",
        brightness: float = 0.0,
        contrast: float = 0.0,
        saturation: float = 0.0,
        blur: float = 2.0,
        sharpen: float = 1.0,
        rotation: str = "0°",
        fps: int = 30,
        speed: float = 1.0,
        volume: float = 1.0,
        normalize_audio: bool = False,
        quality: int = 20,
        preserve_metadata: bool = True,
        replacement_audio_path: str | None = None,
        hardware_backend: str = "auto",
    ) -> str:
        src, dst = Path(source), Path(output)
        if not src.is_file():
            raise FileNotFoundError(f"Source file not found: {src}")
        if src.resolve() == dst.resolve():
            raise ValueError("Output path cannot overwrite the source file.")
        kind = self.media_kind(src)
        if kind == "unknown":
            raise ValueError(f"Unsupported source format: {src.suffix or '(no extension)'}")
        target_ext = dst.suffix.lower()
        target_kind = self._extension_kind(target_ext)
        if kind == "image" and target_kind not in ("image", "gif"):
            raise ValueError("Image files can be converted to image formats only.")
        if kind == "audio" and target_kind != "audio":
            raise ValueError("Audio files can be converted to audio formats only.")
        if kind == "video" and target_kind not in ("video", "gif"):
            raise ValueError("Video files can be exported as video formats or GIF.")
        if replacement_audio_path:
            replacement_audio_path = str(Path(replacement_audio_path).expanduser())
            if not Path(replacement_audio_path).is_file():
                raise FileNotFoundError(f"Replacement audio file not found: {replacement_audio_path}")
            if target_kind == "gif":
                raise ValueError("GIF output cannot contain audio. Choose an MP4/MOV/MKV output format.")
            if kind != "video":
                raise ValueError("Audio replacement is available for video inputs only.")

        dst.parent.mkdir(parents=True, exist_ok=True)
        temp = dst.with_name(f".{dst.stem}.processing{dst.suffix}")
        try:
            if kind == "image":
                self._process_image(src, temp, width, height, resize_mode, filter_name,
                                    brightness, contrast, saturation, blur, sharpen,
                                    rotation, preserve_metadata)
            else:
                self._process_ffmpeg(src, temp, kind, width, height, resize_mode,
                                     filter_name, brightness, contrast, saturation,
                                     blur, sharpen, rotation, fps, speed, volume,
                                     normalize_audio, quality,
                                     replacement_audio_path=replacement_audio_path,
                                     hardware_backend=hardware_backend)
            if self._cancel.is_set():
                raise MediaCancelled("Processing cancelled")
            os.replace(temp, dst)
            return str(dst)
        finally:
            try:
                if temp.exists():
                    temp.unlink()
            except OSError:
                pass

    @staticmethod
    def _extension_kind(ext: str) -> str:
        ext = ext.lower()
        if ext == ".gif":
            return "gif"
        if ext in {f".{x}" for x in IMAGE_FORMATS}:
            return "image"
        if ext in VIDEO_EXTS or ext in {".mp4", ".mov", ".mkv", ".webm"}:
            return "video"
        if ext in AUDIO_EXTS or ext in {".mp3", ".wav", ".aac", ".flac", ".ogg", ".m4a"}:
            return "audio"
        return "unknown"

    def _process_image(
        self, src: Path, dst: Path, width, height, resize_mode, filter_name,
        brightness, contrast, saturation, blur, sharpen, rotation, preserve_metadata,
    ):
        with Image.open(src) as opened:
            animated = bool(getattr(opened, "is_animated", False)) and opened.format in {"GIF", "WEBP"}
            frames: list[Image.Image] = []
            durations: list[int] = []
            iterator = ImageSequenceIterator(opened) if animated else [opened.copy()]
            for frame in iterator:
                if self._cancel.is_set():
                    raise MediaCancelled("Processing cancelled")
                img = ImageOps.exif_transpose(frame.copy())
                img = self._apply_image_adjustments(
                    img, filter_name, brightness, contrast, saturation, blur, sharpen
                )
                img = self._resize_image(img, width, height, resize_mode)
                img = self._rotate_image(img, rotation)
                frames.append(img)
                durations.append(int(frame.info.get("duration", opened.info.get("duration", 100))))

            if not frames:
                raise ValueError("No image frames found in source.")
            fmt = IMAGE_FORMATS.get(dst.suffix.lower().lstrip("."))
            if not fmt:
                raise ValueError(f"Unsupported image output format: {dst.suffix}")
            save_kwargs = {}
            if preserve_metadata and not animated:
                exif = opened.info.get("exif")
                if exif:
                    save_kwargs["exif"] = exif
            if fmt == "JPEG":
                frames = [self._flatten_alpha(f, (255, 255, 255)) for f in frames]
                save_kwargs.update(quality=94, optimize=True, progressive=True)
            elif fmt == "WEBP":
                save_kwargs.update(quality=92, method=6)
            elif fmt == "PNG":
                save_kwargs.update(optimize=True)

            if animated and fmt in ("GIF", "WEBP"):
                first, rest = frames[0], frames[1:]
                first.save(dst, format=fmt, save_all=True, append_images=rest,
                           duration=durations, loop=opened.info.get("loop", 0),
                           disposal=2 if fmt == "GIF" else 0, **save_kwargs)
            else:
                frames[0].save(dst, format=fmt, **save_kwargs)
            for frame in frames:
                try:
                    frame.close()
                except Exception:
                    pass

    @staticmethod
    def _flatten_alpha(image: Image.Image, background: tuple[int, int, int]) -> Image.Image:
        if image.mode in ("RGBA", "LA") or "transparency" in image.info:
            rgba = image.convert("RGBA")
            base = Image.new("RGBA", rgba.size, background + (255,))
            base.alpha_composite(rgba)
            return base.convert("RGB")
        return image.convert("RGB")

    @staticmethod
    def _apply_image_adjustments(image, filter_name, brightness, contrast, saturation, blur, sharpen):
        name = (filter_name or "None").lower()
        has_alpha = "A" in image.getbands() or "transparency" in image.info
        alpha = image.convert("RGBA").getchannel("A") if has_alpha else None
        image = image.convert("RGB")

        if name == "grayscale":
            image = ImageOps.grayscale(image).convert("RGB")
        elif name == "sepia":
            gray = ImageOps.grayscale(image)
            image = ImageOps.colorize(gray, black="#25170e", white="#f2d6a2").convert("RGB")
        elif name == "invert":
            image = ImageOps.invert(image)
        elif name == "vintage":
            image = ImageEnhance.Color(image).enhance(0.72)
            image = ImageEnhance.Contrast(image).enhance(1.08)
            overlay = Image.new("RGB", image.size, "#d6a66b")
            image = Image.blend(image, overlay, 0.10)
        elif name == "vivid":
            image = ImageEnhance.Color(image).enhance(1.35)
            image = ImageEnhance.Contrast(image).enhance(1.08)
        elif name == "emboss":
            image = image.filter(ImageFilter.EMBOSS)
        elif name == "edge":
            image = image.filter(ImageFilter.FIND_EDGES)

        image = ImageEnhance.Brightness(image).enhance(max(0.0, 1.0 + float(brightness)))
        image = ImageEnhance.Contrast(image).enhance(max(0.0, 1.0 + float(contrast)))
        image = ImageEnhance.Color(image).enhance(max(0.0, 1.0 + float(saturation)))

        radius = float(blur) if float(blur) > 0 else (3.0 if name == "blur" else 0.0)
        if radius > 0:
            image = image.filter(ImageFilter.GaussianBlur(radius=min(radius, 50)))
        amount = max(0.0, float(sharpen)) if float(sharpen) > 0 else (1.5 if name == "sharpen" else 0.0)
        if amount > 0:
            image = ImageEnhance.Sharpness(image).enhance(1.0 + amount)

        if alpha is not None:
            image.putalpha(alpha)
        return image

    @staticmethod
    def _resize_image(image: Image.Image, width, height, mode: str) -> Image.Image:
        if not width or not height or width <= 0 or height <= 0:
            return image
        size = (int(width), int(height))
        if mode.lower() == "stretch":
            return image.resize(size, Image.Resampling.LANCZOS)
        if mode.lower() == "fill":
            return ImageOps.fit(image, size, method=Image.Resampling.LANCZOS, centering=(0.5, 0.5))
        fitted = ImageOps.contain(image, size, method=Image.Resampling.LANCZOS)
        canvas_mode = "RGBA" if "A" in image.getbands() else "RGB"
        bg = (0, 0, 0, 0) if canvas_mode == "RGBA" else (0, 0, 0)
        canvas = Image.new(canvas_mode, size, bg)
        x = (size[0] - fitted.width) // 2
        y = (size[1] - fitted.height) // 2
        if "A" in fitted.getbands():
            canvas.paste(fitted, (x, y), fitted.getchannel("A"))
        else:
            canvas.paste(fitted, (x, y))
        return canvas

    @staticmethod
    def _rotate_image(image: Image.Image, rotation: str) -> Image.Image:
        value = (rotation or "0°").lower()
        if "90" in value:
            return image.transpose(Image.Transpose.ROTATE_90)
        if "180" in value:
            return image.transpose(Image.Transpose.ROTATE_180)
        if "270" in value:
            return image.transpose(Image.Transpose.ROTATE_270)
        if "horizontal" in value:
            return ImageOps.mirror(image)
        if "vertical" in value:
            return ImageOps.flip(image)
        return image

    def _process_ffmpeg(
        self, src, dst, kind, width, height, resize_mode, filter_name,
        brightness, contrast, saturation, blur, sharpen, rotation, fps,
        speed, volume, normalize_audio, quality, *,
        replacement_audio_path: str | None = None,
        hardware_backend: str = "auto",
    ):
        ffmpeg = ffmpeg_binary()
        if not ffmpeg or not Path(ffmpeg).is_file():
            raise RuntimeError("FFmpeg executable is not available. Install FFmpeg or imageio-ffmpeg.")
        ext = dst.suffix.lower().lstrip(".")
        filters: list[str] = []
        if kind == "video":
            filter_map = {
                "grayscale": "hue=s=0",
                "sepia": "colorchannelmixer=.393:.769:.189:0:.349:.686:.168:0:.272:.534:.131",
                "vintage": "eq=saturation=0.72:contrast=1.08:brightness=0.03,colorbalance=rs=0.05:bs=-0.04",
                "vivid": "eq=saturation=1.35:contrast=1.08",
                "invert": "negate",
                "blur": f"gblur=sigma={max(0.1, min(float(blur) if float(blur) > 0 else 3.0, 25))}",
                "sharpen": f"unsharp=5:5:{max(0.1, min(float(sharpen) if float(sharpen) > 0 else 1.5, 5))}:5:5:0",
                "emboss": "convolution='0 -1 0 -1 5 -1 0 -1 0'",
                "edge": "edgedetect=low=0.1:high=0.4",
            }
            selected = filter_map.get((filter_name or "None").lower())
            if selected:
                filters.append(selected)
            if abs(float(brightness)) > 0.0001 or abs(float(contrast)) > 0.0001 or abs(float(saturation)) > 0.0001:
                filters.append(
                    f"eq=brightness={float(brightness):.4f}:contrast={max(0.0, 1.0 + float(contrast)):.4f}:saturation={max(0.0, 1.0 + float(saturation)):.4f}"
                )
            if width and height and width > 0 and height > 0:
                w, h = int(width), int(height)
                if resize_mode.lower() == "stretch":
                    filters.append(f"scale={w}:{h}:flags=lanczos")
                elif resize_mode.lower() == "fill":
                    filters.extend([f"scale={w}:{h}:force_original_aspect_ratio=increase:flags=lanczos", f"crop={w}:{h}"])
                else:
                    filters.extend([f"scale={w}:{h}:force_original_aspect_ratio=decrease:flags=lanczos", f"pad={w}:{h}:(ow-iw)/2:(oh-ih)/2"])
            rot = (rotation or "0°").lower()
            rotation_filters = {
                "90°": "transpose=1", "180°": "hflip,vflip", "270°": "transpose=2",
                "flip horizontal": "hflip", "flip vertical": "vflip",
            }
            if rot in rotation_filters:
                filters.extend(rotation_filters[rot].split(","))
            if float(speed) > 0 and abs(float(speed) - 1.0) > 0.001:
                filters.append(f"setpts=PTS/{max(0.25, min(float(speed), 4.0)):.4f}")
            video_filter = ",".join(filters) if filters else None
        else:
            video_filter = None

        audio_filters = []
        if kind == "audio" or kind == "video":
            audio_filters.append(f"volume={max(0.0, min(float(volume), 4.0)):.4f}")
            if normalize_audio:
                audio_filters.append("loudnorm=I=-16:TP=-1.5:LRA=11")
            if abs(float(speed) - 1.0) > 0.001 and float(speed) > 0:
                audio_filters.append(f"atempo={max(0.5, min(float(speed), 2.0)):.4f}")
        audio_filter = ",".join(audio_filters) if audio_filters else None

        if kind == "video" and ext != "gif" and self._video_codec(ext) == "libx264":
            choices = encoder_plan(hardware_backend, ffmpeg)
        elif kind == "video" and ext != "gif":
            from .hardware import EncoderChoice
            choices = [EncoderChoice("cpu", f"FFmpeg {self._video_codec(ext)}", self._video_codec(ext))]
        else:
            choices = [None]

        errors: list[str] = []
        for choice in choices:
            if self._cancel.is_set():
                raise MediaCancelled("Processing cancelled")
            cmd = [ffmpeg, "-hide_banner", "-loglevel", "error", "-y", "-i", str(src)]
            if replacement_audio_path:
                # Loop the music bed and let -shortest trim it exactly to video duration.
                cmd += ["-stream_loop", "-1", "-i", str(replacement_audio_path)]

            if kind == "video":
                if ext == "gif":
                    vf = video_filter or "null"
                    cmd += ["-filter_complex", f"[0:v]{vf},fps={max(5, min(int(fps), 30))},split[a][b];[a]palettegen[p];[b][p]paletteuse"]
                    cmd += ["-an"]
                else:
                    if video_filter:
                        cmd += ["-vf", video_filter]
                    cmd += ["-map", "0:v:0"]
                    cmd += ["-map", "1:a:0" if replacement_audio_path else "0:a?",]
                    selected_codec = choice.codec if choice else self._video_codec(ext)
                    cmd += ["-c:v", selected_codec]
                    if selected_codec == "h264_nvenc":
                        from .hardware import encoder_preset
                        cmd += ["-preset", encoder_preset(choice, "medium"), "-rc", "vbr",
                                "-cq", str(max(0, min(int(quality), 40))), "-b:v", "0",
                                "-pix_fmt", "yuv420p"]
                    elif selected_codec == "h264_qsv":
                        cmd += ["-preset", encoder_preset(choice, "medium"),
                                "-global_quality", str(max(1, min(int(quality), 40))),
                                "-pix_fmt", "nv12"]
                    elif selected_codec == "libx264":
                        cmd += ["-preset", "medium", "-crf", str(max(0, min(int(quality), 40))),
                                "-pix_fmt", "yuv420p"]
                    elif ext == "webm":
                        cmd += ["-deadline", "good", "-cpu-used", "2", "-crf", str(max(0, min(int(quality), 40))), "-b:v", "0", "-pix_fmt", "yuv420p"]
                    elif ext == "ogv":
                        cmd += ["-q:v", str(max(0, min(int(quality), 10)))]
                    elif ext in {"wmv", "avi", "mpeg", "mpg", "ts", "m2ts", "mts", "3gp"}:
                        cmd += ["-q:v", str(max(2, min(int(quality), 30)))]
                    if ext in {"mp4", "mov", "m4v"}:
                        cmd += ["-movflags", "+faststart"]
                    if audio_filter:
                        cmd += ["-af", audio_filter]
                    if ext in {"mp4", "mov", "m4v", "mkv", "avi", "3gp", "flv", "ts", "m2ts", "mts"}:
                        cmd += ["-c:a", "aac", "-b:a", "192k"]
                    elif ext == "webm":
                        cmd += ["-c:a", "libopus", "-b:a", "160k"]
                    elif ext == "ogv":
                        cmd += ["-c:a", "libvorbis", "-q:a", "5"]
                    elif ext == "wmv":
                        cmd += ["-c:a", "wmav2", "-b:a", "192k"]
                    if replacement_audio_path:
                        cmd += ["-shortest"]
            else:
                if audio_filter:
                    cmd += ["-af", audio_filter]
                codec = {
                    "mp3": ["-c:a", "libmp3lame", "-b:a", "192k"],
                    "wav": ["-c:a", "pcm_s16le"],
                    "aiff": ["-c:a", "pcm_s16be"],
                    "aif": ["-c:a", "pcm_s16be"],
                    "aac": ["-c:a", "aac", "-b:a", "192k"],
                    "m4a": ["-c:a", "aac", "-b:a", "192k"],
                    "flac": ["-c:a", "flac"],
                    "ogg": ["-c:a", "libvorbis", "-q:a", "5"],
                    "opus": ["-c:a", "libopus", "-b:a", "160k"],
                    "wma": ["-ar", "44100", "-c:a", "wmav2", "-b:a", "192k"],
                }.get(ext)
                if not codec:
                    raise ValueError(f"Unsupported audio output format: .{ext}")
                cmd += codec
            cmd.append(str(dst))

            stderr_file = tempfile.TemporaryFile()
            process = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=stderr_file)
            self._process = process
            try:
                while process.poll() is None:
                    if self._cancel.is_set():
                        process.terminate()
                        try:
                            process.wait(timeout=3)
                        except subprocess.TimeoutExpired:
                            process.kill()
                        raise MediaCancelled("Processing cancelled")
                    time.sleep(0.12)
                if self._cancel.is_set():
                    raise MediaCancelled("Processing cancelled")
                if process.returncode == 0:
                    if kind == "video" and choice:
                        self.last_video_encoder_label = choice.label
                    return
                stderr_file.seek(0)
                details = stderr_file.read().decode("utf-8", errors="replace").strip()
                errors.append(f"{choice.label if choice else 'FFmpeg'}: {details[-800:] or process.returncode}")
            except MediaCancelled:
                raise
            finally:
                self._process = None
                stderr_file.close()

        raise RuntimeError("FFmpeg processing failed.\n" + "\n".join(errors[-3:]))

    @staticmethod
    def _video_codec(ext: str) -> str:
        if ext == "webm":
            return "libvpx-vp9"
        if ext == "ogv":
            return "libtheora"
        if ext == "wmv":
            return "msmpeg4v3"
        if ext in {"mpeg", "mpg", "ts", "m2ts", "mts"}:
            return "mpeg2video"
        if ext == "avi":
            return "mpeg4"
        if ext == "3gp":
            return "h263"
        return "libx264"


class ImageSequenceIterator:
    """Small iterator preserving frame duration metadata for animated images."""

    def __init__(self, image: Image.Image):
        self.image = image
        self.count = int(getattr(image, "n_frames", 1))
        self.index = 0

    def __iter__(self):
        return self

    def __next__(self):
        if self.index >= self.count:
            raise StopIteration
        self.image.seek(self.index)
        self.index += 1
        return self.image.copy()
