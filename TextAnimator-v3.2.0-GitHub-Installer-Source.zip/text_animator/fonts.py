"""Font discovery and curated list of good kinetic-typography fonts."""

from __future__ import annotations

import os
from pathlib import Path
from functools import lru_cache

# Curated display / bold fonts that look great for kinetic text.
# Format: display_name → absolute path
CURATED_FONTS: dict[str, str] = {}

# Common system locations to search
_SEARCH_ROOTS = [
    Path("/usr/share/fonts"),
    Path("/usr/local/share/fonts"),
    Path.home() / ".fonts",
    Path.home() / ".local/share/fonts",
]

# Preferred bold / display families (case-insensitive match on folder or filename)
_PREFERRED = [
    "DejaVuSans-Bold",
    "LiberationSans-Bold",
    "Anton",
    "Oswald",
    "Montserrat",
    "Bebas",
    "Impact",
    "Archivo Black",
    "Alfa Slab One",
    "Playfair Display",
    "Abril Fatface",
    "Bangers",
    "Fredoka",
    "Righteous",
    "Russo One",
    "Teko",
    "Barlow Condensed",
    "Roboto Condensed",
    "Noto Sans",
    "Open Sans",
    "Poppins",
    "Inter",
    "Source Sans",
    "Merriweather",
    "Lora",
    # Added fonts for expanded selection
    "Lexend",
    "Cabin",
    "Nunito",
    "Quicksand",
    "Raleway",
    "Zilla Slab",
    "Comfortaa",
    "Josefin Sans",
]


def _score_font(path: Path) -> int:
    """Higher score = better for kinetic titles."""
    name = path.name.lower()
    score = 0
    if "bold" in name or "black" in name or "heavy" in name:
        score += 30
    if "italic" in name or "oblique" in name:
        score -= 15
    if "condensed" in name or "narrow" in name:
        score += 10
    if "regular" in name or "medium" in name:
        score += 5
    # Prefer known good families
    for pref in _PREFERRED:
        if pref.lower().replace(" ", "") in name.replace(" ", "").replace("-", ""):
            score += 40
            break
    return score


@lru_cache(maxsize=1)
def discover_fonts() -> dict[str, str]:
    """
    Scan system for TTF/OTF fonts and return a curated mapping
    display_name → full_path.
    """
    found: dict[str, tuple[int, str]] = {}  # name → (score, path)

    for root in _SEARCH_ROOTS:
        if not root.exists():
            continue
        for p in root.rglob("*"):
            if p.suffix.lower() not in {".ttf", ".otf"}:
                continue
            if not p.is_file():
                continue
            score = _score_font(p)
            if score < 20:  # skip weak candidates
                continue
            # Nice display name
            display = p.stem.replace("-", " ").replace("_", " ")
            # Prefer higher score, keep first if equal
            if display not in found or score > found[display][0]:
                found[display] = (score, str(p))

    # Sort by score descending, then name
    sorted_items = sorted(found.items(), key=lambda x: (-x[1][0], x[0]))
    result = {name: path for name, (_, path) in sorted_items}

    # Always guarantee at least DejaVu / Liberation
    fallbacks = [
        ("DejaVu Sans Bold", "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"),
        ("Liberation Sans Bold", "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf"),
        ("DejaVu Serif Bold", "/usr/share/fonts/truetype/dejavu/DejaVuSerif-Bold.ttf"),
    ]
    for name, path in fallbacks:
        if name not in result and os.path.exists(path):
            result[name] = path

    return result


def get_default_font() -> tuple[str, str]:
    """Return (display_name, path) of the best default font."""
    fonts = discover_fonts()
    for preferred in ["DejaVu Sans Bold", "Liberation Sans Bold", "Anton", "Oswald"]:
        if preferred in fonts:
            return preferred, fonts[preferred]
    # first available
    if fonts:
        name = next(iter(fonts))
        return name, fonts[name]
    raise RuntimeError("No usable fonts found on this system")


def list_font_names() -> list[str]:
    return list(discover_fonts().keys())


def resolve_font(name_or_path: str) -> str:
    """Accept either a display name or a direct path and return a valid path."""
    if os.path.isfile(name_or_path):
        return name_or_path
    fonts = discover_fonts()
    if name_or_path in fonts:
        return fonts[name_or_path]
    # fuzzy
    lower = name_or_path.lower()
    for n, p in fonts.items():
        if lower in n.lower():
            return p
    # last resort
    _, path = get_default_font()
    return path
