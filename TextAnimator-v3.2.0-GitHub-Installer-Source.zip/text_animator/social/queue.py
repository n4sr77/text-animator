"""Upload queue with per-platform worker pools, exponential backoff,
circuit breaker, and proactive token refresh.

Design
------
- Each platform gets its own worker pool sized by adapter.max_concurrent().
- Workers pick jobs off a shared platform-keyed queue.
- Transient errors are retried with jitter backoff (max 5 attempts).
- RateLimitError honours Retry-After.
- N consecutive AuthErrors trip a circuit breaker → account flagged needs_reauth.
- Progress and status are reported via callbacks matching BatchRenderer style.
"""

from __future__ import annotations

import queue
import random
import threading
import time
import uuid
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Callable, Optional

from .base import UploadRequest, UploadResult, TokenBundle
from .credentials import TokenStore
from .errors import AuthError, RateLimitError, TransientError, UploadError, SocialError
from .registry import load_adapter
from ..log_setup import get_logger

log = get_logger(__name__)

_MAX_ATTEMPTS = 5
_BASE_DELAY = 2.0        # seconds
_MAX_DELAY = 300.0       # 5 minutes
_CB_THRESHOLD = 3        # consecutive auth failures → needs_reauth


class JobStatus(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    DONE = "done"
    ERROR = "error"
    CANCELLED = "cancelled"
    PROCESSING = "processing"
    REAUTH = "needs_reauth"


@dataclass
class QueueJob:
    """A single upload job managed by UploadQueue."""

    job_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    request: UploadRequest = field(default_factory=lambda: UploadRequest(
        file_path="", platform="", account_id=""))
    status: JobStatus = JobStatus.PENDING
    result: Optional[UploadResult] = None
    error: str = ""
    attempt: int = 0
    cancel_flag: threading.Event = field(default_factory=threading.Event)


StatusCallback = Callable[[str, str, str], None]   # job_id, status, message
ProgressCallback = Callable[[int, int, str], None]  # current, total, message


class UploadQueue:
    """
    Multi-platform upload queue.

    Usage::

        q = UploadQueue()
        job_id = q.enqueue(request)
        q.start()          # starts worker threads
        # …
        q.cancel(job_id)
        q.cancel_all()
        results = q.results()
    """

    def __init__(
        self,
        status_callback: StatusCallback | None = None,
        progress_callback: ProgressCallback | None = None,
    ) -> None:
        self._jobs: dict[str, QueueJob] = {}
        self._jobs_lock = threading.Lock()

        # platform → queue.Queue of job_id strings
        self._platform_queues: dict[str, queue.Queue] = {}
        self._workers: list[threading.Thread] = []
        self._status_cb = status_callback
        self._progress_cb = progress_callback
        self._store = TokenStore()

        # Circuit-breaker: platform:account_id → consecutive auth failure count
        self._auth_failures: dict[str, int] = {}
        self._af_lock = threading.Lock()

        self._running = False

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def enqueue(self, request: UploadRequest) -> str:
        """Add an upload job and return its job_id."""
        job = QueueJob(request=request)
        with self._jobs_lock:
            self._jobs[job.job_id] = job

        platform = request.platform
        if platform not in self._platform_queues:
            self._platform_queues[platform] = queue.Queue()
        self._platform_queues[platform].put(job.job_id)

        self._emit_status(job.job_id, JobStatus.PENDING, "Queued")
        log.info("Enqueued job %s → %s", job.job_id[:8], platform)
        return job.job_id

    def start(self) -> None:
        """Spin up worker threads (call once after all jobs are enqueued)."""
        if self._running:
            return
        self._running = True
        for platform, pq in self._platform_queues.items():
            try:
                adapter = load_adapter(platform)
                concurrency = adapter.max_concurrent()
            except Exception:
                concurrency = 1
            for _ in range(concurrency):
                t = threading.Thread(
                    target=self._worker, args=(platform, pq), daemon=True)
                t.start()
                self._workers.append(t)
        log.info("UploadQueue started with %d worker(s)", len(self._workers))

    def cancel(self, job_id: str) -> None:
        with self._jobs_lock:
            job = self._jobs.get(job_id)
        if job:
            job.cancel_flag.set()
            log.info("Cancel requested for job %s", job_id[:8])

    def cancel_all(self) -> None:
        with self._jobs_lock:
            jobs = list(self._jobs.values())
        for job in jobs:
            job.cancel_flag.set()
        log.info("All uploads cancelled")

    def results(self) -> list[QueueJob]:
        with self._jobs_lock:
            return list(self._jobs.values())

    def wait(self, timeout: float | None = None) -> None:
        """Block until all queues are drained or timeout expires."""
        for pq in self._platform_queues.values():
            pq.join() if timeout is None else None
            # For timeout, just sleep and poll
        if timeout is not None:
            deadline = time.monotonic() + timeout
            while time.monotonic() < deadline:
                if all(pq.empty() for pq in self._platform_queues.values()):
                    break
                time.sleep(0.2)

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _worker(self, platform: str, pq: "queue.Queue[str]") -> None:
        while self._running:
            try:
                job_id = pq.get(timeout=1.0)
            except queue.Empty:
                continue
            try:
                self._process_job(job_id)
            finally:
                pq.task_done()

    def _process_job(self, job_id: str) -> None:
        with self._jobs_lock:
            job = self._jobs.get(job_id)
        if job is None:
            return

        if job.cancel_flag.is_set():
            self._finish_job(job, JobStatus.CANCELLED, "Cancelled before start")
            return

        cb_key = f"{job.request.platform}:{job.request.account_id}"

        for attempt in range(1, _MAX_ATTEMPTS + 1):
            if job.cancel_flag.is_set():
                self._finish_job(job, JobStatus.CANCELLED, "Cancelled")
                return

            job.attempt = attempt
            self._emit_status(job.job_id, JobStatus.RUNNING,
                               f"Attempt {attempt}/{_MAX_ATTEMPTS}")

            try:
                # Proactive token refresh
                bundle = self._refreshed_bundle(job.request)

                adapter = load_adapter(job.request.platform)
                result = adapter.upload(
                    job.request,
                    bundle,
                    progress_callback=self._progress_cb,
                    cancel_flag=job.cancel_flag,
                )

                if not result.success:
                    if result.status == "processing":
                        # The platform accepted the transfer but is still
                        # processing/moderating it. Do not mark it complete or
                        # automatically retry and risk creating duplicates.
                        self._finish_job(job, JobStatus.PROCESSING,
                                         result.error or "Platform processing is pending",
                                         result=result)
                        return
                    if job.cancel_flag.is_set() or result.status == "cancelled" or result.error.lower().startswith("cancelled"):
                        self._finish_job(job, JobStatus.CANCELLED, result.error or "Cancelled",
                                         result=result)
                        return
                    self._finish_job(job, JobStatus.ERROR,
                                     result.error or "Platform reported an unsuccessful upload",
                                     result=result)
                    return

                # Reset circuit breaker only after a confirmed platform success.
                with self._af_lock:
                    self._auth_failures.pop(cb_key, None)

                self._finish_job(job, JobStatus.DONE, result.post_url or "Published",
                                 result=result)
                return

            except AuthError as exc:
                with self._af_lock:
                    self._auth_failures[cb_key] = self._auth_failures.get(cb_key, 0) + 1
                    trips = self._auth_failures[cb_key]
                if trips >= _CB_THRESHOLD:
                    log.warning("Circuit breaker tripped for %s — needs_reauth", cb_key)
                    self._finish_job(job, JobStatus.REAUTH,
                                     f"Re-auth required: {exc}")
                    return
                self._finish_job(job, JobStatus.ERROR, str(exc))
                return

            except RateLimitError as exc:
                delay = exc.retry_after or _backoff(attempt)
                log.info("Rate limited on %s, waiting %.0fs", job.request.platform, delay)
                self._emit_status(job.job_id, JobStatus.RUNNING,
                                  f"Rate limited — retrying in {delay:.0f}s")
                self._interruptible_sleep(delay, job.cancel_flag)

            except TransientError as exc:
                delay = exc.retry_after or _backoff(attempt)
                log.info("Transient error on attempt %d: %s — wait %.0fs",
                         attempt, exc, delay)
                self._emit_status(job.job_id, JobStatus.RUNNING,
                                  f"Transient error, retry {attempt}/{_MAX_ATTEMPTS} in {delay:.0f}s")
                self._interruptible_sleep(delay, job.cancel_flag)

            except (UploadError, Exception) as exc:
                log.error("Non-transient error on job %s: %s", job_id[:8], exc)
                self._finish_job(job, JobStatus.ERROR, str(exc))
                return

        self._finish_job(job, JobStatus.ERROR,
                         f"Failed after {_MAX_ATTEMPTS} attempts")

    def _refreshed_bundle(self, request: UploadRequest) -> TokenBundle:
        bundle = self._store.load(request.platform, request.account_id)
        if bundle is None:
            raise AuthError(
                f"No token found for {request.platform}/{request.account_id}",
                platform=request.platform,
            )
        if bundle.is_expired():
            log.info("Proactively refreshing token for %s/%s",
                     request.platform, request.account_id)
            adapter = load_adapter(request.platform)
            bundle = adapter.refresh_token(bundle)
            self._store.save(bundle)
        return bundle

    def _finish_job(
        self,
        job: QueueJob,
        status: JobStatus,
        message: str,
        result: UploadResult | None = None,
    ) -> None:
        job.status = status
        job.result = result
        job.error = "" if status == JobStatus.DONE else message
        self._emit_status(job.job_id, status, message)
        log.info("Job %s → %s: %s", job.job_id[:8], status.value, message[:80])

    def _emit_status(self, job_id: str, status: JobStatus, message: str) -> None:
        if self._status_cb:
            try:
                self._status_cb(job_id, status.value, message)
            except Exception:
                pass

    @staticmethod
    def _interruptible_sleep(seconds: float, cancel_flag: threading.Event) -> None:
        deadline = time.monotonic() + seconds
        while time.monotonic() < deadline:
            if cancel_flag.is_set():
                return
            time.sleep(min(0.5, deadline - time.monotonic()))


def _backoff(attempt: int) -> float:
    """Exponential backoff with ±25% jitter."""
    delay = min(_BASE_DELAY * (2 ** (attempt - 1)), _MAX_DELAY)
    jitter = delay * 0.25 * (random.random() * 2 - 1)
    return max(1.0, delay + jitter)
