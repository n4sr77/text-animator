"""Social publishing package for TextAnimator.

Lazy-import design: importing ``text_animator.social`` never pulls in
platform-specific heavy deps (google-api-python-client, tweepy, …).
Those are imported only inside their respective ``platforms/`` modules.

Tkinter is never imported here.
"""

from __future__ import annotations

from .errors import (
    AuthError,
    RateLimitError,
    ValidationError,
    UploadError,
    TransientError,
    SocialError,
)
from .base import (
    MediaSpec,
    UploadRequest,
    UploadResult,
    AccountInfo,
    TokenBundle,
    SocialAdapter,
)

__all__ = [
    "AuthError",
    "RateLimitError",
    "ValidationError",
    "UploadError",
    "TransientError",
    "SocialError",
    "MediaSpec",
    "UploadRequest",
    "UploadResult",
    "AccountInfo",
    "TokenBundle",
    "SocialAdapter",
]
