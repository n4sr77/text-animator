"""Secure token storage backed by OS keyring with plaintext fallback.

Keyring (OS secret store) is used when available.  If the user has
no keyring daemon (CI, headless servers), we fall back to a JSON file
at ``~/.textanimator/credentials.json`` with 0600 permissions, but we
warn the user exactly once per session and log a prominent message.

TokenBundle.__repr__ redacts secrets — safe to log.
"""

from __future__ import annotations

import json
import os
import stat
import time
import warnings
from pathlib import Path
from typing import Optional

from .base import TokenBundle
from ..log_setup import get_logger

log = get_logger(__name__)

_CRED_DIR = Path.home() / ".textanimator"
_CRED_FILE = _CRED_DIR / "credentials.json"
_KEYRING_SERVICE = "text-animator"
_CLIENT_CONFIG_SERVICE = "text-animator-client-config"
_CLIENT_CONFIG_FILE = _CRED_DIR / "client_credentials.json"
_ACCOUNT_INDEX_FILE = _CRED_DIR / "connected_accounts.json"
_WARNED_FALLBACK = False

# Fields requested by the GUI and passed to each platform adapter.  Environment
# variables remain supported for existing installations, but are no longer
# required because the desktop app can save these values itself.
PLATFORM_CREDENTIAL_FIELDS = {
    "youtube": [
        {"key": "client_id", "label": "OAuth Client ID", "env": "YT_CLIENT_ID", "secret": False, "required": True},
        {"key": "client_secret", "label": "OAuth Client Secret", "env": "YT_CLIENT_SECRET", "secret": True, "required": True},
    ],
    "tiktok": [
        {"key": "client_key", "label": "TikTok Client Key", "env": "TIKTOK_CLIENT_KEY", "secret": False, "required": True},
        {"key": "client_secret", "label": "TikTok Client Secret", "env": "TIKTOK_CLIENT_SECRET", "secret": True, "required": True},
    ],
    "instagram": [
        {"key": "app_id", "label": "App ID", "env": "IG_APP_ID", "secret": False, "required": True},
        {"key": "app_secret", "label": "App Secret", "env": "IG_APP_SECRET", "secret": True, "required": True},
    ],
    "facebook": [
        {"key": "app_id", "label": "App ID", "env": "FB_APP_ID", "secret": False, "required": True},
        {"key": "app_secret", "label": "App Secret", "env": "FB_APP_SECRET", "secret": True, "required": True},
    ],
    "x_twitter": [
        {"key": "api_key", "label": "API Key", "env": "TWITTER_API_KEY", "secret": False, "required": True},
        {"key": "api_secret", "label": "API Key Secret", "env": "TWITTER_API_SECRET", "secret": True, "required": True},
        {"key": "client_id", "label": "OAuth 2.0 Client ID", "env": "TWITTER_CLIENT_ID", "secret": False, "required": True},
        {"key": "client_secret", "label": "OAuth 2.0 Client Secret", "env": "TWITTER_CLIENT_SECRET", "secret": True, "required": True},
    ],
    "linkedin": [
        {"key": "client_id", "label": "Client ID", "env": "LI_CLIENT_ID", "secret": False, "required": True},
        {"key": "client_secret", "label": "Client Secret", "env": "LI_CLIENT_SECRET", "secret": True, "required": True},
    ],
    "threads": [
        {"key": "app_id", "label": "App ID", "env": "THREADS_APP_ID", "secret": False, "required": True},
        {"key": "app_secret", "label": "App Secret", "env": "THREADS_APP_SECRET", "secret": True, "required": True},
    ],
    "pinterest": [
        {"key": "app_id", "label": "App ID", "env": "PINTEREST_APP_ID", "secret": False, "required": True},
        {"key": "app_secret", "label": "App Secret", "env": "PINTEREST_APP_SECRET", "secret": True, "required": True},
    ],
    "vimeo": [
        {"key": "client_id", "label": "Client ID", "env": "VIMEO_CLIENT_ID", "secret": False, "required": False},
        {"key": "client_secret", "label": "Client Secret", "env": "VIMEO_CLIENT_SECRET", "secret": True, "required": False},
        {"key": "access_token", "label": "Personal Access Token (optional)", "env": "VIMEO_ACCESS_TOKEN", "secret": True, "required": False},
    ],
}


def _keyring_available() -> bool:
    try:
        import keyring  # noqa: F401
        return True
    except ImportError:
        return False


def _keyring_set(key: str, value: str) -> None:
    import keyring
    keyring.set_password(_KEYRING_SERVICE, key, value)


def _keyring_get(key: str) -> Optional[str]:
    import keyring
    return keyring.get_password(_KEYRING_SERVICE, key)


def _keyring_delete(key: str) -> None:
    try:
        import keyring
        keyring.delete_password(_KEYRING_SERVICE, key)
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Plaintext fallback helpers
# ---------------------------------------------------------------------------

def _plaintext_load() -> dict:
    if not _CRED_FILE.exists():
        return {}
    try:
        with open(_CRED_FILE, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def _plaintext_save(data: dict) -> None:
    global _WARNED_FALLBACK
    _CRED_DIR.mkdir(parents=True, exist_ok=True)
    with open(_CRED_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
    # Restrict to owner read/write only (0600)
    try:
        os.chmod(_CRED_FILE, stat.S_IRUSR | stat.S_IWUSR)
    except Exception:
        pass
    if not _WARNED_FALLBACK:
        _WARNED_FALLBACK = True
        msg = (
            f"[TextAnimator] OS keyring unavailable — tokens stored in plaintext at "
            f"{_CRED_FILE} (0600).  Install 'keyring' package for secure storage."
        )
        warnings.warn(msg, stacklevel=4)
        log.warning(msg)


def _cred_key(platform: str, account_id: str) -> str:
    return f"{platform}::{account_id}"


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def _account_index_load() -> set[tuple[str, str]]:
    try:
        with open(_ACCOUNT_INDEX_FILE, encoding="utf-8") as handle:
            data = json.load(handle)
        return {(str(item[0]), str(item[1])) for item in data
                if isinstance(item, (list, tuple)) and len(item) == 2}
    except (OSError, ValueError, TypeError):
        return set()


def _account_index_save(accounts: set[tuple[str, str]]) -> None:
    _CRED_DIR.mkdir(parents=True, exist_ok=True)
    tmp_path = _ACCOUNT_INDEX_FILE.with_suffix(".tmp")
    with open(tmp_path, "w", encoding="utf-8") as handle:
        json.dump(sorted([list(item) for item in accounts]), handle, indent=2)
    try:
        os.chmod(tmp_path, stat.S_IRUSR | stat.S_IWUSR)
    except Exception:
        pass
    os.replace(tmp_path, _ACCOUNT_INDEX_FILE)
    try:
        os.chmod(_ACCOUNT_INDEX_FILE, stat.S_IRUSR | stat.S_IWUSR)
    except Exception:
        pass


class TokenStore:
    """
    Persist and retrieve TokenBundles.

    Uses OS keyring when available; falls back to a 0600 JSON file.
    """

    def save(self, bundle: TokenBundle) -> None:
        key = _cred_key(bundle.platform, bundle.account_id)
        payload = json.dumps({
            "platform": bundle.platform,
            "account_id": bundle.account_id,
            "access_token": bundle.access_token,
            "refresh_token": bundle.refresh_token,
            "expires_at": bundle.expires_at,
            "id_token": bundle.id_token,
            "extra": bundle.extra,
        })
        if _keyring_available():
            try:
                _keyring_set(key, payload)
                accounts = _account_index_load()
                accounts.add((bundle.platform, bundle.account_id))
                _account_index_save(accounts)
                log.debug("Token saved to keyring: %s", repr(bundle))
                return
            except Exception as exc:
                log.warning("keyring write failed (%s); falling back to plaintext", exc)

        # Fallback
        data = _plaintext_load()
        data[key] = payload
        _plaintext_save(data)
        accounts = _account_index_load()
        accounts.add((bundle.platform, bundle.account_id))
        _account_index_save(accounts)
        log.debug("Token saved to plaintext fallback: %s", repr(bundle))

    def load(self, platform: str, account_id: str) -> Optional[TokenBundle]:
        key = _cred_key(platform, account_id)
        raw: Optional[str] = None

        if _keyring_available():
            try:
                raw = _keyring_get(key)
            except Exception as exc:
                log.warning("keyring read failed (%s)", exc)

        if raw is None:
            data = _plaintext_load()
            raw = data.get(key)

        if not raw:
            return None

        try:
            d = json.loads(raw)
            return TokenBundle(
                platform=d["platform"],
                account_id=d["account_id"],
                access_token=d["access_token"],
                refresh_token=d.get("refresh_token", ""),
                expires_at=d.get("expires_at", 0.0),
                id_token=d.get("id_token", ""),
                extra=d.get("extra", {}),
            )
        except Exception as exc:
            log.error("Failed to deserialise token for %s/%s: %s", platform, account_id, exc)
            return None

    def delete(self, platform: str, account_id: str) -> None:
        key = _cred_key(platform, account_id)
        if _keyring_available():
            _keyring_delete(key)
        data = _plaintext_load()
        if key in data:
            del data[key]
            _plaintext_save(data)
        accounts = _account_index_load()
        accounts.discard((platform, account_id))
        # Retain the index entry only if a keyring copy still exists.
        if _keyring_available():
            try:
                if _keyring_get(key):
                    accounts.add((platform, account_id))
            except Exception:
                pass
        _account_index_save(accounts)
        log.info("Token deleted for %s/%s", platform, account_id)

    def list_accounts(self) -> list[tuple[str, str]]:
        """Return all known accounts, including those stored only in keyring.

        OS keyrings generally do not support portable enumeration, so every
        save maintains a small non-secret index file alongside the token store.
        """
        accounts = _account_index_load()
        data = _plaintext_load()
        for key in data:
            if "::" in key:
                p, a = key.split("::", 1)
                accounts.add((p, a))
        return sorted(accounts)


class ClientCredentialStore:
    """Store developer-app credentials in the OS keyring when available.

    A permission-restricted JSON fallback is used only when the keyring is
    unavailable, matching TokenStore's documented fallback behavior.
    """

    def _file_load(self) -> dict:
        if not _CLIENT_CONFIG_FILE.exists():
            return {}
        try:
            with open(_CLIENT_CONFIG_FILE, encoding="utf-8") as handle:
                data = json.load(handle)
            return data if isinstance(data, dict) else {}
        except Exception as exc:
            log.warning("Unable to read client credential file: %s", exc)
            return {}

    def _file_save(self, data: dict, warn_fallback: bool = True) -> None:
        global _WARNED_FALLBACK
        _CRED_DIR.mkdir(parents=True, exist_ok=True)
        tmp_path = _CLIENT_CONFIG_FILE.with_suffix(".tmp")
        with open(tmp_path, "w", encoding="utf-8") as handle:
            json.dump(data, handle, indent=2)
        try:
            os.chmod(tmp_path, stat.S_IRUSR | stat.S_IWUSR)
        except Exception:
            pass
        os.replace(tmp_path, _CLIENT_CONFIG_FILE)
        try:
            os.chmod(_CLIENT_CONFIG_FILE, stat.S_IRUSR | stat.S_IWUSR)
        except Exception:
            pass
        if warn_fallback and not _WARNED_FALLBACK:
            _WARNED_FALLBACK = True
            warnings.warn(
                f"OS keyring unavailable — developer credentials stored in {_CLIENT_CONFIG_FILE} "
                "with owner-only permissions (0600). Install 'keyring' for OS-backed storage.",
                stacklevel=3,
            )
            log.warning("OS keyring unavailable; using protected client credential file")

    def get(self, platform: str, include_environment: bool = True) -> dict:
        """Return stored credentials, optionally filled from legacy env vars."""
        key = f"client-config::{platform}"
        raw = None
        if _keyring_available():
            try:
                import keyring
                raw = keyring.get_password(_CLIENT_CONFIG_SERVICE, key)
            except Exception as exc:
                log.warning("Keyring read failed for %s (%s)", platform, exc)
        if raw is None:
            raw = self._file_load().get(platform)

        values = {}
        if raw:
            try:
                decoded = json.loads(raw) if isinstance(raw, str) else raw
                if isinstance(decoded, dict):
                    values.update({str(k): str(v) for k, v in decoded.items() if v is not None})
            except (TypeError, ValueError):
                log.warning("Invalid saved client credentials for %s", platform)

        if include_environment:
            for field in PLATFORM_CREDENTIAL_FIELDS.get(platform, []):
                # A blank saved field must not mask a valid legacy environment
                # variable (for example, after opening and saving a partial form).
                if not values.get(field["key"]):
                    env_value = os.environ.get(field["env"], "")
                    if env_value:
                        values[field["key"]] = env_value
        return values

    def save(self, platform: str, values: dict) -> None:
        """Save one platform's app credentials without logging secret values."""
        allowed = {field["key"] for field in PLATFORM_CREDENTIAL_FIELDS.get(platform, [])}
        clean = {key: str(value).strip() for key, value in values.items()
                 if key in allowed and value is not None}
        payload = json.dumps(clean)
        key = f"client-config::{platform}"
        if _keyring_available():
            try:
                import keyring
                keyring.set_password(_CLIENT_CONFIG_SERVICE, key, payload)
                data = self._file_load()
                if platform in data:
                    del data[platform]
                    self._file_save(data, warn_fallback=False)
                log.info("Saved developer credentials for %s to OS keyring", platform)
                return
            except Exception as exc:
                log.warning("Keyring write failed for %s (%s); using protected file", platform, exc)
        data = self._file_load()
        data[platform] = payload
        self._file_save(data)
        log.info("Saved developer credentials for %s to protected file", platform)

    def delete(self, platform: str) -> None:
        """Delete saved developer credentials (environment variables are untouched)."""
        key = f"client-config::{platform}"
        if _keyring_available():
            try:
                import keyring
                try:
                    keyring.delete_password(_CLIENT_CONFIG_SERVICE, key)
                except Exception:
                    pass
            except Exception as exc:
                log.warning("Keyring delete failed for %s: %s", platform, exc)
        data = self._file_load()
        if platform in data:
            del data[platform]
            self._file_save(data, warn_fallback=not _keyring_available())
