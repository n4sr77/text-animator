"""Generic OAuth 2.0 / PKCE utilities.

Provides:
  - PKCE verifier + challenge generation (S256)
  - Cryptographic state generation + verification
  - Loopback redirect server (ephemeral port, timeout, cancel)
  - Device-code flow helper (display code + poll)
  - Token exchange + proactive refresh
"""

from __future__ import annotations

import base64
import hashlib
import http.server
import os
import queue
import secrets
import threading
import time
import urllib.parse
from dataclasses import dataclass
from typing import Callable

from ..log_setup import get_logger

log = get_logger(__name__)


# ---------------------------------------------------------------------------
# PKCE
# ---------------------------------------------------------------------------

def generate_pkce() -> tuple[str, str]:
    """
    Return (code_verifier, code_challenge_S256).

    code_verifier:  43-128 high-entropy chars [A-Za-z0-9-._~]
    code_challenge: BASE64URL(SHA-256(ASCII(verifier))) without padding
    """
    verifier = base64.urlsafe_b64encode(os.urandom(64)).rstrip(b"=").decode("ascii")
    digest = hashlib.sha256(verifier.encode("ascii")).digest()
    challenge = base64.urlsafe_b64encode(digest).rstrip(b"=").decode("ascii")
    return verifier, challenge


def generate_state() -> str:
    """Return a 32-byte URL-safe random state token."""
    return secrets.token_urlsafe(32)


def verify_state(expected: str, received: str) -> None:
    """Raise ValueError if the state token doesn't match (timing-safe)."""
    if not secrets.compare_digest(expected, received):
        raise ValueError("OAuth state mismatch — possible CSRF attack")


# ---------------------------------------------------------------------------
# Loopback redirect server
# ---------------------------------------------------------------------------

@dataclass
class RedirectResult:
    code: str = ""
    state: str = ""
    error: str = ""


def _make_handler(result_queue: queue.Queue, expected_state: str):
    """Return a handler class that captures the redirect and queues the result."""

    class _Handler(http.server.BaseHTTPRequestHandler):

        def do_GET(self):                                           # noqa: N802
            parsed = urllib.parse.urlparse(self.path)
            params = dict(urllib.parse.parse_qsl(parsed.query))

            received_state = params.get("state", "")
            code = params.get("code", "")
            error = params.get("error", "")

            try:
                verify_state(expected_state, received_state)
            except ValueError:
                result_queue.put(RedirectResult(error="state_mismatch"))
                self._respond(400, "State mismatch — please close this window.")
                return

            if not error and not code:
                error = "missing_authorization_code"
            if error and params.get("error_description"):
                error = f"{error}: {params['error_description']}"
            result = RedirectResult(code=code, state=received_state, error=error)
            result_queue.put(result)

            if error:
                self._respond(400, f"OAuth error: {error}. You may close this window.")
            else:
                self._respond(200,
                    "<html><body><h2>✓ Authorized!</h2>"
                    "<p>Return to TextAnimator — you may close this tab.</p>"
                    "</body></html>")

        def _respond(self, code: int, body: str):
            encoded = body.encode("utf-8")
            self.send_response(code)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(encoded)))
            self.end_headers()
            self.wfile.write(encoded)

        def log_message(self, fmt, *args):   # silence default access log
            log.debug("OAuth redirect server: " + fmt, *args)

    return _Handler


def wait_for_redirect(
    expected_state: str,
    timeout: float = 120.0,
    cancel_flag=None,          # threading.Event
) -> RedirectResult:
    """Start a loopback listener and wait for a validated OAuth response."""
    result_queue: queue.Queue = queue.Queue()
    handler_cls = _make_handler(result_queue, expected_state)

    server = http.server.HTTPServer(("127.0.0.1", 0), handler_cls)
    server.timeout = 0.5
    port = server.server_address[1]
    deadline = time.monotonic() + timeout
    stop = threading.Event()
    log.info("OAuth loopback server listening on 127.0.0.1:%d", port)

    def _serve():
        try:
            # Keep accepting until the authorization callback arrives. Calling
            # handle_request only once would silently stop after its 0.5s timeout.
            while not stop.is_set() and not result_queue.full() and time.monotonic() < deadline:
                server.handle_request()
        finally:
            server.server_close()

    server_thread = threading.Thread(target=_serve, daemon=True)
    server_thread.start()
    try:
        while time.monotonic() < deadline:
            if cancel_flag and cancel_flag.is_set():
                return RedirectResult(error="cancelled")
            try:
                return result_queue.get(timeout=0.5)
            except queue.Empty:
                continue
        return RedirectResult(error="timeout")
    finally:
        stop.set()
        server_thread.join(timeout=1.0)
        try:
            server.server_close()
        except Exception:
            pass


def loopback_port(expected_state: str) -> tuple[int, threading.Event, "queue.Queue[RedirectResult]"]:
    """
    Alternative API: start the server and return (port, cancel_event, result_queue).
    The caller opens the browser and can poll the queue itself.
    """
    result_queue: queue.Queue = queue.Queue()
    cancel = threading.Event()
    handler_cls = _make_handler(result_queue, expected_state)
    server = http.server.HTTPServer(("127.0.0.1", 0), handler_cls)
    server.timeout = 0.5
    port = server.server_address[1]

    def _serve():
        try:
            while not cancel.is_set():
                server.handle_request()
        finally:
            server.server_close()

    threading.Thread(target=_serve, daemon=True).start()
    return port, cancel, result_queue


# ---------------------------------------------------------------------------
# Device-code flow
# ---------------------------------------------------------------------------

@dataclass
class DeviceCodeInfo:
    device_code: str
    user_code: str
    verification_url: str
    expires_in: int = 1800
    interval: int = 5


def poll_device_token(
    token_endpoint: str,
    client_id: str,
    device_code_info: DeviceCodeInfo,
    post: Callable[[str, dict], dict],  # requests.post wrapper
    cancel_flag=None,
) -> dict:
    """
    Poll *token_endpoint* until the user authorises or the code expires.
    Returns the raw token response dict on success.
    Raises TimeoutError or RuntimeError on failure.

    *post* signature: post(url, data) → dict (parsed JSON body)
    """
    deadline = time.monotonic() + device_code_info.expires_in
    interval = device_code_info.interval

    while time.monotonic() < deadline:
        if cancel_flag and cancel_flag.is_set():
            raise InterruptedError("Device code flow cancelled")

        resp = post(token_endpoint, {
            "grant_type": "urn:ietf:params:oauth:grant-type:device_code",
            "client_id": client_id,
            "device_code": device_code_info.device_code,
        })

        error = resp.get("error", "")
        if not error:
            return resp
        if error == "authorization_pending":
            time.sleep(interval)
            continue
        if error == "slow_down":
            interval = min(interval + 5, 30)
            time.sleep(interval)
            continue
        if error == "expired_token":
            raise TimeoutError("Device code expired — please try again")
        raise RuntimeError(f"Device code error: {error} — {resp.get('error_description', '')}")

    raise TimeoutError("Device code expired (deadline reached)")


# ---------------------------------------------------------------------------
# Token refresh helpers
# ---------------------------------------------------------------------------

def token_expires_at(response: dict) -> float:
    """
    Given a token response dict (with 'expires_in'), return the Unix timestamp
    of expiry, with a 60-second safety buffer.
    """
    expires_in = int(response.get("expires_in", 3600))
    return time.time() + expires_in - 60
