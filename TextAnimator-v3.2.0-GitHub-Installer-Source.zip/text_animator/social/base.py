"""Core dataclasses and the SocialAdapter ABC.

No heavy third-party imports here — only stdlib + local errors.
"""

from __future__ import annotations

import abc
from dataclasses import dataclass, field
from typing import Callable


# ---------------------------------------------------------------------------
# Data models
# ---------------------------------------------------------------------------

@dataclass
class MediaSpec:
    """Platform requirements that every uploaded file must satisfy."""

    platform: str
    max_duration_s: float = 43_200          # 12 h
    max_size_bytes: int = 274_877_906_944   # 256 GB
    allowed_codecs: list[str] = field(default_factory=lambda: ["h264", "aac"])
    allowed_containers: list[str] = field(default_factory=lambda: ["mp4", "mov"])
    allowed_aspects: list[str] = field(default_factory=list)   # e.g. ["16:9","9:16","1:1"]
    min_width: int = 0
    min_height: int = 0
    max_width: int = 7680
    max_height: int = 4320
    min_fps: float = 0.0
    max_fps: float = 120.0
    notes: str = ""


@dataclass
class UploadRequest:
    """Everything needed to upload one video to one platform."""

    file_path: str
    platform: str
    account_id: str
    title: str = ""
    description: str = ""
    tags: list[str] = field(default_factory=list)
    visibility: str = "private"           # private | unlisted | public | draft
    auto_conform: bool = False
    extra: dict = field(default_factory=dict)   # platform-specific extras


@dataclass
class UploadResult:
    """Returned by SocialAdapter.upload()."""

    platform: str
    account_id: str
    file_path: str
    success: bool
    post_url: str = ""
    media_id: str = ""
    error: str = ""
    status: str = ""            # optional adapter lifecycle state (e.g. processing)


@dataclass
class AccountInfo:
    """Cached profile data for a connected account."""

    platform: str
    account_id: str
    display_name: str = ""
    username: str = ""
    avatar_url: str = ""
    needs_reauth: bool = False
    scopes: list[str] = field(default_factory=list)


@dataclass
class TokenBundle:
    """OAuth token set.  __repr__ never reveals secrets."""

    platform: str
    account_id: str
    access_token: str
    refresh_token: str = ""
    expires_at: float = 0.0        # Unix timestamp; 0 = never expires
    id_token: str = ""
    extra: dict = field(default_factory=dict)

    def __repr__(self) -> str:                                      # noqa: D105
        return (
            f"TokenBundle(platform={self.platform!r}, "
            f"account_id={self.account_id!r}, "
            f"access_token='***', refresh_token='***', "
            f"expires_at={self.expires_at})"
        )

    def is_expired(self, buffer_s: float = 60.0) -> bool:
        if self.expires_at == 0:
            return False
        import time
        return time.time() >= self.expires_at - buffer_s


# ---------------------------------------------------------------------------
# Abstract adapter
# ---------------------------------------------------------------------------

ProgressCallback = Callable[[int, int, str], None]   # current, total, message


class SocialAdapter(abc.ABC):
    """Interface every platform adapter must implement."""

    platform_id: str = ""       # e.g. "youtube", "tiktok"
    platform_name: str = ""     # human label: "YouTube"

    # -- Auth ----------------------------------------------------------------

    @abc.abstractmethod
    def auth_url(self, state: str, redirect_uri: str) -> str:
        """Return the OAuth authorisation URL for the browser."""

    @abc.abstractmethod
    def exchange_code(self, code: str, state: str, redirect_uri: str) -> TokenBundle:
        """Exchange an authorisation code for a TokenBundle."""

    @abc.abstractmethod
    def refresh_token(self, bundle: TokenBundle) -> TokenBundle:
        """Return a refreshed TokenBundle (never mutate the original)."""

    @abc.abstractmethod
    def fetch_account(self, bundle: TokenBundle) -> AccountInfo:
        """Fetch and return the connected account's profile."""

    # -- Validate ------------------------------------------------------------

    @abc.abstractmethod
    def media_spec(self) -> MediaSpec:
        """Return the MediaSpec for this platform."""

    @abc.abstractmethod
    def validate(self, request: UploadRequest) -> list[str]:
        """
        Validate *request.file_path* against this platform's MediaSpec.
        Returns a list of human-readable error strings (empty = valid).
        """

    # -- Upload --------------------------------------------------------------

    @abc.abstractmethod
    def upload(
        self,
        request: UploadRequest,
        bundle: TokenBundle,
        progress_callback: ProgressCallback | None = None,
        cancel_flag=None,
    ) -> UploadResult:
        """
        Upload the video.  Must honour *cancel_flag* (threading.Event).
        Raises SocialError subclasses on failure.
        """

    # -- Helpers (optional override) ----------------------------------------

    def supports_resume(self) -> bool:
        """True if the adapter implements resumable chunked upload."""
        return False

    def max_concurrent(self) -> int:
        """Recommended number of concurrent uploads for this platform."""
        return 1
