"""Auto-transcode a video to meet a platform's MediaSpec.

Uses the existing MediaProcessor (media_tools.py) for the heavy lifting.
Reports a human-readable diff before transcoding.
"""

from __future__ import annotations

import os
import tempfile
from pathlib import Path

from .base import MediaSpec, UploadRequest
from .validator import probe, validate
from ..log_setup import get_logger

log = get_logger(__name__)


def conformance_diff(file_path: str, spec: MediaSpec) -> str:
    """
    Return a one-line human-readable diff like:
      "1920×1080, h264, 45.3s → 1920×1080, h264, 30s (trimmed)"
    or empty string if already conformant.
    """
    errors = validate(UploadRequest(file_path=file_path, platform=spec.platform,
                                    account_id=""), spec)
    if not errors:
        return ""
    try:
        info = probe(file_path)
    except Exception:
        return "Could not probe file"

    changes = []
    if info["duration"] > spec.max_duration_s:
        changes.append(f"trim to {spec.max_duration_s:.0f}s")
    if info["video_codec"] not in spec.allowed_codecs and spec.allowed_codecs:
        changes.append(f"re-encode to {spec.allowed_codecs[0]}")
    if spec.allowed_containers and info["container"] not in spec.allowed_containers:
        changes.append(f"remux to {spec.allowed_containers[0]}")

    src = f"{info['width']}×{info['height']}, {info['video_codec']}, {info['duration']:.1f}s"
    if changes:
        return f"{src} → {', '.join(changes)}"
    return ""


def auto_conform(
    file_path: str,
    spec: MediaSpec,
    output_dir: str | None = None,
) -> str:
    """
    Transcode *file_path* to satisfy *spec* and return the path to the new file.
    If the file is already conformant, returns the original path unchanged.
    Caller is responsible for cleaning up the returned temp file on error/cancel.
    """
    errors = validate(UploadRequest(file_path=file_path, platform=spec.platform,
                                    account_id=""), spec)
    if not errors:
        log.debug("File already conformant for %s: %s", spec.platform, file_path)
        return file_path

    log.info("Auto-conforming for %s: %s", spec.platform, conformance_diff(file_path, spec))

    # We use ffmpeg directly for maximum flexibility
    import subprocess

    out_dir = output_dir or tempfile.mkdtemp(prefix="textanim_conform_")
    stem = Path(file_path).stem
    target_ext = spec.allowed_containers[0] if spec.allowed_containers else "mp4"
    out_path = str(Path(out_dir) / f"{stem}_conform.{target_ext}")

    info = probe(file_path)
    target_codec = spec.allowed_codecs[0] if spec.allowed_codecs else "libx264"
    # Map probe codec name to ffmpeg encoder
    codec_map = {"h264": "libx264", "h265": "libx265", "hevc": "libx265",
                 "vp9": "libvpx-vp9", "av1": "libaom-av1"}
    ffmpeg_codec = codec_map.get(target_codec, "libx264")

    cmd = ["ffmpeg", "-y", "-i", file_path, "-c:v", ffmpeg_codec,
           "-preset", "fast", "-crf", "23", "-c:a", "aac", "-b:a", "192k"]

    if info["duration"] > spec.max_duration_s:
        cmd.extend(["-t", str(spec.max_duration_s)])

    cmd.append(out_path)
    log.debug("Conformance cmd: %s", " ".join(cmd))

    result = subprocess.run(cmd, capture_output=True, timeout=3600)
    if result.returncode != 0:
        raise RuntimeError(f"ffmpeg conformance failed: {result.stderr.decode()[-500:]}")

    log.info("Conformance output: %s", out_path)
    return out_path
