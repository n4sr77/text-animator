"""Domain-specific exceptions for the social publishing layer."""

from __future__ import annotations


class SocialError(Exception):
    """Base class for all social-layer errors."""


class AuthError(SocialError):
    """OAuth token missing, expired, revoked, or invalid scope."""

    def __init__(self, message: str = "Authentication required", platform: str = "") -> None:
        super().__init__(message)
        self.platform = platform


class RateLimitError(SocialError):
    """API rate limit hit; ``retry_after`` seconds until reset (may be None)."""

    def __init__(self, message: str = "Rate limit exceeded",
                 retry_after: float | None = None) -> None:
        super().__init__(message)
        self.retry_after = retry_after


class ValidationError(SocialError):
    """File does not meet platform requirements (codec, size, duration …)."""

    def __init__(self, message: str, field: str = "") -> None:
        super().__init__(message)
        self.field = field


class UploadError(SocialError):
    """Non-transient upload failure (bad content, quota exceeded, …)."""


class TransientError(SocialError):
    """Temporary network or server error; safe to retry with backoff."""

    def __init__(self, message: str = "Transient error",
                 retry_after: float | None = None) -> None:
        super().__init__(message)
        self.retry_after = retry_after
