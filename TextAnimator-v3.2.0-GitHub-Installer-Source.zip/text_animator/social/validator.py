"""ffprobe-based media validation against a MediaSpec."""

from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path

from .base import MediaSpec, UploadRequest
from ..log_setup import get_logger

log = get_logger(__name__)

_FFPROBE_BINARY = "ffprobe"


def _ffprobe(path: str) -> dict:
    """Run ffprobe and return the parsed JSON output."""
    cmd = [
        _FFPROBE_BINARY, "-v", "quiet",
        "-print_format", "json",
        "-show_streams", "-show_format",
        path,
    ]
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
    if result.returncode != 0:
        raise RuntimeError(f"ffprobe failed: {result.stderr.strip()}")
    return json.loads(result.stdout)


def probe(file_path: str) -> dict:
    """
    Return a normalised probe dict:
    {
      'duration': float,
      'size_bytes': int,
      'width': int,
      'height': int,
      'fps': float,
      'video_codec': str,
      'audio_codec': str,
      'container': str,
    }
    Raises RuntimeError if ffprobe is unavailable or the file is unreadable.
    """
    data = _ffprobe(file_path)
    fmt = data.get("format", {})
    streams = data.get("streams", [])

    video = next((s for s in streams if s.get("codec_type") == "video"), {})
    audio = next((s for s in streams if s.get("codec_type") == "audio"), {})

    duration = float(fmt.get("duration", 0) or 0)
    size_bytes = int(fmt.get("size", 0) or os.path.getsize(file_path))
    width = int(video.get("width", 0))
    height = int(video.get("height", 0))
    fps = 0.0
    if "r_frame_rate" in video:
        try:
            num, den = video["r_frame_rate"].split("/")
            fps = float(num) / float(den) if float(den) else 0.0
        except Exception:
            pass
    video_codec = video.get("codec_name", "").lower()
    audio_codec = audio.get("codec_name", "").lower()
    container = fmt.get("format_name", "").split(",")[0].lower()

    return {
        "duration": duration,
        "size_bytes": size_bytes,
        "width": width,
        "height": height,
        "fps": fps,
        "video_codec": video_codec,
        "audio_codec": audio_codec,
        "container": container,
    }


def _gcd(a: int, b: int) -> int:
    while b:
        a, b = b, a % b
    return a


def _aspect_str(w: int, h: int) -> str:
    if w == 0 or h == 0:
        return "0:0"
    g = _gcd(w, h)
    return f"{w // g}:{h // g}"


def validate(request: UploadRequest, spec: MediaSpec) -> list[str]:
    """
    Validate *request.file_path* against *spec*.
    Returns a list of human-readable error strings (empty list = valid).
    """
    errors: list[str] = []
    path = request.file_path

    if not Path(path).is_file():
        return [f"File not found: {path}"]

    try:
        info = probe(path)
    except Exception as exc:
        log.error("ffprobe error on %s: %s", path, exc)
        return [f"Could not probe file ({exc})"]

    if info["duration"] > spec.max_duration_s:
        errors.append(
            f"Duration {info['duration']:.1f}s exceeds platform max "
            f"{spec.max_duration_s:.0f}s"
        )

    if info["size_bytes"] > spec.max_size_bytes:
        mb = info["size_bytes"] / 1_048_576
        max_mb = spec.max_size_bytes / 1_048_576
        errors.append(f"File size {mb:.0f} MB exceeds platform max {max_mb:.0f} MB")

    if spec.allowed_codecs and info["video_codec"] not in spec.allowed_codecs:
        errors.append(
            f"Video codec '{info['video_codec']}' not in allowed "
            f"{spec.allowed_codecs}"
        )

    if spec.allowed_containers and info["container"] not in spec.allowed_containers:
        errors.append(
            f"Container '{info['container']}' not in allowed "
            f"{spec.allowed_containers}"
        )

    if spec.allowed_aspects:
        aspect = _aspect_str(info["width"], info["height"])
        if aspect not in spec.allowed_aspects:
            errors.append(
                f"Aspect ratio {aspect} not in allowed {spec.allowed_aspects}"
            )

    if spec.min_width and info["width"] < spec.min_width:
        errors.append(f"Width {info['width']} < platform min {spec.min_width}")
    if spec.min_height and info["height"] < spec.min_height:
        errors.append(f"Height {info['height']} < platform min {spec.min_height}")

    if spec.max_fps and info["fps"] > spec.max_fps:
        errors.append(f"Frame rate {info['fps']:.1f} > platform max {spec.max_fps}")

    return errors
