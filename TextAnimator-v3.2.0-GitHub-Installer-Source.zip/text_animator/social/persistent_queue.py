"""Persistent upload queue backed by ~/.textanimator_queue.json.

Survives process restarts: jobs that were 'pending' or 'running' when the
process died are restored on the next start and can be retried.

Format
------
{
  "jobs": [
    {
      "job_id": "...",
      "request": { ... UploadRequest fields ... },
      "status": "pending|done|error|cancelled",
      "error": "...",
      "post_url": "...",
      "attempt": 0
    }
  ]
}
"""

from __future__ import annotations

import json
import os
import threading
from pathlib import Path
from typing import Optional

from .base import UploadRequest
from .queue import QueueJob, JobStatus
from ..config import SOCIAL_DEFAULTS
from ..log_setup import get_logger

log = get_logger(__name__)

_QUEUE_PATH = Path(SOCIAL_DEFAULTS.get("queue_path",
                   str(Path.home() / ".textanimator_queue.json")))
_lock = threading.Lock()


def _req_to_dict(req: UploadRequest) -> dict:
    return {
        "file_path": req.file_path,
        "platform": req.platform,
        "account_id": req.account_id,
        "title": req.title,
        "description": req.description,
        "tags": req.tags,
        "visibility": req.visibility,
        "auto_conform": req.auto_conform,
        "extra": req.extra,
    }


def _dict_to_req(d: dict) -> UploadRequest:
    return UploadRequest(
        file_path=d.get("file_path", ""),
        platform=d.get("platform", ""),
        account_id=d.get("account_id", ""),
        title=d.get("title", ""),
        description=d.get("description", ""),
        tags=d.get("tags", []),
        visibility=d.get("visibility", "private"),
        auto_conform=d.get("auto_conform", False),
        extra=d.get("extra", {}),
    )


def save_queue(jobs: list[QueueJob]) -> None:
    """Persist the current queue to disk."""
    data = {"jobs": []}
    for job in jobs:
        result_url = job.result.post_url if job.result else ""
        data["jobs"].append({
            "job_id": job.job_id,
            "request": _req_to_dict(job.request),
            "status": job.status.value,
            "error": job.error,
            "post_url": result_url,
            "attempt": job.attempt,
        })
    with _lock:
        try:
            _QUEUE_PATH.parent.mkdir(parents=True, exist_ok=True)
            tmp = str(_QUEUE_PATH) + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2)
            os.replace(tmp, _QUEUE_PATH)
            log.debug("Queue persisted: %d jobs → %s", len(jobs), _QUEUE_PATH)
        except Exception as exc:
            log.error("Failed to persist queue: %s", exc)


def load_queue() -> list[QueueJob]:
    """Load persisted jobs (pending/running) for display and retry."""
    with _lock:
        if not _QUEUE_PATH.exists():
            return []
        try:
            with open(_QUEUE_PATH, encoding="utf-8") as f:
                data = json.load(f)
        except Exception as exc:
            log.error("Failed to load queue: %s", exc)
            return []

    jobs = []
    for d in data.get("jobs", []):
        job = QueueJob(
            job_id=d.get("job_id", ""),
            request=_dict_to_req(d.get("request", {})),
            status=JobStatus(d.get("status", "pending")),
            error=d.get("error", ""),
            attempt=d.get("attempt", 0),
        )
        jobs.append(job)
    log.info("Loaded %d persisted queue jobs", len(jobs))
    return jobs


def has_unsaved_queue() -> bool:
    """Return True if there are pending jobs on disk (unsaved indicator)."""
    jobs = load_queue()
    return any(j.status in (JobStatus.PENDING, JobStatus.RUNNING) for j in jobs)
