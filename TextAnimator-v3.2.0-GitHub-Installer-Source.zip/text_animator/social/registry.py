"""Platform adapter discovery and capability registry."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .base import SocialAdapter


@dataclass
class PlatformCapability:
    platform_id: str
    platform_name: str
    supports_resume: bool = False
    max_concurrent: int = 1
    requires_extras: list[str] = field(default_factory=list)   # pip package names
    adapter_module: str = ""    # dotted module path
    adapter_class: str = ""     # class name inside that module


# Registry of all known platforms
_REGISTRY: dict[str, PlatformCapability] = {
    "youtube": PlatformCapability(
        "youtube", "YouTube",
        supports_resume=True, max_concurrent=1,
        requires_extras=["google-api-python-client", "google-auth-oauthlib"],
        adapter_module="text_animator.social.platforms.youtube",
        adapter_class="YouTubeAdapter",
    ),
    "tiktok": PlatformCapability(
        "tiktok", "TikTok",
        supports_resume=False, max_concurrent=1,
        requires_extras=["requests"],
        adapter_module="text_animator.social.platforms.tiktok",
        adapter_class="TikTokAdapter",
    ),
    "instagram": PlatformCapability(
        "instagram", "Instagram",
        supports_resume=False, max_concurrent=1,
        requires_extras=["requests"],
        adapter_module="text_animator.social.platforms.instagram",
        adapter_class="InstagramAdapter",
    ),
    "facebook": PlatformCapability(
        "facebook", "Facebook",
        supports_resume=True, max_concurrent=1,
        requires_extras=["requests"],
        adapter_module="text_animator.social.platforms.facebook",
        adapter_class="FacebookAdapter",
    ),
    "x_twitter": PlatformCapability(
        "x_twitter", "X / Twitter",
        supports_resume=True, max_concurrent=1,
        requires_extras=["tweepy"],
        adapter_module="text_animator.social.platforms.x_twitter",
        adapter_class="XTwitterAdapter",
    ),
    "linkedin": PlatformCapability(
        "linkedin", "LinkedIn",
        supports_resume=True, max_concurrent=1,
        requires_extras=["requests"],
        adapter_module="text_animator.social.platforms.linkedin",
        adapter_class="LinkedInAdapter",
    ),
    "threads": PlatformCapability(
        "threads", "Threads",
        supports_resume=False, max_concurrent=1,
        requires_extras=["requests"],
        adapter_module="text_animator.social.platforms.threads",
        adapter_class="ThreadsAdapter",
    ),
    "pinterest": PlatformCapability(
        "pinterest", "Pinterest",
        supports_resume=False, max_concurrent=2,
        requires_extras=["requests"],
        adapter_module="text_animator.social.platforms.pinterest",
        adapter_class="PinterestAdapter",
    ),
    "vimeo": PlatformCapability(
        "vimeo", "Vimeo",
        supports_resume=True, max_concurrent=2,
        requires_extras=["requests", "requests-toolbelt"],
        adapter_module="text_animator.social.platforms.vimeo",
        adapter_class="VimeoAdapter",
    ),
}


def list_platforms() -> list[PlatformCapability]:
    """Return all registered platform capabilities, sorted by name."""
    return sorted(_REGISTRY.values(), key=lambda c: c.platform_name)


def get_capability(platform_id: str) -> PlatformCapability | None:
    return _REGISTRY.get(platform_id)


def load_adapter(platform_id: str) -> "SocialAdapter":
    """
    Dynamically import and instantiate the adapter for *platform_id*.
    Raises ImportError with a helpful message if required extras are missing.
    """
    cap = _REGISTRY.get(platform_id)
    if not cap:
        raise ValueError(f"Unknown platform: {platform_id!r}")

    # Check extras availability
    missing = []
    for pkg in cap.requires_extras:
        import importlib
        # Convert package name to importable module name
        mod = pkg.replace("-", "_").replace("google_api_python_client", "googleapiclient")
        try:
            importlib.import_module(mod)
        except ImportError:
            missing.append(pkg)

    if missing:
        raise ImportError(
            f"Platform '{cap.platform_name}' requires: {', '.join(missing)}.\n"
            f"Install with:  pip install 'text-animator[social]'"
        )

    import importlib
    module = importlib.import_module(cap.adapter_module)
    cls = getattr(module, cap.adapter_class)

    # Load credentials saved in the desktop app (or legacy environment
    # variables).  Constructor keyword names intentionally match adapter APIs.
    from .credentials import ClientCredentialStore
    config = ClientCredentialStore().get(platform_id)
    kwargs_by_platform = {
        "youtube": ("client_id", "client_secret"),
        "tiktok": ("client_key", "client_secret"),
        "instagram": ("app_id", "app_secret"),
        "facebook": ("app_id", "app_secret"),
        "x_twitter": ("api_key", "api_secret", "client_id", "client_secret"),
        "linkedin": ("client_id", "client_secret"),
        "threads": ("app_id", "app_secret"),
        "pinterest": ("app_id", "app_secret"),
        "vimeo": ("client_id", "client_secret", "access_token"),
    }
    kwargs = {name: config.get(name, "") for name in kwargs_by_platform.get(platform_id, ())}
    return cls(**kwargs)


def available_platforms() -> list[PlatformCapability]:
    """Return only platforms whose extras are importable right now."""
    result = []
    for cap in _REGISTRY.values():
        try:
            load_adapter(cap.platform_id)
            result.append(cap)
        except (ImportError, Exception):
            pass
    return sorted(result, key=lambda c: c.platform_name)
