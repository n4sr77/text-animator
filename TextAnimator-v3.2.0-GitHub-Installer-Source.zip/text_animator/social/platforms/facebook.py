"""Facebook Page video upload adapter (resumable file_url method)."""

from __future__ import annotations

import os
import threading
import time
from typing import Callable

import requests

from ..base import AccountInfo, MediaSpec, SocialAdapter, TokenBundle, UploadRequest, UploadResult
from ..errors import AuthError, TransientError, UploadError, ValidationError
from ..oauth import token_expires_at
from ..validator import validate as validate_file
from ...log_setup import get_logger

log = get_logger(__name__)

_GRAPH = "https://graph.facebook.com/v19.0"
_SCOPES = "pages_manage_posts,pages_read_engagement,publish_video"


class FacebookAdapter(SocialAdapter):
    platform_id = "facebook"
    platform_name = "Facebook"

    def __init__(self, app_id: str = "", app_secret: str = "") -> None:
        self._app_id = app_id or os.environ.get("FB_APP_ID", "")
        self._app_secret = app_secret or os.environ.get("FB_APP_SECRET", "")

    def auth_url(self, state: str, redirect_uri: str) -> str:
        from urllib.parse import urlencode
        return (
            "https://www.facebook.com/v19.0/dialog/oauth?"
            + urlencode({
                "client_id": self._app_id,
                "redirect_uri": redirect_uri,
                "scope": _SCOPES,
                "state": state,
                "response_type": "code",
            })
        )

    def exchange_code(self, code: str, state: str, redirect_uri: str) -> TokenBundle:
        resp = requests.get(f"{_GRAPH}/oauth/access_token", params={
            "client_id": self._app_id,
            "client_secret": self._app_secret,
            "redirect_uri": redirect_uri,
            "code": code,
        }, timeout=30).json()
        if "error" in resp:
            raise AuthError(f"Facebook auth error: {resp['error'].get('message')}")
        return TokenBundle(
            platform=self.platform_id,
            account_id="",
            access_token=resp["access_token"],
            expires_at=token_expires_at({"expires_in": resp.get("expires_in", 3600)}),
        )

    def refresh_token(self, bundle: TokenBundle) -> TokenBundle:
        resp = requests.get(f"{_GRAPH}/oauth/access_token", params={
            "grant_type": "fb_exchange_token",
            "client_id": self._app_id,
            "client_secret": self._app_secret,
            "fb_exchange_token": bundle.access_token,
        }, timeout=30).json()
        if "error" in resp:
            raise AuthError("Facebook token refresh failed", platform=self.platform_id)
        return TokenBundle(
            platform=self.platform_id,
            account_id=bundle.account_id,
            access_token=resp["access_token"],
            expires_at=token_expires_at({"expires_in": resp.get("expires_in", 5_184_000)}),
        )

    def _page_token(self, bundle: TokenBundle, page_id: str) -> str:
        resp = requests.get(f"{_GRAPH}/{page_id}",
            params={"fields": "access_token", "access_token": bundle.access_token},
            timeout=15).json()
        return resp.get("access_token", bundle.access_token)

    def fetch_account(self, bundle: TokenBundle) -> AccountInfo:
        resp = requests.get(f"{_GRAPH}/me/accounts",
            params={"access_token": bundle.access_token}, timeout=15).json()
        pages = resp.get("data", [])
        if not pages:
            raise AuthError("No Facebook Pages found", platform=self.platform_id)
        page = pages[0]
        return AccountInfo(
            platform=self.platform_id,
            account_id=page["id"],
            display_name=page.get("name", ""),
            username=page.get("name", ""),
        )

    def media_spec(self) -> MediaSpec:
        return MediaSpec(
            platform=self.platform_id,
            max_duration_s=14400,            # 4 h
            max_size_bytes=10 * 1024**3,     # 10 GB
            allowed_codecs=["h264"],
            allowed_containers=["mp4", "mov"],
            allowed_aspects=[],
            notes="H.264 MP4 up to 4 hours.",
        )

    def validate(self, request: UploadRequest) -> list[str]:
        return validate_file(request, self.media_spec())

    def upload(
        self,
        request: UploadRequest,
        bundle: TokenBundle,
        progress_callback: Callable[[int, int, str], None] | None = None,
        cancel_flag: threading.Event | None = None,
    ) -> UploadResult:
        errors = self.validate(request)
        if errors:
            raise ValidationError("; ".join(errors))

        file_path = request.file_path
        total_bytes = os.path.getsize(file_path)
        page_id = bundle.account_id
        page_token = self._page_token(bundle, page_id)

        # Resumable upload: start session
        start_resp = requests.post(f"https://graph-video.facebook.com/v19.0/{page_id}/videos",
            data={
                "upload_phase": "start",
                "file_size": total_bytes,
                "access_token": page_token,
            }, timeout=30).json()
        if "error" in start_resp:
            raise UploadError(f"FB upload start error: {start_resp['error']['message']}")

        upload_session_id = start_resp.get("upload_session_id", "")
        video_id = start_resp.get("video_id", "")

        # Upload chunks
        chunk_size = 10 * 1024 * 1024
        offset = 0
        with open(file_path, "rb") as fh:
            while offset < total_bytes:
                if cancel_flag and cancel_flag.is_set():
                    return UploadResult(platform=self.platform_id, account_id=page_id,
                                        file_path=file_path, success=False, error="cancelled")
                chunk = fh.read(chunk_size)
                transfer_resp = requests.post(
                    f"https://graph-video.facebook.com/v19.0/{page_id}/videos",
                    data={
                        "upload_phase": "transfer",
                        "upload_session_id": upload_session_id,
                        "start_offset": offset,
                        "access_token": page_token,
                    },
                    files={"video_file_chunk": ("chunk", chunk, "application/octet-stream")},
                    timeout=120,
                ).json()
                if "error" in transfer_resp:
                    raise TransientError(f"FB transfer error: {transfer_resp['error']['message']}")
                offset = int(transfer_resp.get("start_offset", offset + len(chunk)))
                if progress_callback:
                    progress_callback(offset, total_bytes, f"Uploading to Facebook… {offset // 1_048_576} MB")

        # Finish
        finish_resp = requests.post(f"https://graph-video.facebook.com/v19.0/{page_id}/videos",
            data={
                "upload_phase": "finish",
                "upload_session_id": upload_session_id,
                "title": request.title,
                "description": request.description,
                "published": str(request.visibility == "public").lower(),
                "access_token": page_token,
            }, timeout=30).json()
        if "error" in finish_resp:
            raise UploadError(f"FB finish error: {finish_resp['error']['message']}")

        post_url = f"https://www.facebook.com/{page_id}/videos/{video_id}" if video_id else ""
        return UploadResult(
            platform=self.platform_id, account_id=page_id,
            file_path=file_path, success=True,
            media_id=video_id, post_url=post_url,
        )

    def supports_resume(self) -> bool:
        return True
