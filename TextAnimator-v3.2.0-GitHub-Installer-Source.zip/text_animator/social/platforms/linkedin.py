"""LinkedIn adapter: registerUpload → PUT → create post URN."""

from __future__ import annotations

import os
import threading
from typing import Callable

import requests

from ..base import AccountInfo, MediaSpec, SocialAdapter, TokenBundle, UploadRequest, UploadResult
from ..errors import AuthError, TransientError, UploadError, ValidationError
from ..oauth import token_expires_at
from ..validator import validate as validate_file
from ...log_setup import get_logger

log = get_logger(__name__)

_API = "https://api.linkedin.com/v2"
_SCOPES = "w_member_social,r_liteprofile"


class LinkedInAdapter(SocialAdapter):
    platform_id = "linkedin"
    platform_name = "LinkedIn"

    def __init__(self, client_id: str = "", client_secret: str = "") -> None:
        self._client_id = client_id or os.environ.get("LI_CLIENT_ID", "")
        self._client_secret = client_secret or os.environ.get("LI_CLIENT_SECRET", "")

    def auth_url(self, state: str, redirect_uri: str) -> str:
        from urllib.parse import urlencode
        return (
            "https://www.linkedin.com/oauth/v2/authorization?"
            + urlencode({
                "response_type": "code",
                "client_id": self._client_id,
                "redirect_uri": redirect_uri,
                "state": state,
                "scope": _SCOPES,
            })
        )

    def exchange_code(self, code: str, state: str, redirect_uri: str) -> TokenBundle:
        resp = requests.post("https://www.linkedin.com/oauth/v2/accessToken", data={
            "grant_type": "authorization_code",
            "code": code,
            "redirect_uri": redirect_uri,
            "client_id": self._client_id,
            "client_secret": self._client_secret,
        }, timeout=30).json()
        if "error" in resp:
            raise AuthError(f"LinkedIn auth error: {resp.get('error_description', resp)}")
        return TokenBundle(
            platform=self.platform_id,
            account_id="",
            access_token=resp["access_token"],
            refresh_token=resp.get("refresh_token", ""),
            expires_at=token_expires_at({"expires_in": resp.get("expires_in", 5_184_000)}),
        )

    def refresh_token(self, bundle: TokenBundle) -> TokenBundle:
        if not bundle.refresh_token:
            raise AuthError("LinkedIn requires re-auth (no refresh token)", platform=self.platform_id)
        resp = requests.post("https://www.linkedin.com/oauth/v2/accessToken", data={
            "grant_type": "refresh_token",
            "refresh_token": bundle.refresh_token,
            "client_id": self._client_id,
            "client_secret": self._client_secret,
        }, timeout=30).json()
        if "error" in resp:
            raise AuthError("LinkedIn token refresh failed", platform=self.platform_id)
        return TokenBundle(
            platform=self.platform_id,
            account_id=bundle.account_id,
            access_token=resp["access_token"],
            refresh_token=resp.get("refresh_token", bundle.refresh_token),
            expires_at=token_expires_at({"expires_in": resp.get("expires_in", 5_184_000)}),
        )

    def _headers(self, bundle: TokenBundle) -> dict:
        return {"Authorization": f"Bearer {bundle.access_token}", "X-Restli-Protocol-Version": "2.0.0"}

    def fetch_account(self, bundle: TokenBundle) -> AccountInfo:
        resp = requests.get(f"{_API}/me",
            params={"projection": "(id,localizedFirstName,localizedLastName)"},
            headers=self._headers(bundle), timeout=15).json()
        person_id = resp.get("id", "")
        name = f"{resp.get('localizedFirstName','')} {resp.get('localizedLastName','')}".strip()
        return AccountInfo(
            platform=self.platform_id,
            account_id=person_id,
            display_name=name,
        )

    def media_spec(self) -> MediaSpec:
        return MediaSpec(
            platform=self.platform_id,
            max_duration_s=600,          # 10 min
            max_size_bytes=5 * 1024**3,  # 5 GB
            allowed_codecs=["h264"],
            allowed_containers=["mp4", "mov"],
            allowed_aspects=[],
            notes="H.264 MP4 up to 10 min.",
        )

    def validate(self, request: UploadRequest) -> list[str]:
        return validate_file(request, self.media_spec())

    def upload(
        self,
        request: UploadRequest,
        bundle: TokenBundle,
        progress_callback: Callable[[int, int, str], None] | None = None,
        cancel_flag: threading.Event | None = None,
    ) -> UploadResult:
        errors = self.validate(request)
        if errors:
            raise ValidationError("; ".join(errors))

        file_path = request.file_path
        total_bytes = os.path.getsize(file_path)
        person_urn = f"urn:li:person:{bundle.account_id}"
        headers = self._headers(bundle)

        # 1. Register upload
        reg_resp = requests.post(f"{_API}/assets?action=registerUpload",
            json={
                "registerUploadRequest": {
                    "owner": person_urn,
                    "recipes": ["urn:li:digitalmediaRecipe:feedshare-video"],
                    "serviceRelationships": [{
                        "identifier": "urn:li:userGeneratedContent",
                        "relationshipType": "OWNER",
                    }],
                }
            },
            headers={**headers, "Content-Type": "application/json"}, timeout=30).json()

        upload_url = reg_resp["value"]["uploadMechanism"][
            "com.linkedin.digitalmedia.uploading.MediaUploadHttpRequest"]["uploadUrl"]
        asset = reg_resp["value"]["asset"]

        if progress_callback:
            progress_callback(0, total_bytes, "LinkedIn: uploading video…")

        # 2. PUT file
        with open(file_path, "rb") as fh:
            put_resp = requests.put(upload_url, data=fh,
                headers={"Authorization": headers["Authorization"]}, timeout=600)
        if put_resp.status_code not in (200, 201):
            raise TransientError(f"LinkedIn PUT failed: HTTP {put_resp.status_code}")

        if progress_callback:
            progress_callback(total_bytes, total_bytes, "LinkedIn: creating post…")

        # 3. Create post
        post_resp = requests.post(f"{_API}/ugcPosts",
            json={
                "author": person_urn,
                "lifecycleState": "PUBLISHED",
                "specificContent": {
                    "com.linkedin.ugc.ShareContent": {
                        "shareCommentary": {"text": f"{request.title}\n{request.description}".strip()},
                        "shareMediaCategory": "VIDEO",
                        "media": [{"status": "READY", "media": asset, "title": {"text": request.title}}],
                    }
                },
                "visibility": {"com.linkedin.ugc.MemberNetworkVisibility":
                               "PUBLIC" if request.visibility == "public" else "CONNECTIONS"},
            },
            headers={**headers, "Content-Type": "application/json"}, timeout=30)

        if post_resp.status_code not in (200, 201):
            raise UploadError(f"LinkedIn post creation failed: {post_resp.text[:200]}")

        post_id = post_resp.json().get("id", "")
        return UploadResult(
            platform=self.platform_id, account_id=bundle.account_id,
            file_path=file_path, success=True,
            media_id=asset, post_url=f"https://www.linkedin.com/feed/update/{post_id}",
        )

    def supports_resume(self) -> bool:
        return True
