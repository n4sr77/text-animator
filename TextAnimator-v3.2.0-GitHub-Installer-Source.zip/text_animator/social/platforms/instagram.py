"""Instagram / Meta Graph API adapter (Reels via container + poll + publish)."""

from __future__ import annotations

import os
import threading
import time
from typing import Callable

import requests

from ..base import AccountInfo, MediaSpec, SocialAdapter, TokenBundle, UploadRequest, UploadResult
from ..errors import AuthError, RateLimitError, TransientError, UploadError, ValidationError
from ..oauth import token_expires_at
from ..validator import validate as validate_file
from ...log_setup import get_logger

log = get_logger(__name__)

_GRAPH = "https://graph.facebook.com/v19.0"
_SCOPES = "instagram_basic,instagram_content_publish,pages_read_engagement"


class InstagramAdapter(SocialAdapter):
    platform_id = "instagram"
    platform_name = "Instagram"

    def __init__(self, app_id: str = "", app_secret: str = "") -> None:
        self._app_id = app_id or os.environ.get("IG_APP_ID", "")
        self._app_secret = app_secret or os.environ.get("IG_APP_SECRET", "")

    def auth_url(self, state: str, redirect_uri: str) -> str:
        from urllib.parse import urlencode
        return (
            "https://www.facebook.com/v19.0/dialog/oauth?"
            + urlencode({
                "client_id": self._app_id,
                "redirect_uri": redirect_uri,
                "scope": _SCOPES,
                "state": state,
                "response_type": "code",
            })
        )

    def exchange_code(self, code: str, state: str, redirect_uri: str) -> TokenBundle:
        resp = requests.get(f"{_GRAPH}/oauth/access_token", params={
            "client_id": self._app_id,
            "client_secret": self._app_secret,
            "redirect_uri": redirect_uri,
            "code": code,
        }, timeout=30).json()
        if "error" in resp:
            raise AuthError(f"Instagram auth error: {resp['error'].get('message')}")
        return TokenBundle(
            platform=self.platform_id,
            account_id="",
            access_token=resp["access_token"],
            expires_at=token_expires_at({"expires_in": resp.get("expires_in", 3600)}),
        )

    def refresh_token(self, bundle: TokenBundle) -> TokenBundle:
        resp = requests.get(f"{_GRAPH}/oauth/access_token", params={
            "grant_type": "fb_exchange_token",
            "client_id": self._app_id,
            "client_secret": self._app_secret,
            "fb_exchange_token": bundle.access_token,
        }, timeout=30).json()
        if "error" in resp:
            raise AuthError("Instagram token refresh failed", platform=self.platform_id)
        return TokenBundle(
            platform=self.platform_id,
            account_id=bundle.account_id,
            access_token=resp["access_token"],
            expires_at=token_expires_at({"expires_in": resp.get("expires_in", 5_184_000)}),
        )

    def _ig_user_id(self, bundle: TokenBundle) -> str:
        resp = requests.get(f"{_GRAPH}/me/accounts",
            params={"access_token": bundle.access_token}, timeout=15).json()
        for page in resp.get("data", []):
            ig_resp = requests.get(f"{_GRAPH}/{page['id']}",
                params={"fields": "instagram_business_account", "access_token": page["access_token"]},
                timeout=15).json()
            ig_id = ig_resp.get("instagram_business_account", {}).get("id")
            if ig_id:
                return ig_id
        raise AuthError("No Instagram Business Account linked", platform=self.platform_id)

    def fetch_account(self, bundle: TokenBundle) -> AccountInfo:
        ig_id = self._ig_user_id(bundle)
        resp = requests.get(f"{_GRAPH}/{ig_id}",
            params={"fields": "name,username,profile_picture_url",
                    "access_token": bundle.access_token}, timeout=15).json()
        return AccountInfo(
            platform=self.platform_id,
            account_id=ig_id,
            display_name=resp.get("name", ""),
            username=resp.get("username", ""),
            avatar_url=resp.get("profile_picture_url", ""),
        )

    def media_spec(self) -> MediaSpec:
        return MediaSpec(
            platform=self.platform_id,
            max_duration_s=900,          # 15 min Reels
            max_size_bytes=1024**3,      # 1 GB
            allowed_codecs=["h264"],
            allowed_containers=["mp4"],
            allowed_aspects=["9:16", "1:1", "4:5", "16:9"],
            min_width=320, min_height=320,
            max_fps=60.0,
            notes="Vertical 9:16 for Reels; H.264 MP4 required.",
        )

    def validate(self, request: UploadRequest) -> list[str]:
        return validate_file(request, self.media_spec())

    def upload(
        self,
        request: UploadRequest,
        bundle: TokenBundle,
        progress_callback: Callable[[int, int, str], None] | None = None,
        cancel_flag: threading.Event | None = None,
    ) -> UploadResult:
        errors = self.validate(request)
        if errors:
            raise ValidationError("; ".join(errors))

        # Instagram requires a publicly accessible video URL.
        video_url = request.extra.get("video_url")
        if not video_url:
            raise UploadError(
                "Instagram requires a public video URL. "
                "Host the file and pass it as extra['video_url']."
            )

        ig_id = bundle.account_id or self._ig_user_id(bundle)
        token = bundle.access_token

        # 1. Create container
        container_resp = requests.post(f"{_GRAPH}/{ig_id}/media", data={
            "media_type": "REELS",
            "video_url": video_url,
            "caption": f"{request.title}\n{request.description}".strip(),
            "share_to_feed": "true",
            "access_token": token,
        }, timeout=30).json()
        if "error" in container_resp:
            raise UploadError(f"IG container error: {container_resp['error']['message']}")

        container_id = container_resp["id"]
        if progress_callback:
            progress_callback(1, 3, "Instagram: container created, waiting for processing…")

        # 2. Poll until FINISHED
        deadline = time.monotonic() + 300
        while time.monotonic() < deadline:
            if cancel_flag and cancel_flag.is_set():
                return UploadResult(platform=self.platform_id, account_id=ig_id,
                                    file_path=request.file_path, success=False, error="cancelled")
            status_resp = requests.get(f"{_GRAPH}/{container_id}",
                params={"fields": "status_code", "access_token": token}, timeout=15).json()
            status_code = status_resp.get("status_code", "")
            if status_code == "FINISHED":
                break
            if status_code == "ERROR":
                raise UploadError(f"IG container error: {status_resp}")
            time.sleep(5)
        else:
            raise TransientError("Instagram container processing timeout")

        if progress_callback:
            progress_callback(2, 3, "Instagram: publishing…")

        # 3. Publish
        pub_resp = requests.post(f"{_GRAPH}/{ig_id}/media_publish", data={
            "creation_id": container_id,
            "access_token": token,
        }, timeout=30).json()
        if "error" in pub_resp:
            raise UploadError(f"IG publish error: {pub_resp['error']['message']}")

        media_id = pub_resp.get("id", "")
        post_url = f"https://www.instagram.com/p/{media_id}/" if media_id else ""
        return UploadResult(
            platform=self.platform_id, account_id=ig_id,
            file_path=request.file_path, success=True,
            media_id=media_id, post_url=post_url,
        )
