"""YouTube adapter using google-api-python-client + google-auth-oauthlib.

Requires:  pip install 'text-animator[social]'
Scopes:    https://www.googleapis.com/auth/youtube.upload
           https://www.googleapis.com/auth/youtube.readonly

Upload strategy: resumable (single chunked request via the Data API v3).
Quota cost:  ~1,600 units per upload — we surface a remaining estimate.
"""

from __future__ import annotations

import json
import os
import threading
import time
from typing import Callable

from ..base import (
    AccountInfo, MediaSpec, SocialAdapter, TokenBundle,
    UploadRequest, UploadResult,
)
from ..errors import AuthError, RateLimitError, TransientError, UploadError, ValidationError
from ..oauth import generate_pkce, generate_state, token_expires_at
from ..validator import validate as validate_file
from ...log_setup import get_logger

log = get_logger(__name__)

SCOPES = [
    "https://www.googleapis.com/auth/youtube.upload",
    "https://www.googleapis.com/auth/youtube.readonly",
]
_CHUNK_SIZE = 10 * 1024 * 1024   # 10 MB


def _api_error_reason(exc) -> str:
    """Extract the structured Google API error reason when present."""
    content = getattr(exc, "content", b"")
    try:
        if isinstance(content, bytes):
            content = content.decode("utf-8", errors="replace")
        payload = json.loads(content) if content else {}
        errors = payload.get("error", {}).get("errors", [])
        if errors and isinstance(errors[0], dict):
            return str(errors[0].get("reason", ""))
        return str(payload.get("error", {}).get("status", ""))
    except (TypeError, ValueError, AttributeError):
        return ""


class YouTubeAdapter(SocialAdapter):
    platform_id = "youtube"
    platform_name = "YouTube"

    def __init__(self, client_id: str = "", client_secret: str = "") -> None:
        self._client_id = client_id or os.environ.get("YT_CLIENT_ID", "")
        self._client_secret = client_secret or os.environ.get("YT_CLIENT_SECRET", "")
        self._code_verifier = ""

    # -- Auth ---------------------------------------------------------------

    def _flow(self, redirect_uri: str, code_verifier: str = "", auto_pkce: bool = False):
        from google_auth_oauthlib.flow import Flow  # type: ignore
        if not self._client_id or not self._client_secret:
            raise AuthError(
                "YouTube OAuth Client ID and Client Secret are required. "
                "Open Publish → API Credentials…",
                platform=self.platform_id,
            )
        # YouTube desktop clients must use the installed-app OAuth type and
        # loopback redirect flow. PKCE is generated per authorization request.
        return Flow.from_client_config(
            {"installed": {
                "client_id": self._client_id,
                "client_secret": self._client_secret,
                "auth_uri": "https://accounts.google.com/o/oauth2/auth",
                "token_uri": "https://oauth2.googleapis.com/token",
                "redirect_uris": ["http://localhost"],
            }},
            scopes=SCOPES,
            redirect_uri=redirect_uri,
            code_verifier=code_verifier or None,
            autogenerate_code_verifier=auto_pkce,
        )

    def auth_url(self, state: str, redirect_uri: str) -> str:
        flow = self._flow(redirect_uri, auto_pkce=True)
        url, _ = flow.authorization_url(
            access_type="offline",
            include_granted_scopes="true",
            state=state,
            prompt="consent",
        )
        self._code_verifier = getattr(flow, "code_verifier", "") or ""
        return url

    def exchange_code(self, code: str, state: str, redirect_uri: str) -> TokenBundle:
        if not self._code_verifier:
            raise AuthError("YouTube PKCE verifier is missing. Restart account connection.", platform=self.platform_id)
        flow = self._flow(redirect_uri, code_verifier=self._code_verifier)
        flow.fetch_token(code=code)
        self._code_verifier = ""
        creds = flow.credentials
        return TokenBundle(
            platform=self.platform_id,
            account_id="",           # filled in by fetch_account
            access_token=creds.token or "",
            refresh_token=creds.refresh_token or "",
            expires_at=token_expires_at({"expires_in": 3600}),
            id_token=getattr(creds, "id_token", "") or "",
        )

    def refresh_token(self, bundle: TokenBundle) -> TokenBundle:
        import google.auth.transport.requests as gtreq              # type: ignore
        from google.oauth2.credentials import Credentials           # type: ignore
        creds = Credentials(
            token=bundle.access_token,
            refresh_token=bundle.refresh_token,
            token_uri="https://oauth2.googleapis.com/token",
            client_id=self._client_id,
            client_secret=self._client_secret,
        )
        try:
            creds.refresh(gtreq.Request())
        except Exception as exc:
            detail = str(exc)
            if any(token in detail.lower() for token in ("invalid_grant", "invalid_client", "revoked", "expired")):
                raise AuthError(f"YouTube authorization must be renewed: {detail}", platform=self.platform_id) from exc
            raise TransientError(f"YouTube token refresh failed: {detail}", retry_after=15) from exc
        new_refresh = creds.refresh_token or bundle.refresh_token
        return TokenBundle(
            platform=self.platform_id,
            account_id=bundle.account_id,
            access_token=creds.token or "",
            refresh_token=new_refresh,
            expires_at=token_expires_at({"expires_in": 3600}),
        )

    def _build_service(self, bundle: TokenBundle):
        from google.oauth2.credentials import Credentials           # type: ignore
        from googleapiclient.discovery import build                 # type: ignore
        creds = Credentials(
            token=bundle.access_token,
            refresh_token=bundle.refresh_token,
            token_uri="https://oauth2.googleapis.com/token",
            client_id=self._client_id,
            client_secret=self._client_secret,
            scopes=SCOPES,
        )
        return build("youtube", "v3", credentials=creds, cache_discovery=False)

    def fetch_account(self, bundle: TokenBundle) -> AccountInfo:
        service = self._build_service(bundle)
        resp = service.channels().list(part="snippet", mine=True).execute()
        items = resp.get("items", [])
        if not items:
            raise AuthError("No YouTube channel found", platform=self.platform_id)
        snippet = items[0].get("snippet", {})
        channel_id = items[0].get("id", "")
        return AccountInfo(
            platform=self.platform_id,
            account_id=channel_id,
            display_name=snippet.get("title", ""),
            username=snippet.get("customUrl", ""),
            avatar_url=snippet.get("thumbnails", {}).get("default", {}).get("url", ""),
        )

    # -- Validate -----------------------------------------------------------

    def media_spec(self) -> MediaSpec:
        return MediaSpec(
            platform=self.platform_id,
            max_duration_s=43_200,            # 12 h
            max_size_bytes=274_877_906_944,   # 256 GB
            allowed_codecs=["h264", "hevc", "vp9", "av1"],
            allowed_containers=["mp4", "mov", "avi", "wmv", "flv", "webm", "mkv"],
            allowed_aspects=[],               # YouTube accepts any
            notes="H.264 MP4 recommended for best compatibility.",
        )

    def validate(self, request: UploadRequest) -> list[str]:
        errors = validate_file(request, self.media_spec())
        title = request.title or os.path.basename(request.file_path)
        description = request.description or ""
        if len(title) > 100:
            errors.append("YouTube video titles must be 100 characters or fewer.")
        if "<" in title or ">" in title:
            errors.append("YouTube titles cannot contain < or > characters.")
        if len(description.encode("utf-8")) > 5000:
            errors.append("YouTube descriptions must be 5,000 UTF-8 bytes or fewer.")
        if "<" in description or ">" in description:
            errors.append("YouTube descriptions cannot contain < or > characters.")
        # YouTube counts commas and quotes around tags containing spaces.
        tag_length = sum(len(tag) + (2 if " " in tag else 0) for tag in request.tags)
        tag_length += max(0, len(request.tags) - 1)
        if tag_length > 500:
            errors.append("YouTube tags must total 500 characters or fewer, including separators.")
        return errors

    # -- Upload -------------------------------------------------------------

    def upload(
        self,
        request: UploadRequest,
        bundle: TokenBundle,
        progress_callback: Callable[[int, int, str], None] | None = None,
        cancel_flag: threading.Event | None = None,
    ) -> UploadResult:
        from googleapiclient.http import MediaFileUpload            # type: ignore
        from googleapiclient.errors import HttpError               # type: ignore

        file_path = request.file_path
        if not os.path.isfile(file_path):
            raise UploadError(f"File not found: {file_path}")

        errors = self.validate(request)
        if errors:
            raise ValidationError("; ".join(errors))

        service = self._build_service(bundle)
        total_bytes = os.path.getsize(file_path)

        body = {
            "snippet": {
                "title": request.title or os.path.basename(file_path),
                "description": request.description,
                "tags": request.tags,
                "categoryId": request.extra.get("category_id", "22"),  # People & Blogs
            },
            "status": {
                "privacyStatus": request.visibility if request.visibility in
                                  ("public", "private", "unlisted") else "private",
                "selfDeclaredMadeForKids": request.extra.get("made_for_kids", False),
            },
        }

        media = MediaFileUpload(
            file_path,
            mimetype="video/*",
            resumable=True,
            chunksize=_CHUNK_SIZE,
        )

        insert_request = service.videos().insert(
            part=",".join(body.keys()),
            body=body,
            media_body=media,
        )

        response = None
        uploaded = 0
        try:
            while response is None:
                if cancel_flag and cancel_flag.is_set():
                    raise InterruptedError("Upload cancelled")
                try:
                    # google-api-python-client retries transient HTTP failures
                    # within the same resumable session, avoiding duplicate inserts.
                    status, response = insert_request.next_chunk(num_retries=5)
                except HttpError as e:
                    status_code = e.resp.status
                    reason = _api_error_reason(e)
                    if status_code in (429,) or reason in ("rateLimitExceeded", "userRateLimitExceeded"):
                        raise RateLimitError(f"YouTube API rate limit ({reason or status_code})", retry_after=60) from e
                    if status_code in (500, 502, 503, 504):
                        raise TransientError(f"YouTube API server error HTTP {status_code}", retry_after=30) from e
                    if reason in ("quotaExceeded", "dailyLimitExceeded"):
                        raise UploadError("YouTube API project quota has been exceeded. Check Google Cloud quota/billing before retrying.") from e
                    if status_code == 401 or reason in (
                        "authError", "invalidCredentials", "youtubeSignupRequired",
                        "insufficientPermissions", "forbidden",
                    ):
                        raise AuthError(f"YouTube authorization failed ({reason or status_code}): {e}",
                                        platform=self.platform_id) from e
                    raise UploadError(f"YouTube API error HTTP {status_code} ({reason or 'unknown'}): {e}") from e

                if status and progress_callback:
                    uploaded = status.resumable_progress or 0
                    progress_callback(
                        uploaded, total_bytes,
                        f"Uploading to YouTube… {uploaded // 1_048_576} MB / "
                        f"{total_bytes // 1_048_576} MB"
                    )
        except InterruptedError:
            return UploadResult(
                platform=self.platform_id, account_id=bundle.account_id,
                file_path=file_path, success=False, error="cancelled"
            )

        video_id = response.get("id", "")
        if not video_id:
            raise UploadError("YouTube upload returned success without a video ID")
        post_url = f"https://www.youtube.com/watch?v={video_id}"
        log.info("YouTube upload complete: %s", post_url)
        return UploadResult(
            platform=self.platform_id,
            account_id=bundle.account_id,
            file_path=file_path,
            success=True,
            media_id=video_id,
            post_url=post_url,
        )

    def supports_resume(self) -> bool:
        return True
