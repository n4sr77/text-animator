"""Pinterest adapter: media upload → pin creation."""

from __future__ import annotations

import os
import threading
from typing import Callable

import requests

from ..base import AccountInfo, MediaSpec, SocialAdapter, TokenBundle, UploadRequest, UploadResult
from ..errors import AuthError, UploadError, ValidationError
from ..oauth import token_expires_at
from ..validator import validate as validate_file
from ...log_setup import get_logger

log = get_logger(__name__)

_API = "https://api.pinterest.com/v5"
_SCOPES = "boards:read,pins:write,user_accounts:read"


class PinterestAdapter(SocialAdapter):
    platform_id = "pinterest"
    platform_name = "Pinterest"

    def __init__(self, app_id: str = "", app_secret: str = "") -> None:
        self._app_id = app_id or os.environ.get("PINTEREST_APP_ID", "")
        self._app_secret = app_secret or os.environ.get("PINTEREST_APP_SECRET", "")

    def auth_url(self, state: str, redirect_uri: str) -> str:
        from urllib.parse import urlencode
        return (
            "https://www.pinterest.com/oauth/?"
            + urlencode({
                "client_id": self._app_id,
                "redirect_uri": redirect_uri,
                "response_type": "code",
                "scope": _SCOPES,
                "state": state,
            })
        )

    def exchange_code(self, code: str, state: str, redirect_uri: str) -> TokenBundle:
        resp = requests.post(f"{_API}/oauth/token", data={
            "grant_type": "authorization_code",
            "code": code,
            "redirect_uri": redirect_uri,
        }, auth=(self._app_id, self._app_secret), timeout=30).json()
        if "error" in resp:
            raise AuthError(f"Pinterest auth error: {resp.get('error_description', resp)}")
        return TokenBundle(
            platform=self.platform_id,
            account_id="",
            access_token=resp["access_token"],
            refresh_token=resp.get("refresh_token", ""),
            expires_at=token_expires_at({"expires_in": resp.get("expires_in", 2_592_000)}),
        )

    def refresh_token(self, bundle: TokenBundle) -> TokenBundle:
        resp = requests.post(f"{_API}/oauth/token", data={
            "grant_type": "refresh_token",
            "refresh_token": bundle.refresh_token,
        }, auth=(self._app_id, self._app_secret), timeout=30).json()
        if "error" in resp:
            raise AuthError("Pinterest refresh failed", platform=self.platform_id)
        return TokenBundle(
            platform=self.platform_id,
            account_id=bundle.account_id,
            access_token=resp["access_token"],
            refresh_token=resp.get("refresh_token", bundle.refresh_token),
            expires_at=token_expires_at({"expires_in": resp.get("expires_in", 2_592_000)}),
        )

    def _headers(self, bundle: TokenBundle) -> dict:
        return {"Authorization": f"Bearer {bundle.access_token}", "Content-Type": "application/json"}

    def fetch_account(self, bundle: TokenBundle) -> AccountInfo:
        resp = requests.get(f"{_API}/user_account",
            headers=self._headers(bundle), timeout=15).json()
        return AccountInfo(
            platform=self.platform_id,
            account_id=resp.get("username", ""),
            display_name=resp.get("display_name", resp.get("username", "")),
            username=resp.get("username", ""),
        )

    def media_spec(self) -> MediaSpec:
        return MediaSpec(
            platform=self.platform_id,
            max_duration_s=900,          # 15 min Idea Pins
            max_size_bytes=2 * 1024**3,  # 2 GB
            allowed_codecs=["h264"],
            allowed_containers=["mp4"],
            allowed_aspects=["2:3", "1:1", "9:16"],
            notes="2:3 or 9:16 vertical recommended for Idea Pins.",
        )

    def validate(self, request: UploadRequest) -> list[str]:
        return validate_file(request, self.media_spec())

    def upload(
        self,
        request: UploadRequest,
        bundle: TokenBundle,
        progress_callback: Callable[[int, int, str], None] | None = None,
        cancel_flag: threading.Event | None = None,
    ) -> UploadResult:
        errors = self.validate(request)
        if errors:
            raise ValidationError("; ".join(errors))

        # Pinterest v5 requires a media URL or file upload via multipart
        video_url = request.extra.get("video_url")
        board_id = request.extra.get("board_id", "")

        pin_body = {
            "board_id": board_id,
            "title": request.title,
            "description": request.description,
            "media_source": {
                "source_type": "video_url" if video_url else "video_id",
            },
        }
        if video_url:
            pin_body["media_source"]["url"] = video_url
        else:
            raise UploadError("Pinterest requires extra['video_url'] with a public video URL.")

        if progress_callback:
            progress_callback(0, 1, "Pinterest: creating pin…")

        resp = requests.post(f"{_API}/pins", json=pin_body,
            headers=self._headers(bundle), timeout=30).json()

        if "code" in resp and resp["code"] != 0:
            raise UploadError(f"Pinterest pin error: {resp.get('message', resp)}")

        pin_id = resp.get("id", "")
        post_url = f"https://www.pinterest.com/pin/{pin_id}/" if pin_id else ""
        return UploadResult(
            platform=self.platform_id, account_id=bundle.account_id,
            file_path=request.file_path, success=True,
            media_id=pin_id, post_url=post_url,
        )

    def max_concurrent(self) -> int:
        return 2
