"""Vimeo adapter: Tus resumable upload protocol."""

from __future__ import annotations

import os
import threading
import time
from typing import Callable

import requests

from ..base import AccountInfo, MediaSpec, SocialAdapter, TokenBundle, UploadRequest, UploadResult
from ..errors import AuthError, TransientError, UploadError, ValidationError
from ..oauth import token_expires_at
from ..validator import validate as validate_file
from ...log_setup import get_logger

log = get_logger(__name__)

_API = "https://api.vimeo.com"
_CHUNK_SIZE = 10 * 1024 * 1024   # 10 MB


class VimeoAdapter(SocialAdapter):
    platform_id = "vimeo"
    platform_name = "Vimeo"

    def __init__(self, client_id: str = "", client_secret: str = "", access_token: str = "") -> None:
        self._client_id = client_id or os.environ.get("VIMEO_CLIENT_ID", "")
        self._client_secret = client_secret or os.environ.get("VIMEO_CLIENT_SECRET", "")
        self._static_token = access_token or os.environ.get("VIMEO_ACCESS_TOKEN", "")

    def auth_url(self, state: str, redirect_uri: str) -> str:
        from urllib.parse import urlencode
        return (
            "https://api.vimeo.com/oauth/authorize?"
            + urlencode({
                "client_id": self._client_id,
                "redirect_uri": redirect_uri,
                "response_type": "code",
                "scope": "public private upload",
                "state": state,
            })
        )

    def exchange_code(self, code: str, state: str, redirect_uri: str) -> TokenBundle:
        resp = requests.post(f"{_API}/oauth/access_token", data={
            "grant_type": "authorization_code",
            "code": code,
            "redirect_uri": redirect_uri,
        }, auth=(self._client_id, self._client_secret), timeout=30).json()
        if "error" in resp:
            raise AuthError(f"Vimeo auth error: {resp.get('error_description', resp)}")
        return TokenBundle(
            platform=self.platform_id,
            account_id=str(resp.get("user", {}).get("uri", "").split("/")[-1]),
            access_token=resp["access_token"],
            expires_at=0.0,   # Vimeo tokens don't expire by default
        )

    def refresh_token(self, bundle: TokenBundle) -> TokenBundle:
        # Vimeo tokens are long-lived; re-auth if needed
        raise AuthError("Vimeo tokens don't expire; re-connect if invalid.", platform=self.platform_id)

    def fetch_account(self, bundle: TokenBundle) -> AccountInfo:
        token = bundle.access_token or self._static_token
        resp = requests.get(f"{_API}/me",
            headers={"Authorization": f"bearer {token}"}, timeout=15).json()
        return AccountInfo(
            platform=self.platform_id,
            account_id=str(resp.get("uri", "").split("/")[-1]),
            display_name=resp.get("name", ""),
            username=resp.get("link", "").split("vimeo.com/")[-1],
        )

    def media_spec(self) -> MediaSpec:
        return MediaSpec(
            platform=self.platform_id,
            max_duration_s=86_400,           # plan-dependent; 24h as safe max
            max_size_bytes=50 * 1024**3,     # plan-dependent; 50 GB
            allowed_codecs=["h264", "hevc", "vp9", "av1"],
            allowed_containers=["mp4", "mov", "mkv"],
            allowed_aspects=[],
            notes="Tus resumable upload; plan limits vary.",
        )

    def validate(self, request: UploadRequest) -> list[str]:
        return validate_file(request, self.media_spec())

    def upload(
        self,
        request: UploadRequest,
        bundle: TokenBundle,
        progress_callback: Callable[[int, int, str], None] | None = None,
        cancel_flag: threading.Event | None = None,
    ) -> UploadResult:
        errors = self.validate(request)
        if errors:
            raise ValidationError("; ".join(errors))

        file_path = request.file_path
        total_bytes = os.path.getsize(file_path)
        token = bundle.access_token or self._static_token
        auth_header = {"Authorization": f"bearer {token}"}

        # 1. Create video + get upload link
        create_resp = requests.post(f"{_API}/me/videos",
            json={
                "upload": {"approach": "tus", "size": total_bytes},
                "name": request.title or os.path.basename(file_path),
                "description": request.description,
                "privacy": {"view": request.visibility if request.visibility in
                             ("anybody", "nobody", "password") else "nobody"},
            },
            headers={**auth_header, "Content-Type": "application/json"}, timeout=30).json()

        if "error" in create_resp:
            raise UploadError(f"Vimeo create error: {create_resp.get('developer_message', create_resp)}")

        upload_link = create_resp["upload"]["upload_link"]
        video_uri = create_resp.get("uri", "")
        video_id = video_uri.split("/")[-1]

        # 2. Tus upload: PATCH with offset
        offset = 0
        with open(file_path, "rb") as fh:
            while offset < total_bytes:
                if cancel_flag and cancel_flag.is_set():
                    return UploadResult(platform=self.platform_id, account_id=bundle.account_id,
                                        file_path=file_path, success=False, error="cancelled")
                chunk = fh.read(_CHUNK_SIZE)
                patch_resp = requests.patch(upload_link,
                    data=chunk,
                    headers={
                        "Tus-Resumable": "1.0.0",
                        "Upload-Offset": str(offset),
                        "Content-Type": "application/offset+octet-stream",
                    }, timeout=120)
                if patch_resp.status_code not in (200, 204):
                    # Retrieve current offset for resume
                    head = requests.head(upload_link, headers={"Tus-Resumable": "1.0.0"}, timeout=15)
                    offset = int(head.headers.get("Upload-Offset", offset))
                    continue
                offset = int(patch_resp.headers.get("Upload-Offset", offset + len(chunk)))
                if progress_callback:
                    progress_callback(offset, total_bytes,
                        f"Uploading to Vimeo… {offset // 1_048_576} MB / {total_bytes // 1_048_576} MB")

        post_url = f"https://vimeo.com/{video_id}" if video_id else ""
        log.info("Vimeo upload complete: %s", post_url)
        return UploadResult(
            platform=self.platform_id, account_id=bundle.account_id,
            file_path=file_path, success=True,
            media_id=video_id, post_url=post_url,
        )

    def supports_resume(self) -> bool:
        return True

    def max_concurrent(self) -> int:
        return 2
