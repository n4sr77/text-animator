"""Threads (Meta) adapter: container + publish pattern."""

from __future__ import annotations

import os
import threading
import time
from typing import Callable

import requests

from ..base import AccountInfo, MediaSpec, SocialAdapter, TokenBundle, UploadRequest, UploadResult
from ..errors import AuthError, TransientError, UploadError, ValidationError
from ..oauth import token_expires_at
from ..validator import validate as validate_file
from ...log_setup import get_logger

log = get_logger(__name__)

_GRAPH = "https://graph.threads.net/v1.0"
_SCOPES = "threads_basic,threads_content_publish"


class ThreadsAdapter(SocialAdapter):
    platform_id = "threads"
    platform_name = "Threads"

    def __init__(self, app_id: str = "", app_secret: str = "") -> None:
        self._app_id = app_id or os.environ.get("THREADS_APP_ID", "")
        self._app_secret = app_secret or os.environ.get("THREADS_APP_SECRET", "")

    def auth_url(self, state: str, redirect_uri: str) -> str:
        from urllib.parse import urlencode
        return (
            "https://threads.net/oauth/authorize?"
            + urlencode({
                "client_id": self._app_id,
                "redirect_uri": redirect_uri,
                "scope": _SCOPES,
                "state": state,
                "response_type": "code",
            })
        )

    def exchange_code(self, code: str, state: str, redirect_uri: str) -> TokenBundle:
        resp = requests.post(f"{_GRAPH}/oauth/access_token", data={
            "client_id": self._app_id,
            "client_secret": self._app_secret,
            "grant_type": "authorization_code",
            "redirect_uri": redirect_uri,
            "code": code,
        }, timeout=30).json()
        if "error" in resp:
            raise AuthError(f"Threads auth error: {resp['error'].get('message', resp)}")
        return TokenBundle(
            platform=self.platform_id,
            account_id=str(resp.get("user_id", "")),
            access_token=resp["access_token"],
            expires_at=token_expires_at({"expires_in": resp.get("expires_in", 3600)}),
        )

    def refresh_token(self, bundle: TokenBundle) -> TokenBundle:
        resp = requests.get(f"{_GRAPH}/refresh_access_token", params={
            "grant_type": "th_refresh_token",
            "access_token": bundle.access_token,
        }, timeout=30).json()
        if "error" in resp:
            raise AuthError("Threads refresh failed", platform=self.platform_id)
        return TokenBundle(
            platform=self.platform_id,
            account_id=bundle.account_id,
            access_token=resp["access_token"],
            expires_at=token_expires_at({"expires_in": resp.get("expires_in", 5_184_000)}),
        )

    def fetch_account(self, bundle: TokenBundle) -> AccountInfo:
        resp = requests.get(f"{_GRAPH}/me",
            params={"fields": "id,username,name,threads_profile_picture_url",
                    "access_token": bundle.access_token}, timeout=15).json()
        return AccountInfo(
            platform=self.platform_id,
            account_id=resp.get("id", bundle.account_id),
            display_name=resp.get("name", ""),
            username=resp.get("username", ""),
            avatar_url=resp.get("threads_profile_picture_url", ""),
        )

    def media_spec(self) -> MediaSpec:
        return MediaSpec(
            platform=self.platform_id,
            max_duration_s=300,          # 5 min
            max_size_bytes=1024**3,      # 1 GB
            allowed_codecs=["h264"],
            allowed_containers=["mp4"],
            allowed_aspects=["9:16", "1:1", "16:9"],
            notes="H.264 MP4; vertical 9:16 preferred.",
        )

    def validate(self, request: UploadRequest) -> list[str]:
        return validate_file(request, self.media_spec())

    def upload(
        self,
        request: UploadRequest,
        bundle: TokenBundle,
        progress_callback: Callable[[int, int, str], None] | None = None,
        cancel_flag: threading.Event | None = None,
    ) -> UploadResult:
        errors = self.validate(request)
        if errors:
            raise ValidationError("; ".join(errors))

        video_url = request.extra.get("video_url")
        if not video_url:
            raise UploadError("Threads requires a public video URL in extra['video_url'].")

        user_id = bundle.account_id
        token = bundle.access_token

        # 1. Create container
        container_resp = requests.post(f"{_GRAPH}/{user_id}/threads",
            data={
                "media_type": "VIDEO",
                "video_url": video_url,
                "text": f"{request.title}\n{request.description}".strip(),
                "access_token": token,
            }, timeout=30).json()
        if "error" in container_resp:
            raise UploadError(f"Threads container error: {container_resp['error']['message']}")

        container_id = container_resp["id"]
        if progress_callback:
            progress_callback(1, 2, "Threads: waiting for video processing…")

        # 2. Poll
        deadline = time.monotonic() + 300
        while time.monotonic() < deadline:
            if cancel_flag and cancel_flag.is_set():
                return UploadResult(platform=self.platform_id, account_id=user_id,
                                    file_path=request.file_path, success=False, error="cancelled")
            status_resp = requests.get(f"{_GRAPH}/{container_id}",
                params={"fields": "status,error_message", "access_token": token},
                timeout=15).json()
            status = status_resp.get("status", "")
            if status == "FINISHED":
                break
            if status == "ERROR":
                raise UploadError(f"Threads processing error: {status_resp.get('error_message')}")
            time.sleep(5)
        else:
            raise TransientError("Threads container processing timeout")

        if progress_callback:
            progress_callback(2, 2, "Threads: publishing…")

        # 3. Publish
        pub_resp = requests.post(f"{_GRAPH}/{user_id}/threads_publish",
            data={"creation_id": container_id, "access_token": token}, timeout=30).json()
        if "error" in pub_resp:
            raise UploadError(f"Threads publish error: {pub_resp['error']['message']}")

        post_id = pub_resp.get("id", "")
        return UploadResult(
            platform=self.platform_id, account_id=user_id,
            file_path=request.file_path, success=True,
            media_id=post_id, post_url=f"https://www.threads.net/@{request.extra.get('username', '')}",
        )
