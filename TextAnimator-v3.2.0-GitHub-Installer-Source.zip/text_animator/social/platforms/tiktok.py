"""TikTok Content Posting API adapter for desktop direct publishing.

Desktop OAuth uses TikTok's PKCE variant (hex-encoded SHA-256 challenge).
Direct Post queries creator capabilities, uploads valid sequential chunks, and
polls the publish status endpoint rather than treating transfer completion as
publication success.
"""

from __future__ import annotations

import hashlib
import mimetypes
import os
import secrets
import threading
import time
from typing import Callable
from urllib.parse import urlencode

import requests

from ..base import AccountInfo, MediaSpec, SocialAdapter, TokenBundle, UploadRequest, UploadResult
from ..errors import AuthError, RateLimitError, TransientError, UploadError, ValidationError
from ..oauth import token_expires_at
from ..validator import validate as validate_file
from ...log_setup import get_logger

log = get_logger(__name__)

_AUTH_URL = "https://www.tiktok.com/v2/auth/authorize/"
_TOKEN_URL = "https://open.tiktokapis.com/v2/oauth/token/"
_CREATOR_INFO_URL = "https://open.tiktokapis.com/v2/post/publish/creator_info/query/"
_UPLOAD_URL = "https://open.tiktokapis.com/v2/post/publish/video/init/"
_STATUS_URL = "https://open.tiktokapis.com/v2/post/publish/status/fetch/"
_CHUNK_SIZE = 10_000_000  # decimal 10 MB, within TikTok's 5–64 MB chunk range
_MAX_CHUNKS = 1000
_STATUS_POLL_INTERVAL = 5.0
_STATUS_POLL_TIMEOUT = 120.0
_SCOPES = "user.info.basic,video.publish"
_PRIVACY_MAP = {
    "public": "PUBLIC_TO_EVERYONE",
    "private": "SELF_ONLY",
    # TikTok has no true unlisted mode; mutual-followers is the closest choice.
    "unlisted": "MUTUAL_FOLLOW_FRIENDS",
}


def _error_details(payload: dict) -> tuple[str, str]:
    error = payload.get("error", {}) if isinstance(payload, dict) else {}
    if isinstance(error, dict):
        return str(error.get("code", "")), str(error.get("message", ""))
    if error:
        return str(error), str(payload.get("error_description", ""))
    return "", ""


def _read_json_response(response, context: str) -> dict:
    """Decode TikTok's JSON response and translate API/HTTP failures."""
    try:
        payload = response.json()
    except (ValueError, TypeError) as exc:
        raise UploadError(
            f"TikTok {context} returned non-JSON HTTP {getattr(response, 'status_code', '?')}"
        ) from exc
    if not isinstance(payload, dict):
        raise UploadError(f"TikTok {context} returned an unexpected response")

    status = int(getattr(response, "status_code", 200) or 200)
    code, message = _error_details(payload)
    detail = f"{code}: {message}" if message else (code or str(payload)[:500])
    if status == 401 or code in ("access_token_invalid", "scope_not_authorized"):
        raise AuthError(f"TikTok {context} authorization failed ({detail})", platform="tiktok")
    if status == 429 or code == "rate_limit_exceeded":
        raise RateLimitError(f"TikTok {context} rate limit ({detail})", retry_after=60)
    if status >= 500:
        raise TransientError(f"TikTok {context} server error HTTP {status} ({detail})", retry_after=15)
    if status >= 400 or (code and code != "ok"):
        raise UploadError(f"TikTok {context} failed HTTP {status} ({detail})")
    return payload


def _chunk_layout(video_size: int, preferred_chunk_size: int = _CHUNK_SIZE) -> tuple[int, int]:
    """Return a TikTok-compliant (chunk_size, chunk_count) pair.

    TikTok requires a single request for files <=64 MB. For larger files,
    chunk_count is floor(video_size/chunk_size), with the final read consuming
    the remaining bytes so that the last chunk is never a tiny trailing piece.
    """
    if video_size <= 0:
        raise ValidationError("TikTok cannot upload an empty video file")
    if video_size <= 64_000_000:
        return video_size, 1
    chunk_size = min(max(preferred_chunk_size, 5_000_000), 64_000_000)
    chunk_count = video_size // chunk_size
    if chunk_count < 1 or chunk_count > _MAX_CHUNKS:
        raise ValidationError(
            f"TikTok upload needs {chunk_count} chunks; the API limit is {_MAX_CHUNKS}"
        )
    return chunk_size, chunk_count



def _build_caption(request: UploadRequest) -> str:
    """Combine the desktop title, description, and tags into TikTok's caption."""
    parts = [request.title.strip() or os.path.basename(request.file_path)]
    if request.description.strip():
        parts.append(request.description.strip())
    if request.tags:
        tags = [tag.strip() if tag.strip().startswith("#") else f"#{tag.strip()}"
                for tag in request.tags if tag.strip()]
        if tags:
            parts.append(" ".join(tags))
    caption = "\n".join(part for part in parts if part)
    utf16_units = len(caption.encode("utf-16-le")) // 2
    if utf16_units > 2200:
        raise ValidationError(
            f"TikTok captions are limited to 2,200 UTF-16 code units; this caption uses {utf16_units}."
        )
    return caption

class TikTokAdapter(SocialAdapter):
    platform_id = "tiktok"
    platform_name = "TikTok"

    def __init__(self, client_key: str = "", client_secret: str = "") -> None:
        self._client_key = client_key or os.environ.get("TIKTOK_CLIENT_KEY", "")
        self._client_secret = client_secret or os.environ.get("TIKTOK_CLIENT_SECRET", "")
        self._code_verifier = ""

    def auth_url(self, state: str, redirect_uri: str) -> str:
        if not self._client_key or not self._client_secret:
            raise AuthError(
                "TikTok Client Key and Client Secret are required. Open Publish → API Credentials…",
                platform=self.platform_id,
            )
        # TikTok's desktop Login Kit specifies a hex-encoded SHA-256 challenge.
        self._code_verifier = secrets.token_urlsafe(64)
        challenge = hashlib.sha256(self._code_verifier.encode("ascii")).hexdigest()
        params = {
            "client_key": self._client_key,
            "scope": _SCOPES,
            "response_type": "code",
            "redirect_uri": redirect_uri,
            "state": state,
            "code_challenge": challenge,
            "code_challenge_method": "S256",
        }
        return f"{_AUTH_URL}?{urlencode(params)}"

    def exchange_code(self, code: str, state: str, redirect_uri: str) -> TokenBundle:
        if not self._code_verifier:
            raise AuthError("TikTok PKCE verifier is missing. Restart account connection.", platform=self.platform_id)
        try:
            response = requests.post(_TOKEN_URL, data={
                "client_key": self._client_key,
                "client_secret": self._client_secret,
                "code": code,
                "grant_type": "authorization_code",
                "redirect_uri": redirect_uri,
                "code_verifier": self._code_verifier,
            }, timeout=30)
        except requests.RequestException as exc:
            raise AuthError(f"TikTok token exchange network error: {exc}", platform=self.platform_id) from exc
        payload = _read_json_response(response, "token exchange")
        data = payload.get("data", payload)
        access_token = data.get("access_token", "")
        if not access_token:
            raise AuthError("TikTok token exchange did not return an access token", platform=self.platform_id)
        self._code_verifier = ""  # discard the one-time verifier
        return TokenBundle(
            platform=self.platform_id,
            account_id=data.get("open_id", ""),
            access_token=access_token,
            refresh_token=data.get("refresh_token", ""),
            expires_at=token_expires_at({"expires_in": data.get("expires_in", 86400)}),
            extra={"scope": data.get("scope", "")},
        )

    def refresh_token(self, bundle: TokenBundle) -> TokenBundle:
        try:
            response = requests.post(_TOKEN_URL, data={
                "client_key": self._client_key,
                "client_secret": self._client_secret,
                "grant_type": "refresh_token",
                "refresh_token": bundle.refresh_token,
            }, timeout=30)
        except requests.RequestException as exc:
            raise TransientError(f"TikTok token refresh network error: {exc}", retry_after=15) from exc
        payload = _read_json_response(response, "token refresh")
        data = payload.get("data", payload)
        if not data.get("access_token"):
            raise AuthError("TikTok token refresh failed", platform=self.platform_id)
        return TokenBundle(
            platform=self.platform_id,
            account_id=bundle.account_id,
            access_token=data["access_token"],
            refresh_token=data.get("refresh_token", bundle.refresh_token),
            expires_at=token_expires_at({"expires_in": data.get("expires_in", 86400)}),
            extra={"scope": data.get("scope", bundle.extra.get("scope", ""))},
        )

    def _api_headers(self, bundle: TokenBundle) -> dict:
        return {
            "Authorization": f"Bearer {bundle.access_token}",
            "Content-Type": "application/json; charset=UTF-8",
        }

    def fetch_account(self, bundle: TokenBundle) -> AccountInfo:
        try:
            response = requests.get(
                "https://open.tiktokapis.com/v2/user/info/",
                headers=self._api_headers(bundle),
                params={"fields": "open_id,display_name,avatar_url"},
                timeout=15,
            )
        except requests.RequestException as exc:
            raise TransientError(f"TikTok account lookup failed: {exc}", retry_after=10) from exc
        payload = _read_json_response(response, "account lookup")
        data = payload.get("data", {}).get("user", {})
        if not data.get("open_id") and not bundle.account_id:
            raise AuthError("TikTok account lookup returned no open_id", platform=self.platform_id)
        return AccountInfo(
            platform=self.platform_id,
            account_id=data.get("open_id", bundle.account_id),
            display_name=data.get("display_name", ""),
            avatar_url=data.get("avatar_url", ""),
            scopes=[s for s in str(bundle.extra.get("scope", "")).split(",") if s],
        )

    def query_creator_info(self, bundle: TokenBundle) -> dict:
        """Fetch current TikTok creator capabilities required for Direct Post."""
        try:
            response = requests.post(
                _CREATOR_INFO_URL,
                headers=self._api_headers(bundle),
                timeout=20,
            )
        except requests.RequestException as exc:
            raise TransientError(f"TikTok creator-info request failed: {exc}", retry_after=10) from exc
        payload = _read_json_response(response, "creator-info query")
        data = payload.get("data", {})
        if not data.get("privacy_level_options"):
            raise UploadError("TikTok creator-info response omitted privacy_level_options")
        return data

    def fetch_publish_status(self, bundle: TokenBundle, publish_id: str) -> dict:
        """Fetch the current state of an accepted TikTok publish request."""
        if not publish_id:
            raise ValueError("publish_id is required")
        try:
            response = requests.post(
                _STATUS_URL,
                json={"publish_id": publish_id},
                headers=self._api_headers(bundle),
                timeout=20,
            )
        except requests.RequestException as exc:
            raise TransientError(f"TikTok status request failed: {exc}", retry_after=10) from exc
        payload = _read_json_response(response, "publish-status query")
        return payload.get("data", {})

    def media_spec(self) -> MediaSpec:
        return MediaSpec(
            platform=self.platform_id,
            max_duration_s=600,
            max_size_bytes=4 * 1024**3,
            allowed_codecs=["h264", "h265"],
            allowed_containers=["mp4", "mov", "webm"],
            allowed_aspects=["9:16", "1:1", "16:9"],
            min_width=360,
            min_height=360,
            notes="Direct Post; creator-specific duration/privacy limits also apply.",
        )

    def validate(self, request: UploadRequest) -> list[str]:
        errors = validate_file(request, self.media_spec())
        try:
            _build_caption(request)
        except ValidationError as exc:
            errors.append(str(exc))
        return errors

    def _poll_status(
        self,
        bundle: TokenBundle,
        publish_id: str,
        progress_callback: Callable[[int, int, str], None] | None,
        cancel_flag: threading.Event | None,
    ) -> tuple[str, dict]:
        deadline = time.monotonic() + _STATUS_POLL_TIMEOUT
        last_data: dict = {}
        while True:
            # Once TikTok has issued a publish_id, cancelling locally cannot
            # retract the platform-side post. Do not report it as cancelled.
            if cancel_flag and cancel_flag.is_set():
                return "PROCESSING", {**last_data, "local_cancel_requested": True}
            try:
                last_data = self.fetch_publish_status(bundle, publish_id)
            except (RateLimitError, TransientError) as exc:
                # Retrying the entire upload would create a second post. Keep
                # the publish_id visible and let the user query status later.
                return "PROCESSING_UNCONFIRMED", {**last_data, "status_check_error": str(exc)}
            status = str(last_data.get("status", "")).upper()
            if status in ("PUBLISH_COMPLETE", "FAILED"):
                return status, last_data
            if progress_callback:
                progress_callback(0, 0, f"TikTok processing… {status or 'checking status'}")
            if time.monotonic() >= deadline:
                return status or "PROCESSING", last_data
            time.sleep(min(_STATUS_POLL_INTERVAL, max(0.0, deadline - time.monotonic())))

    def upload(
        self,
        request: UploadRequest,
        bundle: TokenBundle,
        progress_callback: Callable[[int, int, str], None] | None = None,
        cancel_flag: threading.Event | None = None,
    ) -> UploadResult:
        errors = self.validate(request)
        if errors:
            raise ValidationError("; ".join(errors))

        file_path = request.file_path
        total_bytes = os.path.getsize(file_path)
        chunk_size, chunk_count = _chunk_layout(total_bytes)
        headers = self._api_headers(bundle)

        # TikTok requires this query before showing Direct Post controls and
        # uses the returned privacy choices to validate the actual post.
        creator = self.query_creator_info(bundle)
        privacy_level = request.extra.get("privacy_level") or _PRIVACY_MAP.get(
            request.visibility, "SELF_ONLY"
        )
        allowed_privacy = creator.get("privacy_level_options", [])
        if privacy_level not in allowed_privacy:
            raise ValidationError(
                f"TikTok privacy level {privacy_level} is unavailable for this creator. "
                f"Available choices: {', '.join(allowed_privacy)}"
            )

        max_duration = creator.get("max_video_post_duration_sec")
        if max_duration:
            from ..validator import probe
            media_info = probe(file_path)
            if media_info["duration"] > float(max_duration):
                raise ValidationError(
                    f"This TikTok account allows videos up to {int(max_duration)} seconds; "
                    f"the selected video is {media_info['duration']:.1f} seconds."
                )

        init_payload = {
            "post_info": {
                "title": _build_caption(request),
                "privacy_level": privacy_level,
                "disable_duet": bool(request.extra.get("disable_duet", False)) or bool(creator.get("duet_disabled", False)),
                "disable_comment": bool(request.extra.get("disable_comment", False)) or bool(creator.get("comment_disabled", False)),
                "disable_stitch": bool(request.extra.get("disable_stitch", False)) or bool(creator.get("stitch_disabled", False)),
                "video_cover_timestamp_ms": int(request.extra.get("video_cover_timestamp_ms", 0)),
                "brand_content_toggle": bool(request.extra.get("brand_content_toggle", False)),
                "brand_organic_toggle": bool(request.extra.get("brand_organic_toggle", False)),
                "is_aigc": bool(request.extra.get("is_aigc", False)),
            },
            "source_info": {
                "source": "FILE_UPLOAD",
                "video_size": total_bytes,
                "chunk_size": chunk_size,
                "total_chunk_count": chunk_count,
            },
        }
        try:
            init_response = requests.post(
                _UPLOAD_URL, json=init_payload, headers=headers, timeout=30
            )
        except requests.RequestException as exc:
            # The server may have accepted the init request despite a lost
            # response; an automatic retry could create a duplicate post.
            raise UploadError(
                "TikTok upload initialization response was lost. Check the TikTok account "
                "before retrying to avoid a duplicate post."
            ) from exc
        try:
            init_payload_response = _read_json_response(init_response, "upload initialization")
        except TransientError as exc:
            raise UploadError(
                f"TikTok upload initialization returned an uncertain server response ({exc}). "
                "Verify TikTok before retrying to avoid a duplicate post."
            ) from exc
        init_data = init_payload_response.get("data", {})
        publish_id = init_data.get("publish_id", "")
        upload_url = init_data.get("upload_url", "")
        if not publish_id or not upload_url:
            raise UploadError("TikTok upload initialization did not return publish_id and upload_url")

        mime_type = mimetypes.guess_type(file_path)[0] or "video/mp4"
        uploaded = 0
        with open(file_path, "rb") as handle:
            for chunk_index in range(chunk_count):
                if cancel_flag and cancel_flag.is_set():
                    return UploadResult(
                        platform=self.platform_id, account_id=bundle.account_id,
                        file_path=file_path, success=False, media_id=publish_id,
                        status="cancelled", error="cancelled",
                    )
                # All chunks except the final one have chunk_size bytes. The
                # final one absorbs the entire remainder, as required by TikTok.
                bytes_this_chunk = chunk_size if chunk_index < chunk_count - 1 else total_bytes - uploaded
                chunk_data = handle.read(bytes_this_chunk)
                if len(chunk_data) != bytes_this_chunk:
                    raise UploadError("Video file ended unexpectedly during TikTok upload")
                start = uploaded
                end = start + len(chunk_data) - 1
                chunk_headers = {
                    "Content-Range": f"bytes {start}-{end}/{total_bytes}",
                    "Content-Length": str(len(chunk_data)),
                    "Content-Type": mime_type,
                }
                try:
                    chunk_response = requests.put(
                        upload_url, data=chunk_data, headers=chunk_headers, timeout=180
                    )
                except requests.RequestException as exc:
                    return UploadResult(
                        platform=self.platform_id, account_id=bundle.account_id,
                        file_path=file_path, success=False, media_id=publish_id,
                        status="processing",
                        error=(f"TikTok upload connection was interrupted after initialization "
                               f"(chunk {chunk_index + 1}). Check publish status before retrying; "
                               f"publish_id={publish_id}. Details: {exc}"),
                    )
                code = int(getattr(chunk_response, "status_code", 0) or 0)
                if code not in (200, 201, 206):
                    if code == 401:
                        raise AuthError("TikTok upload URL authorization failed", platform=self.platform_id)
                    if code == 429 or code >= 500:
                        return UploadResult(
                            platform=self.platform_id, account_id=bundle.account_id,
                            file_path=file_path, success=False, media_id=publish_id,
                            status="processing",
                            error=(f"TikTok chunk {chunk_index + 1} returned HTTP {code}; "
                                   f"the remote upload state is uncertain. Check status before "
                                   f"retrying; publish_id={publish_id}"),
                        )
                    raise UploadError(
                        f"TikTok chunk {chunk_index + 1} failed: HTTP {code} "
                        f"{getattr(chunk_response, 'text', '')[:300]}"
                    )
                uploaded = end + 1
                if progress_callback:
                    progress_callback(
                        uploaded, total_bytes,
                        f"Uploading to TikTok… {uploaded // 1_048_576} MB / "
                        f"{total_bytes // 1_048_576} MB",
                    )

        log.info("TikTok video transferred; checking publish status id=%s", publish_id)
        status, status_data = self._poll_status(
            bundle, publish_id, progress_callback, cancel_flag
        )
        if status == "CANCELLED":  # kept for compatibility with older callers
            status = "PROCESSING"
        if status == "FAILED":
            fail_reason = status_data.get("fail_reason", "TikTok rejected the post")
            raise UploadError(f"TikTok publishing failed: {fail_reason} (publish_id={publish_id})")
        if status != "PUBLISH_COMPLETE":
            return UploadResult(
                platform=self.platform_id, account_id=bundle.account_id,
                file_path=file_path, success=False, media_id=publish_id,
                status="processing",
                error=(f"TikTok accepted the video but publication is not yet confirmed. "
                       f"{status_data.get('status_check_error', '')} "
                       f"Check status before retrying; publish_id={publish_id}"),
            )

        post_ids = status_data.get("publicaly_available_post_id", []) or []
        username = creator.get("creator_username", "")
        post_url = (
            f"https://www.tiktok.com/@{username}/video/{post_ids[0]}"
            if post_ids and username else (f"https://www.tiktok.com/@{username}" if username else "")
        )
        return UploadResult(
            platform=self.platform_id, account_id=bundle.account_id,
            file_path=file_path, success=True, media_id=publish_id,
            post_url=post_url,
            status="published",
        )

    def supports_resume(self) -> bool:
        # The current adapter starts a fresh publish init for each retry; it
        # does not persist upload_url/chunk offsets, so claiming resume would
        # be misleading to the upload scheduler.
        return False
