"""X / Twitter adapter using tweepy v2 (INIT/APPEND/FINALIZE chunked media)."""

from __future__ import annotations

import os
import threading
import time
from typing import Callable

from ..base import AccountInfo, MediaSpec, SocialAdapter, TokenBundle, UploadRequest, UploadResult
from ..errors import AuthError, RateLimitError, TransientError, UploadError, ValidationError
from ..oauth import token_expires_at
from ..validator import validate as validate_file
from ...log_setup import get_logger

log = get_logger(__name__)

_CHUNK_SIZE = 5 * 1024 * 1024   # 5 MB
_MEDIA_UPLOAD_URL = "https://upload.twitter.com/1.1/media/upload.json"


class XTwitterAdapter(SocialAdapter):
    platform_id = "x_twitter"
    platform_name = "X / Twitter"

    def __init__(self, api_key: str = "", api_secret: str = "",
                 client_id: str = "", client_secret: str = "") -> None:
        self._api_key = api_key or os.environ.get("TWITTER_API_KEY", "")
        self._api_secret = api_secret or os.environ.get("TWITTER_API_SECRET", "")
        self._client_id = client_id or os.environ.get("TWITTER_CLIENT_ID", "")
        self._client_secret = client_secret or os.environ.get("TWITTER_CLIENT_SECRET", "")

    def auth_url(self, state: str, redirect_uri: str) -> str:
        import tweepy  # type: ignore
        oauth2 = tweepy.OAuth2UserHandler(
            client_id=self._client_id,
            redirect_uri=redirect_uri,
            scope=["tweet.write", "tweet.read", "users.read", "offline.access"],
            client_secret=self._client_secret,
        )
        url, _ = oauth2.get_authorization_url()
        return url

    def exchange_code(self, code: str, state: str, redirect_uri: str) -> TokenBundle:
        import tweepy  # type: ignore
        oauth2 = tweepy.OAuth2UserHandler(
            client_id=self._client_id,
            redirect_uri=redirect_uri,
            scope=["tweet.write", "tweet.read", "users.read", "offline.access"],
            client_secret=self._client_secret,
        )
        token_resp = oauth2.fetch_token(f"{redirect_uri}?code={code}&state={state}")
        return TokenBundle(
            platform=self.platform_id,
            account_id="",
            access_token=token_resp.get("access_token", ""),
            refresh_token=token_resp.get("refresh_token", ""),
            expires_at=token_expires_at({"expires_in": token_resp.get("expires_in", 7200)}),
        )

    def refresh_token(self, bundle: TokenBundle) -> TokenBundle:
        import tweepy  # type: ignore
        oauth2 = tweepy.OAuth2UserHandler(
            client_id=self._client_id,
            redirect_uri="",
            scope=[],
            client_secret=self._client_secret,
        )
        token_resp = oauth2.refresh_token(
            "https://api.twitter.com/2/oauth2/token",
            refresh_token=bundle.refresh_token,
        )
        return TokenBundle(
            platform=self.platform_id,
            account_id=bundle.account_id,
            access_token=token_resp.get("access_token", ""),
            refresh_token=token_resp.get("refresh_token", bundle.refresh_token),
            expires_at=token_expires_at({"expires_in": token_resp.get("expires_in", 7200)}),
        )

    def _client(self, bundle: TokenBundle):
        import tweepy  # type: ignore
        return tweepy.Client(access_token=bundle.access_token,
                             consumer_key=self._api_key, consumer_secret=self._api_secret)

    def fetch_account(self, bundle: TokenBundle) -> AccountInfo:
        client = self._client(bundle)
        me = client.get_me(user_fields=["profile_image_url", "name", "username"])
        user = me.data
        return AccountInfo(
            platform=self.platform_id,
            account_id=str(user.id),
            display_name=user.name,
            username=user.username,
            avatar_url=user.profile_image_url or "",
        )

    def media_spec(self) -> MediaSpec:
        return MediaSpec(
            platform=self.platform_id,
            max_duration_s=140,              # 2 min 20 s
            max_size_bytes=512 * 1024**2,    # 512 MB
            allowed_codecs=["h264"],
            allowed_containers=["mp4", "mov"],
            allowed_aspects=[],
            max_fps=60.0,
            notes="H.264 MP4; ≤ 2 min 20 s; ≤ 512 MB.",
        )

    def validate(self, request: UploadRequest) -> list[str]:
        return validate_file(request, self.media_spec())

    def upload(
        self,
        request: UploadRequest,
        bundle: TokenBundle,
        progress_callback: Callable[[int, int, str], None] | None = None,
        cancel_flag: threading.Event | None = None,
    ) -> UploadResult:
        import tweepy  # type: ignore

        errors = self.validate(request)
        if errors:
            raise ValidationError("; ".join(errors))

        file_path = request.file_path
        total_bytes = os.path.getsize(file_path)

        # OAuth1 for media upload endpoint (v1.1 requirement)
        auth = tweepy.OAuth1UserHandler(self._api_key, self._api_secret)
        auth.set_access_token(bundle.access_token, bundle.extra.get("access_secret", ""))
        api = tweepy.API(auth)

        # INIT
        init = api.media_upload(filename=file_path,
                                media_category="tweet_video",
                                media_type="video/mp4",
                                chunked=True)
        media_id = init.media_id_string

        if progress_callback:
            progress_callback(0, total_bytes, "X/Twitter: media upload initiated")

        # Wait for processing
        for _ in range(30):
            if cancel_flag and cancel_flag.is_set():
                return UploadResult(platform=self.platform_id, account_id=bundle.account_id,
                                    file_path=file_path, success=False, error="cancelled")
            info = api.get_media_upload_status(media_id)
            state = info.processing_info.get("state") if hasattr(info, "processing_info") else "succeeded"
            if state == "succeeded":
                break
            if state == "failed":
                raise UploadError("X/Twitter media processing failed")
            time.sleep(info.processing_info.get("check_after_secs", 5))

        if progress_callback:
            progress_callback(total_bytes, total_bytes, "X/Twitter: posting tweet…")

        # Post tweet
        client = self._client(bundle)
        text = request.title or request.description or ""
        tweet = client.create_tweet(text=text, media_ids=[media_id])
        tweet_id = tweet.data["id"]
        post_url = f"https://x.com/i/status/{tweet_id}"

        return UploadResult(
            platform=self.platform_id, account_id=bundle.account_id,
            file_path=file_path, success=True,
            media_id=media_id, post_url=post_url,
        )
