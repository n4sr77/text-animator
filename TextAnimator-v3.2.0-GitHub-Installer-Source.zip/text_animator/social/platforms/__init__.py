"""Platform adapter implementations."""
