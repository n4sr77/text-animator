"""Batch generation from CSV files – enhanced with rich per-row overrides.

Expected CSV columns (case-insensitive, flexible names):
  Required (one of each group):
    title | name | id | filename | slug
    sentence | text | content | body | line | quote

  Optional overrides (any combination):
    preset, color_mode, font_size, font, word_duration, gap, end_hold,
    fps, outline, shadow, resolution, transition, bg_image, audio
"""

from __future__ import annotations

import csv
import re
from pathlib import Path
from typing import Callable, Any

from .renderer import VideoRenderer, RenderCancelled
from .audio_library import RandomAudioPool
from .config import RESOLUTIONS, COLOR_MODES


TITLE_KEYS = {"title", "name", "id", "filename", "slug"}
TEXT_KEYS = {"sentence", "text", "content", "body", "line", "quote"}

# All optional override keys we recognise (normalized)
OPTIONAL_KEYS = {
    "preset", "color_mode", "font_size", "font", "word_duration", "gap",
    "end_hold", "fps", "outline", "outline_width", "shadow", "shadow_offset",
    "auto_fit_font", "resolution", "transition", "transition_duration",
    "bg_image", "encode_preset", "hardware_backend", "audio", "audio_volume",
    "audio_fade_in", "audio_fade_out", "filename",
}

BOOL_TRUE = {"1", "true", "yes", "y", "on"}
BOOL_FALSE = {"0", "false", "no", "n", "off"}


def _normalize_header(h: str) -> str:
    return re.sub(r"\s+", "_", h.strip().lower())


def load_csv_rows(csv_path: str) -> list[dict]:
    """Load CSV and return list of normalized row dicts."""
    rows = []
    with open(csv_path, newline="", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        if not reader.fieldnames:
            raise ValueError("CSV has no header row")
        header_map = {h: _normalize_header(h) for h in reader.fieldnames}
        for raw in reader:
            row = {header_map[k]: (v or "").strip() for k, v in raw.items() if k}
            rows.append(row)
    return rows


def _pick(row: dict, keys: set[str], default: str = "") -> str:
    for k in keys:
        if k in row and row[k]:
            return row[k]
    return default


def _as_bool(val: str | None, default: bool = False) -> bool:
    if val is None or val == "":
        return default
    v = val.strip().lower()
    if v in BOOL_TRUE:
        return True
    if v in BOOL_FALSE:
        return False
    return default


def _as_float(val: str | None, default: float) -> float:
    if val is None or val == "":
        return default
    try:
        return float(val)
    except ValueError:
        return default


def _as_int(val: str | None, default: int) -> int:
    if val is None or val == "":
        return default
    try:
        return int(float(val))
    except ValueError:
        return default


def _normalize_encode_preset(value: str | None, default: str) -> str:
    if not value:
        return default
    candidate = value.strip().lower()
    aliases = {
        "medium (balanced)": "medium", "slow (better quality)": "slow",
    }
    candidate = aliases.get(candidate, candidate)
    return candidate if candidate in {"ultrafast", "fast", "medium", "slow"} else default


def _normalize_hardware_backend(value: str | None, default: str) -> str:
    if not value:
        return default
    candidate = value.strip().lower()
    aliases = {"nvenc": "nvidia", "qsv": "intel", "software": "cpu"}
    candidate = aliases.get(candidate, candidate)
    return candidate if candidate in {"auto", "nvidia", "intel", "cpu"} else default


def safe_filename(name: str, max_len: int = 80) -> str:
    name = re.sub(r"[^\w\s\-]", "", name, flags=re.UNICODE)
    name = re.sub(r"\s+", "_", name.strip())
    return name[:max_len] or "untitled"


def resolve_resolution(label_or_pair: str, default: tuple[int, int]) -> tuple[int, int]:
    """Accept a known label or 'WIDTHxHEIGHT' string."""
    if not label_or_pair:
        return default
    s = label_or_pair.strip().lower()
    for k, v in RESOLUTIONS.items():
        if s == k.lower() or s == f"{v[0]}x{v[1]}":
            return v
    m = re.match(r"^(\d+)\s*[x×]\s*(\d+)$", s)
    if m:
        return int(m.group(1)), int(m.group(2))
    return default


def validate_rows(rows: list[dict]) -> list[str]:
    """Return list of human-readable warnings / errors for the loaded rows."""
    warnings = []
    if not rows:
        warnings.append("CSV contains no data rows.")
        return warnings
    for i, row in enumerate(rows, 1):
        title = _pick(row, TITLE_KEYS, default="")
        text = _pick(row, TEXT_KEYS)
        if not text:
            warnings.append(f"Row {i}: empty text (title={title or '—'}) — will be skipped.")
        if row.get("color_mode") and row["color_mode"] not in COLOR_MODES:
            warnings.append(f"Row {i}: unknown color_mode '{row['color_mode']}' — will use default.")
        if row.get("preset"):
            # soft check only
            pass
    return warnings


SAMPLE_CSV_CONTENT = """title,sentence,preset,color_mode,font,font_size,word_duration,gap,end_hold,fps,outline,outline_width,shadow,shadow_offset,auto_fit_font,resolution,transition,transition_duration,bg_image,encode_preset,hardware_backend,audio,audio_volume,audio_fade_in,audio_fade_out
Quote One,Words become motion,classic,white_on_black,,90,0.85,0.08,1.2,30,false,3,false,4,true,1280x720,fade,0.25,,medium,auto,,0.85,0.15,0.25
Quote Two,Stay hungry stay foolish,typewriter,white_on_black,,85,0.7,0.05,1.0,30,true,4,false,4,true,1080x1920,fade,0.25,,fast,auto,,0.85,0.15,0.25
Quote Three,The only way to do great work is to love what you do,pop_hold,black_on_white,,80,0.9,0.1,1.5,30,false,3,true,5,true,1920x1080,cut,0.0,,medium,auto,,0.85,0.15,0.25
"""


class BatchRenderer:
    """Render many videos from a CSV with rich per-row overrides."""

    def __init__(self):
        self.renderer = VideoRenderer()
        self._last_results: list[dict[str, Any]] = []

    def cancel(self):
        self.renderer.cancel()

    @property
    def last_results(self) -> list[dict[str, Any]]:
        return list(self._last_results)

    def run(
        self,
        csv_path: str,
        output_dir: str,
        *,
        default_preset: str = "classic",
        default_size: tuple[int, int] = (1280, 720),
        default_font: str = "",
        default_font_size: int = 90,
        default_color_mode: str = "white_on_black",
        default_word_duration: float = 0.85,
        default_gap: float = 0.08,
        default_end_hold: float = 1.2,
        default_fps: int = 30,
        outline: bool = False,
        shadow: bool = False,
        outline_width: int = 3,
        shadow_offset: int = 4,
        bg_image_path: str | None = None,
        auto_fit_font: bool = True,
        encode_preset: str = "medium",
        transition: str = "fade",
        transition_duration: float = 0.25,
        audio_path: str | None = None,
        audio_mode: str = "fixed",
        audio_folder: str | None = None,
        fixed_audio_path: str | None = None,
        hardware_backend: str = "auto",
        audio_volume: float = 0.85,
        audio_fade_in: float = 0.15,
        audio_fade_out: float = 0.25,
        skip_existing: bool = True,
        variants_per_row: int = 1,
        progress_callback: Callable[[int, int, str], None] | None = None,
        row_status_callback: Callable[[int, str, str], None] | None = None,
    ) -> list[str]:
        """Render each CSV row, optionally creating multiple animation-preset variants."""
        from .presets import PRESET_NAMES

        rows = load_csv_rows(csv_path)
        if not rows:
            raise ValueError("CSV has no data rows")
        variants_per_row = max(1, min(20, int(variants_per_row)))
        audio_mode = (audio_mode or "fixed").strip().lower()
        if audio_mode not in {"fixed", "random", "none"}:
            raise ValueError("Audio mode must be 'fixed', 'random' or 'none'.")
        has_unassigned_audio = any(not (row.get("audio") or "").strip() for row in rows)
        random_audio = (
            RandomAudioPool(audio_folder)
            if audio_mode == "random" and not fixed_audio_path and has_unassigned_audio
            else None
        )
        if fixed_audio_path and not Path(fixed_audio_path).expanduser().is_file():
            raise FileNotFoundError(f"Fixed batch soundtrack not found: {fixed_audio_path}")
        out_dir = Path(output_dir)
        out_dir.mkdir(parents=True, exist_ok=True)

        results: list[str] = []
        self._last_results = []
        total = len(rows) * variants_per_row
        progress_index = 0

        for row_index, row in enumerate(rows, 1):
            title = _pick(row, TITLE_KEYS, default=f"row_{row_index}")
            text = _pick(row, TEXT_KEYS)
            if not text:
                for _ in range(variants_per_row):
                    progress_index += 1
                    if progress_callback:
                        progress_callback(progress_index, total, f"Skip empty text: {title}")
                if row_status_callback:
                    row_status_callback(row_index, "skipped", f"Skip empty text: {title}")
                self._last_results.append({
                    "index": row_index, "title": title, "status": "skipped",
                    "path": None, "error": "empty text",
                })
                continue

            # Per-row overrides.
            base_preset = (row.get("preset") or default_preset).strip().lower()
            if base_preset not in PRESET_NAMES:
                base_preset = default_preset if default_preset in PRESET_NAMES else "classic"
            color_mode = (row.get("color_mode") or default_color_mode).strip()
            if color_mode not in COLOR_MODES:
                color_mode = default_color_mode
            font_size = _as_int(row.get("font_size"), default_font_size)
            font = (row.get("font") or default_font or "").strip()
            word_duration = _as_float(row.get("word_duration"), default_word_duration)
            gap = _as_float(row.get("gap"), default_gap)
            end_hold = _as_float(row.get("end_hold"), default_end_hold)
            fps = max(10, min(120, _as_int(row.get("fps"), default_fps)))
            row_outline = _as_bool(row.get("outline"), outline)
            row_shadow = _as_bool(row.get("shadow"), shadow)
            size = resolve_resolution(row.get("resolution") or "", default_size)
            row_transition = (row.get("transition") or transition).strip().lower()
            if row_transition not in ("fade", "cut", "zoom"):
                row_transition = transition
            row_transition_duration = min(1.5, max(0.0, _as_float(
                row.get("transition_duration"), transition_duration
            )))
            row_outline_width = min(16, max(1, _as_int(row.get("outline_width"), outline_width)))
            row_shadow_offset = min(24, max(1, _as_int(row.get("shadow_offset"), shadow_offset)))
            row_auto_fit_font = _as_bool(row.get("auto_fit_font"), auto_fit_font)
            row_encode_preset = _normalize_encode_preset(row.get("encode_preset"), encode_preset)
            row_hardware_backend = _normalize_hardware_backend(row.get("hardware_backend"), hardware_backend)
            row_audio_volume = min(1.0, max(0.0, _as_float(row.get("audio_volume"), audio_volume)))
            row_audio_fade_in = min(10.0, max(0.0, _as_float(row.get("audio_fade_in"), audio_fade_in)))
            row_audio_fade_out = min(10.0, max(0.0, _as_float(row.get("audio_fade_out"), audio_fade_out)))

            row_bg = (row.get("bg_image") or "").strip() or bg_image_path
            if row_bg and not Path(row_bg).is_file():
                row_bg = bg_image_path
            # An explicit CSV soundtrack always wins over random selection.
            # This is the deterministic per-row override requested by users.
            csv_audio = (row.get("audio") or "").strip()
            if csv_audio.lower() in {"none", "silent", "off", "-"}:
                row_audio = None
            elif csv_audio:
                # Relative CSV paths are anchored to the CSV file, not the process CWD.
                csv_audio_path = Path(csv_audio).expanduser()
                if not csv_audio_path.is_absolute():
                    csv_relative = Path(csv_path).expanduser().resolve().parent / csv_audio_path
                    if csv_relative.is_file():
                        csv_audio_path = csv_relative
                row_audio = str(csv_audio_path.resolve())  # bad paths surface as row render errors
            elif audio_mode == "none":
                row_audio = None
            elif fixed_audio_path:
                row_audio = str(Path(fixed_audio_path).expanduser())
            elif audio_mode == "random":
                row_audio = random_audio.next() if random_audio else None
            else:
                row_audio = audio_path

            explicit_name = (row.get("filename") or "").strip()
            base_name = Path(explicit_name).stem if explicit_name else title
            base_name = safe_filename(base_name)
            preset_cycle = [base_preset] + [p for p in PRESET_NAMES if p != base_preset]
            row_errors: list[str] = []
            row_done = 0
            row_skipped = 0

            for variant_index in range(variants_per_row):
                if self.renderer._cancel.is_set():
                    raise RenderCancelled("Batch cancelled")
                progress_index += 1
                preset = preset_cycle[variant_index % len(preset_cycle)]
                fname = f"{base_name}.mp4" if variants_per_row == 1 else f"{base_name}_v{variant_index + 1:02d}_{preset}.mp4"
                out_path = str(out_dir / fname)

                if skip_existing and Path(out_path).is_file():
                    row_skipped += 1
                    self._last_results.append({
                        "index": row_index, "title": title, "variant": variant_index + 1,
                        "preset": preset, "status": "skipped", "path": out_path, "error": None,
                    })
                    if progress_callback:
                        progress_callback(progress_index, total, f"Skip existing: {fname}")
                    if row_status_callback:
                        row_status_callback(row_index, "running", f"Existing variant: {fname}")
                    continue

                if progress_callback:
                    progress_callback(progress_index - 1, total,
                                      f"Rendering {progress_index}/{total}: {title} — {preset}")
                if row_status_callback:
                    row_status_callback(row_index, "running", f"Rendering variant {variant_index + 1}/{variants_per_row}")

                try:
                    self.renderer.render_to_file(
                        text, out_path, preset_name=preset, size=size,
                        font_name_or_path=font, font_size=font_size,
                        color_mode=color_mode, word_duration=word_duration,
                        gap=gap, end_hold=end_hold, fps=fps,
                        outline=row_outline, shadow=row_shadow,
                        outline_width=row_outline_width, shadow_offset=row_shadow_offset,
                        bg_image_path=row_bg, auto_fit_font=row_auto_fit_font,
                        encode_preset=row_encode_preset, hardware_backend=row_hardware_backend,
                        transition=row_transition, transition_duration=row_transition_duration,
                        audio_path=row_audio, audio_volume=row_audio_volume,
                        audio_fade_in=row_audio_fade_in, audio_fade_out=row_audio_fade_out,
                    )
                    results.append(out_path)
                    row_done += 1
                    self._last_results.append({
                        "index": row_index, "title": title, "variant": variant_index + 1,
                        "preset": preset, "status": "done", "path": out_path,
                        "audio_path": row_audio, "error": None,
                    })
                except RenderCancelled:
                    self._last_results.append({
                        "index": row_index, "title": title, "variant": variant_index + 1,
                        "preset": preset, "status": "cancelled", "path": None, "error": "cancelled",
                    })
                    if row_status_callback:
                        row_status_callback(row_index, "error", "Cancelled")
                    raise
                except Exception as exc:
                    error = str(exc)
                    row_errors.append(error)
                    self._last_results.append({
                        "index": row_index, "title": title, "variant": variant_index + 1,
                        "preset": preset, "status": "error", "path": None, "error": error,
                    })
                    if progress_callback:
                        progress_callback(progress_index, total, f"Error on {title} ({preset}): {error}")

                if progress_callback:
                    progress_callback(progress_index, total, f"Finished {progress_index}/{total}: {title}")

            if row_status_callback:
                if row_errors:
                    row_status_callback(row_index, "error", row_errors[-1][:120])
                elif row_done:
                    row_status_callback(row_index, "done", f"{row_done} variant(s) rendered")
                elif row_skipped:
                    row_status_callback(row_index, "skipped", f"{row_skipped} existing variant(s)")

        return results

