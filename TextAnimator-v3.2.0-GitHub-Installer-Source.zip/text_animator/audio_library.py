"""Audio-folder discovery and cycle-random track selection."""

from __future__ import annotations

import random
from pathlib import Path

AUDIO_EXTENSIONS = {
    ".mp3", ".wav", ".m4a", ".aac", ".flac", ".ogg", ".opus",
    ".aiff", ".aif", ".wma", ".alac",
}


def discover_audio_files(folder: str | Path, *, recursive: bool = True) -> list[str]:
    root = Path(folder).expanduser()
    if not root.is_dir():
        return []
    iterator = root.rglob("*") if recursive else root.iterdir()
    return [str(p.resolve()) for p in sorted(iterator, key=lambda p: str(p).casefold())
            if p.is_file() and p.suffix.lower() in AUDIO_EXTENSIONS]


class RandomAudioPool:
    """Select randomly without repeats until every eligible file has been used."""

    def __init__(self, folder: str | Path, *, seed: int | None = None):
        self.folder = str(Path(folder).expanduser())
        self.files = discover_audio_files(folder)
        if not self.files:
            raise ValueError(f"No supported audio files were found in: {self.folder}")
        self._rng = random.Random(seed)
        self._remaining: list[str] = []

    def next(self) -> str:
        if not self._remaining:
            self._remaining = list(self.files)
            self._rng.shuffle(self._remaining)
        return self._remaining.pop()
