"""Slide Cascade – words slide in from alternating sides."""

from __future__ import annotations

from moviepy import CompositeVideoClip

from .base import AnimationPreset, RenderContext, make_background
from ..effects import make_styled_text_clip, apply_fade, ease_out_cubic


class SlideCascadePreset(AnimationPreset):
    name = "slide_cascade"
    description = "Slide Cascade – words slide in from left / right"

    def build(self, ctx: RenderContext) -> tuple[CompositeVideoClip, float]:
        n = len(ctx.words)
        total = n * (ctx.word_duration + ctx.gap) - ctx.gap + ctx.end_hold
        total = max(total, 1.0)

        bg = make_background(ctx, total)
        clips = [bg]
        w, h = ctx.size

        for i, word in enumerate(ctx.words):
            self._check_cancel(ctx)
            self._progress(ctx, i + 1, n, f"Slide: {word}")

            start = i * (ctx.word_duration + ctx.gap)
            from_left = i % 2 == 0

            txt = make_styled_text_clip(
                text=word,
                font=ctx.font_path,
                font_size=ctx.font_size,
                color=ctx.text_color,
                duration=ctx.word_duration,
                outline=ctx.outline,
                outline_width=ctx.outline_width,
                shadow=ctx.shadow,
            )

            slide_dur = min(0.4, ctx.word_duration * 0.5)
            start_x = -txt.w if from_left else w + txt.w
            end_x = (w - txt.w) // 2

            def make_pos(t, sx=start_x, ex=end_x, sd=slide_dur):
                if t >= sd:
                    return (ex, "center")
                p = ease_out_cubic(t / sd)
                x = sx + (ex - sx) * p
                return (x, "center")

            txt = txt.with_position(make_pos)
            txt = apply_fade(txt, fade_in=0.15, fade_out=0.2)
            txt = txt.with_start(start).with_duration(ctx.word_duration)
            clips.append(txt)

        final = CompositeVideoClip(clips, size=ctx.size).with_fps(ctx.fps)
        return final, total
