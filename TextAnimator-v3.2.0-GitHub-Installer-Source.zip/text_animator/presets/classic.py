"""Classic Kinetic – sequential centered words with fade + zoom + optional tilt."""

from __future__ import annotations

from moviepy import CompositeVideoClip

from .base import AnimationPreset, RenderContext, make_background
from ..effects import make_styled_text_clip, apply_fade, apply_zoom, ease_out_cubic


class ClassicPreset(AnimationPreset):
    name = "classic"
    description = "Classic Kinetic – words appear one by one, centered, with fade & zoom"

    def build(self, ctx: RenderContext) -> tuple[CompositeVideoClip, float]:
        n = len(ctx.words)
        total = n * (ctx.word_duration + ctx.gap) - ctx.gap + ctx.end_hold
        total = max(total, 1.0)

        bg = make_background(ctx, total)
        clips = [bg]

        for i, word in enumerate(ctx.words):
            self._check_cancel(ctx)
            self._progress(ctx, i + 1, n, f"Classic: {word}")

            start = i * (ctx.word_duration + ctx.gap)
            txt = make_styled_text_clip(
                text=word,
                font=ctx.font_path,
                font_size=ctx.font_size,
                color=ctx.text_color,
                duration=ctx.word_duration,
                outline=ctx.outline,
                outline_width=ctx.outline_width,
                shadow=ctx.shadow,
                shadow_offset=ctx.shadow_offset,
            )
            txt = txt.with_position("center")
            transition_time = min(ctx.transition_duration, ctx.word_duration * 0.45)
            if ctx.transition == "fade":
                txt = apply_fade(txt, fade_in=transition_time, fade_out=transition_time * 0.8)
            txt = apply_zoom(
                txt,
                start_scale=0.18 if ctx.transition == "zoom" else 0.28,
                end_scale=1.0,
                duration=transition_time,
                ease=ease_out_cubic,
            )

            # mild static tilt for variety
            tilt = 6 * (1 if hash(word) % 2 == 0 else -1)
            try:
                txt = txt.rotated(tilt * 0.35, expand=True)
            except Exception:
                pass

            txt = txt.with_start(start).with_duration(ctx.word_duration)
            clips.append(txt)

        final = CompositeVideoClip(clips, size=ctx.size).with_fps(ctx.fps)
        return final, total
