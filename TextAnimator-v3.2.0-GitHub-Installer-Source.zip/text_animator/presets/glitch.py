"""Glitch / Strobe – rapid black/white flashes + jitter."""

from __future__ import annotations

import random
from moviepy import ColorClip, CompositeVideoClip

from .base import AnimationPreset, RenderContext, make_background
from ..effects import make_styled_text_clip, apply_fade


class GlitchPreset(AnimationPreset):
    name = "glitch"
    description = "Glitch / Strobe – short flashes, jitter and high contrast cuts"

    def build(self, ctx: RenderContext) -> tuple[CompositeVideoClip, float]:
        n = len(ctx.words)
        flash_dur = max(0.18, min(0.45, ctx.word_duration * 0.55))
        total = n * (flash_dur + 0.06) + ctx.end_hold
        total = max(total, 1.0)

        clips = []
        t = 0.0

        for i, word in enumerate(ctx.words):
            self._check_cancel(ctx)
            self._progress(ctx, i + 1, n, f"Glitch: {word}")

            # Occasionally invert colors for one flash
            invert = (i % 3 == 2)
            if invert:
                bg_c = (0, 0, 0) if ctx.bg_color == (255, 255, 255) else (255, 255, 255)
                txt_c = "white" if ctx.text_color == "black" else "black"
            else:
                bg_c = ctx.bg_color
                txt_c = ctx.text_color

            # Prefer solid flash colors for glitch energy; still allow image under non-inverted
            if invert or not ctx.bg_image_path:
                bg = ColorClip(size=ctx.size, color=bg_c, duration=flash_dur).with_start(t)
            else:
                bg = make_background(ctx, flash_dur).with_start(t)
            clips.append(bg)

            txt = make_styled_text_clip(
                text=word,
                font=ctx.font_path,
                font_size=int(ctx.font_size * (1.0 + random.uniform(-0.08, 0.12))),
                color=txt_c,
                duration=flash_dur,
                outline=True,  # always outline for glitch readability
                outline_width=max(2, ctx.outline_width),
            )
            jx = random.randint(-12, 12)
            jy = random.randint(-8, 8)
            txt = txt.with_position((ctx.size[0] // 2 + jx - txt.w // 2,
                                    ctx.size[1] // 2 + jy - txt.h // 2))
            txt = apply_fade(txt, fade_in=0.04, fade_out=0.06)
            txt = txt.with_start(t).with_duration(flash_dur)
            clips.append(txt)

            t += flash_dur + 0.06

        # final hold
        final_bg = make_background(ctx, ctx.end_hold).with_start(t)
        clips.append(final_bg)

        final = CompositeVideoClip(clips, size=ctx.size).with_fps(ctx.fps)
        return final, t + ctx.end_hold
