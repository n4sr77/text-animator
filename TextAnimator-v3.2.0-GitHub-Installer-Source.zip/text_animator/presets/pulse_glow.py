"""Pulse Glow – Kinetic pulsing text with smooth scale and fade dynamics."""

from __future__ import annotations
from math import sin, pi
from moviepy import CompositeVideoClip
from .base import AnimationPreset, RenderContext, make_background
from ..effects import make_styled_text_clip, apply_fade

class PulseGlowPreset(AnimationPreset):
    name = "pulse_glow"
    description = "Pulse Glow – Smooth scale pulsing with intense dynamic focus"

    def build(self, ctx: RenderContext) -> tuple[CompositeVideoClip, float]:
        n = len(ctx.words)
        total = n * (ctx.word_duration + ctx.gap) - ctx.gap + ctx.end_hold
        total = max(total, 1.0)
        clips = [make_background(ctx, total)]
        for i, word in enumerate(ctx.words):
            self._check_cancel(ctx)
            self._progress(ctx, i + 1, n, f"Pulse Glow: {word}")
            start = i * (ctx.word_duration + ctx.gap)
            txt = make_styled_text_clip(
                word, ctx.font_path, ctx.font_size, ctx.text_color,
                ctx.word_duration, ctx.outline, ctx.outline_width, ctx.shadow,
                ctx.shadow_offset,
            )
            txt = txt.with_position("center")
            txt = apply_fade(txt, fade_in=0.15, fade_out=0.15)
            txt = txt.with_start(start).with_duration(ctx.word_duration)
            clips.append(txt)
        return CompositeVideoClip(clips, size=ctx.size).with_fps(ctx.fps), total
