"""Zoom Pulse – energetic entrance followed by a subtle breathing scale."""

from __future__ import annotations

from math import sin, pi
from moviepy import CompositeVideoClip
from moviepy.video.fx import Resize

from .base import AnimationPreset, RenderContext, make_background
from ..effects import make_styled_text_clip, apply_fade, ease_out_back


class ZoomPulsePreset(AnimationPreset):
    name = "zoom_pulse"
    description = "Zoom Pulse – overshoot entrance with a gentle scale pulse"

    def build(self, ctx: RenderContext) -> tuple[CompositeVideoClip, float]:
        n = len(ctx.words)
        total = n * (ctx.word_duration + ctx.gap) - ctx.gap + ctx.end_hold
        total = max(total, 1.0)
        clips = [make_background(ctx, total)]
        for i, word in enumerate(ctx.words):
            self._check_cancel(ctx)
            self._progress(ctx, i + 1, n, f"Zoom pulse: {word}")
            start = i * (ctx.word_duration + ctx.gap)
            txt = make_styled_text_clip(
                word, ctx.font_path, ctx.font_size, ctx.text_color,
                ctx.word_duration, ctx.outline, ctx.outline_width, ctx.shadow,
                ctx.shadow_offset,
            )
            enter = min(0.5, ctx.word_duration * 0.55)

            def scale(t, d=enter):
                if t < d:
                    p = min(1.0, max(0.0, t / max(d, 0.01)))
                    return 0.08 + 0.92 * ease_out_back(p, 1.45)
                pulse_t = t - d
                return 1.0 + 0.018 * sin(2 * pi * pulse_t * 1.15)

            txt = txt.with_effects([Resize(scale)])
            txt = txt.with_position("center")
            txt = apply_fade(txt, fade_in=0.10, fade_out=0.10)
            txt = txt.with_start(start).with_duration(ctx.word_duration)
            clips.append(txt)
        return CompositeVideoClip(clips, size=ctx.size).with_fps(ctx.fps), total
