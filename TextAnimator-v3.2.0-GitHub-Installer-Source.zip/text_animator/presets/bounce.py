"""Bounce In – words spring into the frame from alternating vertical directions."""

from __future__ import annotations

from math import sin
from moviepy import CompositeVideoClip

from .base import AnimationPreset, RenderContext, make_background
from ..effects import make_styled_text_clip, apply_fade, ease_out_back


class BouncePreset(AnimationPreset):
    name = "bounce"
    description = "Bounce In – springy words drop into the center"

    def build(self, ctx: RenderContext) -> tuple[CompositeVideoClip, float]:
        n = len(ctx.words)
        total = n * (ctx.word_duration + ctx.gap) - ctx.gap + ctx.end_hold
        total = max(total, 1.0)
        clips = [make_background(ctx, total)]
        center_y = ctx.size[1] / 2

        for i, word in enumerate(ctx.words):
            self._check_cancel(ctx)
            self._progress(ctx, i + 1, n, f"Bounce: {word}")
            start = i * (ctx.word_duration + ctx.gap)
            txt = make_styled_text_clip(
                word, ctx.font_path, ctx.font_size, ctx.text_color,
                ctx.word_duration, ctx.outline, ctx.outline_width, ctx.shadow,
                ctx.shadow_offset,
            )
            enter = min(0.48, ctx.word_duration * 0.6)
            direction = -1 if i % 2 == 0 else 1

            def position(t, h=txt.h, w=txt.w, d=enter, sign=direction):
                p = min(1.0, max(0.0, t / max(d, 0.01)))
                eased = ease_out_back(p, 1.55)
                y = center_y + sign * (1.0 - eased) * (ctx.size[1] * 0.48 + h / 2) - h / 2
                return ((ctx.size[0] - w) / 2, y)

            txt = apply_fade(txt, fade_in=min(0.12, enter * 0.4), fade_out=0.12)
            txt = txt.with_position(position).with_start(start).with_duration(ctx.word_duration)
            clips.append(txt)
        return CompositeVideoClip(clips, size=ctx.size).with_fps(ctx.fps), total
