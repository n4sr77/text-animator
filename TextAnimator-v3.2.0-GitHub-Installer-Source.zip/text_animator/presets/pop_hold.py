"""Pop & Hold – fast zoom with overshoot / bounce then hold."""

from __future__ import annotations

from moviepy import CompositeVideoClip

from .base import AnimationPreset, RenderContext, make_background
from ..effects import make_styled_text_clip, apply_fade, apply_zoom, ease_out_back


class PopHoldPreset(AnimationPreset):
    name = "pop_hold"
    description = "Pop & Hold – fast zoom with overshoot, then solid hold"

    def build(self, ctx: RenderContext) -> tuple[CompositeVideoClip, float]:
        n = len(ctx.words)
        enter = min(0.45, ctx.word_duration * 0.4)
        hold = max(0.5, ctx.word_duration - enter)
        total = n * (enter + hold + ctx.gap) - ctx.gap + ctx.end_hold
        total = max(total, 1.0)

        bg = make_background(ctx, total)
        clips = [bg]

        for i, word in enumerate(ctx.words):
            self._check_cancel(ctx)
            self._progress(ctx, i + 1, n, f"Pop: {word}")

            start = i * (enter + hold + ctx.gap)
            duration = enter + hold

            txt = make_styled_text_clip(
                text=word,
                font=ctx.font_path,
                font_size=ctx.font_size,
                color=ctx.text_color,
                duration=duration,
                outline=ctx.outline,
                outline_width=ctx.outline_width,
                shadow=ctx.shadow,
            )
            txt = txt.with_position("center")
            txt = apply_fade(txt, fade_in=0.08, fade_out=0.18)
            txt = apply_zoom(
                txt,
                start_scale=0.15,
                end_scale=1.0,
                duration=enter,
                ease=ease_out_back,
            )
            txt = txt.with_start(start).with_duration(duration)
            clips.append(txt)

        final = CompositeVideoClip(clips, size=ctx.size).with_fps(ctx.fps)
        return final, total
