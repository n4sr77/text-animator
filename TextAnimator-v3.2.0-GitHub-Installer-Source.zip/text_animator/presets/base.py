"""Base class for all animation presets."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Callable, Any

from moviepy import ColorClip, CompositeVideoClip, ImageClip


@dataclass
class RenderContext:
    """Everything a preset needs to build the final video."""
    words: list[str]
    size: tuple[int, int]
    font_path: str
    font_size: int
    text_color: str
    bg_color: tuple[int, int, int]
    word_duration: float
    gap: float
    end_hold: float
    fps: int
    outline: bool = False
    shadow: bool = False
    outline_width: int = 3
    shadow_offset: int = 4
    # Optional custom background image. When set, overrides solid color.
    bg_image_path: str | None = None
    transition: str = "fade"
    transition_duration: float = 0.25
    # cancellation
    cancel_flag: Any = None          # threading.Event
    progress_callback: Callable[[int, int, str], None] | None = None


def make_background(ctx: RenderContext, duration: float):
    """
    Create a background clip of the requested duration.
    Uses custom image if provided, otherwise solid color.
    Image is resized/cropped to fill the frame (cover).
    """
    if ctx.bg_image_path:
        try:
            img = ImageClip(ctx.bg_image_path)
            # Cover the target size while preserving aspect ratio
            iw, ih = img.size
            tw, th = ctx.size
            scale = max(tw / iw, th / ih)
            new_w, new_h = int(iw * scale), int(ih * scale)
            img = img.resized((new_w, new_h))
            # Center crop
            x1 = (new_w - tw) // 2
            y1 = (new_h - th) // 2
            img = img.cropped(x1=x1, y1=y1, x2=x1 + tw, y2=y1 + th)
            return img.with_duration(duration)
        except Exception:
            # Fallback to solid color on any image error
            pass
    return ColorClip(size=ctx.size, color=ctx.bg_color, duration=duration)


class AnimationPreset(ABC):
    """Abstract preset. Subclasses implement build()."""

    name: str = "base"
    description: str = ""

    @abstractmethod
    def build(self, ctx: RenderContext) -> tuple[CompositeVideoClip, float]:
        """
        Return (final_clip, total_duration_seconds).
        Must respect ctx.cancel_flag if set.
        """
        ...

    def _check_cancel(self, ctx: RenderContext):
        if ctx.cancel_flag is not None and ctx.cancel_flag.is_set():
            raise InterruptedError("Render cancelled by user")

    def _progress(self, ctx: RenderContext, current: int, total: int, msg: str):
        if ctx.progress_callback:
            ctx.progress_callback(current, total, msg)
