"""Fade Through Black – each word fades in, then background briefly goes pure black."""

from __future__ import annotations

from moviepy import ColorClip, CompositeVideoClip

from .base import AnimationPreset, RenderContext, make_background
from ..effects import make_styled_text_clip, apply_fade, apply_zoom, ease_out_cubic


class FadeBlackPreset(AnimationPreset):
    name = "fade_black"
    description = "Fade Through Black – soft fade + brief pure black between words"

    def build(self, ctx: RenderContext) -> tuple[CompositeVideoClip, float]:
        n = len(ctx.words)
        black_gap = max(0.12, ctx.gap * 1.8)
        total = n * (ctx.word_duration + black_gap) - black_gap + ctx.end_hold
        total = max(total, 1.0)

        clips = []
        t = 0.0

        for i, word in enumerate(ctx.words):
            self._check_cancel(ctx)
            self._progress(ctx, i + 1, n, f"FadeBlack: {word}")

            # Main background segment (image or solid)
            bg = make_background(ctx, ctx.word_duration).with_start(t)
            clips.append(bg)

            txt = make_styled_text_clip(
                text=word,
                font=ctx.font_path,
                font_size=ctx.font_size,
                color=ctx.text_color,
                duration=ctx.word_duration,
                outline=ctx.outline,
                outline_width=ctx.outline_width,
                shadow=ctx.shadow,
            )
            txt = txt.with_position("center")
            txt = apply_fade(txt, fade_in=0.35, fade_out=0.3)
            txt = apply_zoom(txt, start_scale=0.55, end_scale=1.0, ease=ease_out_cubic)
            txt = txt.with_start(t).with_duration(ctx.word_duration)
            clips.append(txt)

            t += ctx.word_duration

            # Brief pure black transition (except after last word)
            if i < n - 1:
                black = ColorClip(size=ctx.size, color=(0, 0, 0), duration=black_gap).with_start(t)
                clips.append(black)
                t += black_gap

        # final hold
        if ctx.end_hold > 0:
            hold_bg = make_background(ctx, ctx.end_hold).with_start(t)
            clips.append(hold_bg)
            t += ctx.end_hold

        final = CompositeVideoClip(clips, size=ctx.size).with_fps(ctx.fps)
        return final, t
