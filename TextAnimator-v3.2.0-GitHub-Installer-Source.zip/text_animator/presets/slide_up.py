"""Slide Up – words rise from below the frame with a soft settle."""

from __future__ import annotations

from moviepy import CompositeVideoClip

from .base import AnimationPreset, RenderContext, make_background
from ..effects import make_styled_text_clip, apply_fade, ease_out_cubic


class SlideUpPreset(AnimationPreset):
    name = "slide_up"
    description = "Slide Up – words rise into the center"

    def build(self, ctx: RenderContext) -> tuple[CompositeVideoClip, float]:
        n = len(ctx.words)
        total = n * (ctx.word_duration + ctx.gap) - ctx.gap + ctx.end_hold
        total = max(total, 1.0)
        clips = [make_background(ctx, total)]

        for i, word in enumerate(ctx.words):
            self._check_cancel(ctx)
            self._progress(ctx, i + 1, n, f"Slide up: {word}")
            start = i * (ctx.word_duration + ctx.gap)
            txt = make_styled_text_clip(
                word, ctx.font_path, ctx.font_size, ctx.text_color,
                ctx.word_duration, ctx.outline, ctx.outline_width, ctx.shadow,
                ctx.shadow_offset,
            )
            enter = min(0.42, ctx.word_duration * 0.55)
            start_y = ctx.size[1] + txt.h
            target_y = (ctx.size[1] - txt.h) / 2

            def position(t, h=txt.h, w=txt.w, sy=start_y, ty=target_y, d=enter):
                p = ease_out_cubic(min(1.0, max(0.0, t / max(d, 0.01))))
                y = sy + (ty - sy) * p
                return ((ctx.size[0] - w) / 2, y)

            txt = apply_fade(txt, fade_in=0.14, fade_out=0.10)
            txt = txt.with_position(position).with_start(start).with_duration(ctx.word_duration)
            clips.append(txt)
        return CompositeVideoClip(clips, size=ctx.size).with_fps(ctx.fps), total
