"""Typewriter – words appear sequentially and stay on screen."""

from __future__ import annotations

from moviepy import CompositeVideoClip

from .base import AnimationPreset, RenderContext, make_background
from ..effects import make_styled_text_clip, apply_fade


class TypewriterPreset(AnimationPreset):
    name = "typewriter"
    description = "Typewriter – words appear one after another and remain visible"

    def build(self, ctx: RenderContext) -> tuple[CompositeVideoClip, float]:
        n = len(ctx.words)
        total = n * (ctx.word_duration * 0.55) + ctx.end_hold
        total = max(total, 1.5)

        bg = make_background(ctx, total)
        clips = [bg]

        for i, word in enumerate(ctx.words):
            self._check_cancel(ctx)
            self._progress(ctx, i + 1, n, f"Typewriter: {word}")

            start = i * (ctx.word_duration * 0.55)
            remaining = total - start

            txt = make_styled_text_clip(
                text=word,
                font=ctx.font_path,
                font_size=ctx.font_size,
                color=ctx.text_color,
                duration=remaining,
                outline=ctx.outline,
                outline_width=ctx.outline_width,
                shadow=ctx.shadow,
            )
            y_off = (i - (n - 1) / 2) * (ctx.font_size * 0.9)
            txt = txt.with_position(("center", ctx.size[1] // 2 + y_off))
            txt = apply_fade(txt, fade_in=0.12, fade_out=0.0)
            txt = txt.with_start(start)
            clips.append(txt)

        final = CompositeVideoClip(clips, size=ctx.size).with_fps(ctx.fps)
        return final, total
