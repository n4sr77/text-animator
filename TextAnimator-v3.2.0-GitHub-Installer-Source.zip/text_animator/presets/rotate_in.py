"""Rotate In – each word turns upright as it enters."""

from __future__ import annotations

from moviepy import CompositeVideoClip

from .base import AnimationPreset, RenderContext, make_background
from ..effects import make_styled_text_clip, apply_fade, ease_out_cubic


class RotateInPreset(AnimationPreset):
    name = "rotate_in"
    description = "Rotate In – words rotate into place"

    def build(self, ctx: RenderContext) -> tuple[CompositeVideoClip, float]:
        n = len(ctx.words)
        total = n * (ctx.word_duration + ctx.gap) - ctx.gap + ctx.end_hold
        total = max(total, 1.0)
        clips = [make_background(ctx, total)]
        for i, word in enumerate(ctx.words):
            self._check_cancel(ctx)
            self._progress(ctx, i + 1, n, f"Rotate: {word}")
            start = i * (ctx.word_duration + ctx.gap)
            txt = make_styled_text_clip(
                word, ctx.font_path, ctx.font_size, ctx.text_color,
                ctx.word_duration, ctx.outline, ctx.outline_width, ctx.shadow,
                ctx.shadow_offset,
            )
            enter = min(0.45, ctx.word_duration * 0.6)
            direction = 1 if i % 2 == 0 else -1

            def angle(t, d=enter, sign=direction):
                p = ease_out_cubic(min(1.0, max(0.0, t / max(d, 0.01))))
                return sign * 22.0 * (1.0 - p)

            txt = txt.rotated(angle, expand=False)
            txt = txt.with_position("center")
            txt = apply_fade(txt, fade_in=0.12, fade_out=0.12)
            txt = txt.with_start(start).with_duration(ctx.word_duration)
            clips.append(txt)
        return CompositeVideoClip(clips, size=ctx.size).with_fps(ctx.fps), total
