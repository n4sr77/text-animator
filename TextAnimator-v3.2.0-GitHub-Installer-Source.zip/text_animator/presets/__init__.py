"""Animation preset registry."""

from .classic import ClassicPreset
from .typewriter import TypewriterPreset
from .pop_hold import PopHoldPreset
from .slide_cascade import SlideCascadePreset
from .glitch import GlitchPreset
from .fade_black import FadeBlackPreset
from .bounce import BouncePreset
from .slide_up import SlideUpPreset
from .rotate_in import RotateInPreset
from .zoom_pulse import ZoomPulsePreset
from .pulse_glow import PulseGlowPreset

PRESETS = {
    "classic": ClassicPreset(),
    "typewriter": TypewriterPreset(),
    "pop_hold": PopHoldPreset(),
    "slide_cascade": SlideCascadePreset(),
    "glitch": GlitchPreset(),
    "fade_black": FadeBlackPreset(),
    "bounce": BouncePreset(),
    "slide_up": SlideUpPreset(),
    "rotate_in": RotateInPreset(),
    "zoom_pulse": ZoomPulsePreset(),
    "pulse_glow": PulseGlowPreset(),
}

PRESET_NAMES = list(PRESETS.keys())

PRESET_LABELS = {
    "classic": "Classic Kinetic",
    "typewriter": "Typewriter",
    "pop_hold": "Pop & Hold",
    "slide_cascade": "Slide Cascade",
    "glitch": "Glitch / Strobe",
    "fade_black": "Fade Through Black",
    "bounce": "Bounce In",
    "slide_up": "Slide Up",
    "rotate_in": "Rotate In",
    "zoom_pulse": "Zoom Pulse",
    "pulse_glow": "Pulse Glow",
}

def get_preset(name: str):
    return PRESETS.get(name, PRESETS["classic"])
