"""Text splitting and helpers."""

from __future__ import annotations

import re


def split_into_words(text: str) -> list[str]:
    """Split text into words while keeping punctuation attached."""
    words = re.findall(r"\S+", text.strip())
    return [w for w in words if w]


def split_into_letters(text: str, keep_spaces: bool = False) -> list[str]:
    """
    Split into individual characters.
    If keep_spaces=False, spaces are dropped (common for kinetic letter animations).
    """
    if keep_spaces:
        return list(text)
    return [c for c in text if not c.isspace()]


def estimate_safe_font_size(
    text: str,
    max_width: int,
    max_height: int,
    font_path: str,
    preferred: int = 90,
) -> int:
    """
    Rough estimate so the longest word fits comfortably.
    Uses a simple heuristic; exact measurement is done later by MoviePy/Pillow.
    """
    from PIL import ImageFont

    words = split_into_words(text)
    if not words:
        return preferred

    longest = max(words, key=len)
    size = preferred
    try:
        while size > 24:
            font = ImageFont.truetype(font_path, size)
            bbox = font.getbbox(longest)
            w = bbox[2] - bbox[0]
            h = bbox[3] - bbox[1]
            if w < max_width * 0.85 and h < max_height * 0.55:
                return size
            size -= 4
    except Exception:
        pass
    return max(28, size)
