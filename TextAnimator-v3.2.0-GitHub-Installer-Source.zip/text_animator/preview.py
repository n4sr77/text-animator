"""Low-resolution live preview generation."""

from __future__ import annotations

import os
import tempfile
from typing import Callable

from .config import PREVIEW_SIZE, PREVIEW_FPS
from .renderer import VideoRenderer


class PreviewEngine:
    """Generates a quick low-res preview video."""

    def __init__(self):
        self.renderer = VideoRenderer()
        self._tmp_path: str | None = None

    def cancel(self):
        self.renderer.cancel()

    def generate(
        self,
        text: str,
        *,
        preset_name: str = "classic",
        font_name_or_path: str = "",
        font_size: int = 70,
        color_mode: str = "white_on_black",
        word_duration: float = 0.7,
        gap: float = 0.06,
        end_hold: float = 0.8,
        outline: bool = False,
        shadow: bool = False,
        outline_width: int = 3,
        shadow_offset: int = 4,
        auto_fit_font: bool = True,
        transition: str = "fade",
        transition_duration: float = 0.25,
        audio_path: str | None = None,
        audio_volume: float = 0.85,
        audio_fade_in: float = 0.15,
        audio_fade_out: float = 0.25,
        bg_image_path: str | None = None,
        hardware_backend: str = "auto",
        progress_callback: Callable[[int, int, str], None] | None = None,
    ) -> str:
        """
        Build a low-res preview and return the path to a temporary MP4.
        Caller is responsible for cleaning up or the next call will overwrite.
        """
        # Clean previous
        if self._tmp_path and os.path.exists(self._tmp_path):
            try:
                os.remove(self._tmp_path)
            except OSError:
                pass

        tmp = tempfile.NamedTemporaryFile(suffix=".mp4", delete=False, prefix="preview_")
        tmp.close()
        self._tmp_path = tmp.name

        # Slightly faster timings for preview
        self.renderer.render_to_file(
            text,
            self._tmp_path,
            preset_name=preset_name,
            size=PREVIEW_SIZE,
            font_name_or_path=font_name_or_path,
            font_size=max(40, font_size - 20),
            color_mode=color_mode,
            word_duration=max(0.35, word_duration * 0.75),
            gap=gap,
            end_hold=max(0.4, end_hold * 0.7),
            fps=PREVIEW_FPS,
            outline=outline,
            shadow=shadow,
            outline_width=outline_width,
            shadow_offset=shadow_offset,
            auto_fit_font=auto_fit_font,
            transition=transition,
            transition_duration=transition_duration,
            audio_path=audio_path,
            audio_volume=audio_volume,
            audio_fade_in=audio_fade_in,
            audio_fade_out=audio_fade_out,
            bg_image_path=bg_image_path,
            hardware_backend=hardware_backend,
            progress_callback=progress_callback,
            logger=None,
        )
        return self._tmp_path

    def cleanup(self):
        if self._tmp_path and os.path.exists(self._tmp_path):
            try:
                os.remove(self._tmp_path)
            except OSError:
                pass
            self._tmp_path = None
