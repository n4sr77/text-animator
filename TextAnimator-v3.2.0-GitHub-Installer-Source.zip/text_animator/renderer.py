"""Video rendering engine with cancellation support."""

from __future__ import annotations

import os
import tempfile
import shutil
import threading
from pathlib import Path
from typing import Callable

from moviepy import CompositeVideoClip, AudioFileClip
from moviepy.audio.fx import AudioFadeIn, AudioFadeOut, AudioLoop

from .config import COLOR_MODES, ENCODE_PRESETS
from .presets import get_preset
from .presets.base import RenderContext
from .fonts import resolve_font
from .text_utils import split_into_words, estimate_safe_font_size
from .hardware import encoder_plan, encoder_preset, set_moviepy_ffmpeg


class RenderCancelled(Exception):
    pass


class VideoRenderer:
    """High-level renderer used by both full export and preview."""

    def __init__(self):
        self._cancel = threading.Event()
        self._is_running = False
        self.last_encoder_label = "Not rendered yet"

    @property
    def is_running(self) -> bool:
        return self._is_running

    def cancel(self):
        self._cancel.set()

    def reset(self):
        self._cancel.clear()
        self._is_running = False

    def build_clip(
        self,
        text: str,
        *,
        preset_name: str = "classic",
        size: tuple[int, int] = (1280, 720),
        font_name_or_path: str = "",
        font_size: int = 90,
        color_mode: str = "white_on_black",
        word_duration: float = 0.85,
        gap: float = 0.08,
        end_hold: float = 1.2,
        fps: int = 30,
        outline: bool = False,
        shadow: bool = False,
        outline_width: int = 3,
        shadow_offset: int = 4,
        bg_image_path: str | None = None,
        auto_fit_font: bool = True,
        transition: str = "fade",
        transition_duration: float = 0.25,
        progress_callback: Callable[[int, int, str], None] | None = None,
    ) -> tuple[CompositeVideoClip, float]:
        """Build the CompositeVideoClip (does not write to disk)."""
        self._is_running = True
        self._cancel.clear()

        words = split_into_words(text)
        if not words:
            raise ValueError("No words found in the input text")

        font_path = resolve_font(font_name_or_path) if font_name_or_path else resolve_font("")
        if auto_fit_font:
            font_size = estimate_safe_font_size(
                text, size[0], size[1], font_path, preferred=font_size
            )

        colors = COLOR_MODES.get(color_mode, COLOR_MODES["white_on_black"])

        bg_path = None
        if bg_image_path and os.path.isfile(bg_image_path):
            ext = os.path.splitext(bg_image_path)[1].lower()
            if ext in {".jpg", ".jpeg", ".png", ".webp", ".bmp", ".tif", ".tiff", ".gif", ".ppm"}:
                bg_path = bg_image_path

        ctx = RenderContext(
            words=words,
            size=size,
            font_path=font_path,
            font_size=font_size,
            text_color=colors["text"],
            bg_color=colors["bg"],
            word_duration=word_duration,
            gap=gap,
            end_hold=end_hold,
            fps=fps,
            outline=outline,
            shadow=shadow,
            outline_width=outline_width,
            shadow_offset=shadow_offset,
            bg_image_path=bg_path,
            transition=transition,
            transition_duration=max(0.0, min(1.2, transition_duration)),
            cancel_flag=self._cancel,
            progress_callback=progress_callback,
        )

        preset = get_preset(preset_name)
        try:
            clip, duration = preset.build(ctx)
            return clip, duration
        except InterruptedError as e:
            raise RenderCancelled(str(e)) from e
        finally:
            self._is_running = False

    def render_to_file(
        self,
        text: str,
        output_path: str,
        *,
        preset_name: str = "classic",
        size: tuple[int, int] = (1280, 720),
        font_name_or_path: str = "",
        font_size: int = 90,
        color_mode: str = "white_on_black",
        word_duration: float = 0.85,
        gap: float = 0.08,
        end_hold: float = 1.2,
        fps: int = 30,
        outline: bool = False,
        shadow: bool = False,
        outline_width: int = 3,
        shadow_offset: int = 4,
        bg_image_path: str | None = None,
        auto_fit_font: bool = True,
        encode_preset: str = "medium",
        hardware_backend: str = "auto",
        audio_path: str | None = None,
        audio_volume: float = 0.85,
        audio_fade_in: float = 0.15,
        audio_fade_out: float = 0.25,
        transition: str = "fade",
        transition_duration: float = 0.25,
        progress_callback: Callable[[int, int, str], None] | None = None,
        logger=None,
    ) -> str:
        """Full render → MP4. Returns the final output path."""
        clip = None
        tmp_dir = None
        try:
            clip, _ = self.build_clip(
                text,
                preset_name=preset_name,
                size=size,
                font_name_or_path=font_name_or_path,
                font_size=font_size,
                color_mode=color_mode,
                word_duration=word_duration,
                gap=gap,
                end_hold=end_hold,
                fps=fps,
                outline=outline,
                shadow=shadow,
                outline_width=outline_width,
                shadow_offset=shadow_offset,
                bg_image_path=bg_image_path,
                auto_fit_font=auto_fit_font,
                transition=transition,
                transition_duration=transition_duration,
                progress_callback=progress_callback,
            )

            if self._cancel.is_set():
                raise RenderCancelled("Cancelled before writing")

            tmp_dir = tempfile.mkdtemp(prefix="textanim_")
            tmp_path = os.path.join(tmp_dir, "out.mp4")

            # Map friendly name → MoviePy/x264 preset
            x264_preset = ENCODE_PRESETS.get(encode_preset, encode_preset)
            if x264_preset not in ("ultrafast", "superfast", "veryfast", "faster",
                                   "fast", "medium", "slow", "slower", "veryslow"):
                x264_preset = "medium"

            audio = None
            if audio_path:
                if not os.path.isfile(audio_path):
                    raise ValueError(f"Audio file not found: {audio_path}")
                audio = AudioFileClip(audio_path)
                if audio.duration < clip.duration:
                    audio = AudioLoop(duration=clip.duration).apply(audio)
                else:
                    audio = audio.subclipped(0, clip.duration)
                audio = audio.with_volume_scaled(max(0.0, min(1.0, audio_volume)))
                fade_in = max(0.0, min(audio_fade_in, clip.duration * 0.45))
                fade_out = max(0.0, min(audio_fade_out, clip.duration * 0.45))
                effects = []
                if fade_in:
                    effects.append(AudioFadeIn(fade_in))
                if fade_out:
                    effects.append(AudioFadeOut(fade_out))
                if effects:
                    audio = audio.with_effects(effects)
                clip = clip.with_audio(audio)

            # Try the chosen hardware encoder first, then fall back automatically.
            # MoviePy/Pillow still render/composite frames on the CPU; this accelerates
            # the final H.264 encoding stage only.
            ffmpeg_path = set_moviepy_ffmpeg()
            plan = encoder_plan(hardware_backend, ffmpeg_path)
            encode_errors: list[str] = []
            encoded = False
            for choice in plan:
                if self._cancel.is_set():
                    raise RenderCancelled("Cancelled during encode")
                try:
                    try:
                        if os.path.exists(tmp_path):
                            os.unlink(tmp_path)
                    except OSError:
                        pass
                    kwargs = {
                        "fps": fps,
                        "codec": choice.codec,
                        "audio": bool(audio),
                        "audio_codec": "aac" if audio else None,
                        "audio_bitrate": "192k" if audio else None,
                        "preset": encoder_preset(choice, x264_preset),
                        "logger": logger,
                    }
                    # Explicit pixel formats avoid unsupported alpha formats on
                    # hardware encoders; QSV commonly expects NV12.
                    if choice.key == "nvenc":
                        kwargs["ffmpeg_params"] = ["-pix_fmt", "yuv420p"]
                    elif choice.key == "qsv":
                        kwargs["ffmpeg_params"] = ["-pix_fmt", "nv12"]
                    clip.write_videofile(tmp_path, **kwargs)
                    self.last_encoder_label = choice.label
                    encoded = True
                    break
                except Exception as exc:
                    encode_errors.append(f"{choice.label}: {exc}")
                    try:
                        if os.path.exists(tmp_path):
                            os.unlink(tmp_path)
                    except OSError:
                        pass
                    if self._cancel.is_set():
                        raise RenderCancelled("Cancelled during encode") from exc

            if not encoded:
                raise RuntimeError(
                    "Video encoding failed with all available encoders.\n" +
                    "\n".join(encode_errors[-3:])
                )

            if self._cancel.is_set():
                raise RenderCancelled("Cancelled during encode")

            Path(output_path).parent.mkdir(parents=True, exist_ok=True)
            shutil.move(tmp_path, output_path)
            return output_path

        finally:
            if clip is not None:
                try:
                    clip.close()
                except Exception:
                    pass
            if tmp_dir and os.path.isdir(tmp_dir):
                shutil.rmtree(tmp_dir, ignore_errors=True)
            self._is_running = False
