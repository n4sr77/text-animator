"""Module entry point for ``python -m text_animator``."""
from __future__ import annotations

import argparse

from . import __version__


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="python -m text_animator",
        description="Create animated text videos and batch-process image, video and audio files.",
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"TextAnimator {__version__}",
    )
    parser.parse_args(argv)

    from .gui import TextAnimatorApp

    app = TextAnimatorApp()
    app.mainloop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
