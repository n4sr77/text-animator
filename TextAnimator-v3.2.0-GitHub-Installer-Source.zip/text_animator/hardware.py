"""FFmpeg encoder discovery and hardware-first H.264 encoding plans.

The app renders/composites frames on the CPU (MoviePy/Pillow), then can use
NVIDIA NVENC or Intel Quick Sync for the final H.264 encode when the selected
FFmpeg binary and installed drivers support them. Every hardware attempt has a
software fallback.
"""

from __future__ import annotations

import os
import re
import shutil
import subprocess
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path

import imageio_ffmpeg


@dataclass(frozen=True)
class EncoderChoice:
    key: str
    label: str
    codec: str


ENCODERS = {
    "nvenc": EncoderChoice("nvenc", "NVIDIA NVENC", "h264_nvenc"),
    "qsv": EncoderChoice("qsv", "Intel Quick Sync", "h264_qsv"),
    "cpu": EncoderChoice("cpu", "CPU / x264", "libx264"),
}


def ffmpeg_binary() -> str:
    """Prefer the user's system FFmpeg (often has NVENC/QSV), then bundled FFmpeg."""
    system_ffmpeg = shutil.which("ffmpeg") or shutil.which("ffmpeg.exe")
    if system_ffmpeg:
        return str(Path(system_ffmpeg).resolve())
    return imageio_ffmpeg.get_ffmpeg_exe()


@lru_cache(maxsize=4)
def available_encoders(binary: str | None = None) -> frozenset[str]:
    binary = binary or ffmpeg_binary()
    try:
        result = subprocess.run(
            [binary, "-hide_banner", "-encoders"],
            capture_output=True, text=True, timeout=12, check=False,
        )
    except (OSError, subprocess.SubprocessError):
        return frozenset({"libx264"})
    found: set[str] = set()
    for line in (result.stdout or "").splitlines():
        # FFmpeg encoder rows start with six capability flags, then the name.
        match = re.match(r"^\s*[VAS\.][A-Z\.]{5}\s+(\S+)", line)
        if match:
            found.add(match.group(1))
    if "libx264" not in found and result.returncode != 0:
        found.add("libx264")
    return frozenset(found)


def encoder_plan(preference: str = "auto", binary: str | None = None) -> list[EncoderChoice]:
    """Return ordered encoders; CPU is always last unless explicitly requested."""
    available = available_encoders(binary)
    pref = (preference or "auto").strip().lower()
    order = {
        "auto": ("nvenc", "qsv", "cpu"),
        "nvidia": ("nvenc", "qsv", "cpu"),
        "nvenc": ("nvenc", "qsv", "cpu"),
        "intel": ("qsv", "nvenc", "cpu"),
        "qsv": ("qsv", "nvenc", "cpu"),
        "cpu": ("cpu",),
        "software": ("cpu",),
    }.get(pref, ("nvenc", "qsv", "cpu"))
    plan = [ENCODERS[key] for key in order if ENCODERS[key].codec in available]
    # Most FFmpeg builds ship libx264; retaining this fallback also handles
    # unusual builds where encoder listing is unavailable.
    if not any(choice.key == "cpu" for choice in plan) and pref not in {"cpu", "software"}:
        plan.append(ENCODERS["cpu"])
    if not plan:
        plan = [ENCODERS["cpu"]]
    return plan


def encoder_preset(choice: EncoderChoice, preset: str) -> str:
    value = (preset or "medium").strip().lower()
    if choice.key == "nvenc":
        return {"ultrafast": "fast", "fast": "fast", "medium": "medium", "slow": "slow"}.get(value, "medium")
    if choice.key == "qsv":
        return {"ultrafast": "veryfast", "fast": "faster", "medium": "medium", "slow": "slow"}.get(value, "medium")
    return value if value in {"ultrafast", "superfast", "veryfast", "faster", "fast", "medium", "slow", "slower", "veryslow"} else "medium"


def set_moviepy_ffmpeg(binary: str | None = None) -> str:
    """Set MoviePy's imported writer to the same FFmpeg used for encoder probing."""
    selected = binary or ffmpeg_binary()
    try:
        from moviepy.video.io import ffmpeg_writer
        ffmpeg_writer.FFMPEG_BINARY = selected
    except Exception:
        pass
    return selected


def hardware_summary(binary: str | None = None) -> dict[str, object]:
    binary = binary or ffmpeg_binary()
    encoders = available_encoders(binary)
    return {
        "ffmpeg": binary,
        "nvenc": "h264_nvenc" in encoders,
        "qsv": "h264_qsv" in encoders,
        "x264": "libx264" in encoders,
    }
