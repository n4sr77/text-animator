"""Reusable visual effects and easing helpers for kinetic text."""

from __future__ import annotations

from typing import Callable
from moviepy import TextClip, CompositeVideoClip
from moviepy.video.fx import FadeIn, FadeOut, Resize


# ---------------------------------------------------------------------------
# Easing
# ---------------------------------------------------------------------------

def ease_out_quad(t: float) -> float:
    return 1 - (1 - t) ** 2


def ease_out_cubic(t: float) -> float:
    return 1 - (1 - t) ** 3


def ease_out_back(t: float, overshoot: float = 1.7) -> float:
    """Slight overshoot (good for Pop & Hold)."""
    t = t - 1
    return t * t * ((overshoot + 1) * t + overshoot) + 1


def bounce_out(t: float) -> float:
    if t < 1 / 2.75:
        return 7.5625 * t * t
    elif t < 2 / 2.75:
        t -= 1.5 / 2.75
        return 7.5625 * t * t + 0.75
    elif t < 2.5 / 2.75:
        t -= 2.25 / 2.75
        return 7.5625 * t * t + 0.9375
    else:
        t -= 2.625 / 2.75
        return 7.5625 * t * t + 0.984375


# ---------------------------------------------------------------------------
# Text styling (outline / shadow)
# ---------------------------------------------------------------------------

def make_styled_text_clip(
    text: str,
    font: str,
    font_size: int,
    color: str,
    duration: float,
    outline: bool = False,
    outline_width: int = 3,
    shadow: bool = False,
    shadow_offset: int = 4,
    method: str = "label",
) -> TextClip:
    """
    Create a TextClip with optional outline and/or soft shadow.
    Outline is simulated by a slightly larger stroke.
    Shadow is attached as metadata so callers can composite it correctly.
    """
    stroke_color = None
    stroke_width = 0

    if outline:
        stroke_color = "white" if color == "black" else "black"
        stroke_width = max(1, outline_width)

    clip = TextClip(
        text=text,
        font=font,
        font_size=font_size,
        color=color,
        stroke_color=stroke_color,
        stroke_width=stroke_width,
        method=method,
        horizontal_align="center",
        vertical_align="center",
        transparent=True,
        duration=duration,
        margin=(20, 15),
    )

    if shadow:
        shadow_color = "black" if color == "white" else "#444444"
        shadow_clip = TextClip(
            text=text,
            font=font,
            font_size=font_size,
            color=shadow_color,
            method=method,
            horizontal_align="center",
            vertical_align="center",
            transparent=True,
            duration=duration,
            margin=(20, 15),
        )
        clip._shadow_clip = shadow_clip       # type: ignore[attr-defined]
        clip._shadow_offset = shadow_offset   # type: ignore[attr-defined]

    return clip


def composite_with_shadow(
    main_clip: TextClip,
    canvas_size: tuple[int, int],
    position: tuple | str = "center",
) -> CompositeVideoClip:
    """
    If *main_clip* carries a shadow clip (attached by make_styled_text_clip),
    composite shadow-below-main onto a transparent layer and return it.
    Otherwise, just return a single-clip composite so callers always get the
    same type back.

    Parameters
    ----------
    main_clip:
        The TextClip produced by make_styled_text_clip.
    canvas_size:
        (width, height) of the destination canvas.
    position:
        Where to place the main clip; shadow is offset automatically.
    """
    # Read from instance storage rather than getattr(): MagicMock and some
    # proxy objects synthesize arbitrary missing attributes on access, which
    # can otherwise be mistaken for a real shadow layer.
    instance_attrs = getattr(main_clip, "__dict__", {})
    shadow: TextClip | None = instance_attrs.get("_shadow_clip")
    offset: int = instance_attrs.get("_shadow_offset", 4)

    if shadow is None:
        return CompositeVideoClip([main_clip.with_position(position)], size=canvas_size)

    # Determine pixel position for the main clip so we can offset the shadow.
    if position == "center":
        cx = (canvas_size[0] - main_clip.w) // 2
        cy = (canvas_size[1] - main_clip.h) // 2
        main_pos = (cx, cy)
    elif isinstance(position, (list, tuple)) and len(position) == 2:
        main_pos = tuple(position)
    else:
        main_pos = position  # type: ignore[assignment]

    if isinstance(main_pos, tuple) and len(main_pos) == 2:
        shadow_pos = (main_pos[0] + offset, main_pos[1] + offset)
    else:
        shadow_pos = main_pos

    return CompositeVideoClip(
        [
            shadow.with_position(shadow_pos),
            main_clip.with_position(main_pos),
        ],
        size=canvas_size,
    )


def apply_fade(clip, fade_in: float = 0.0, fade_out: float = 0.0):
    fx = []
    if fade_in > 0:
        fx.append(FadeIn(min(fade_in, clip.duration * 0.45)))
    if fade_out > 0:
        fx.append(FadeOut(min(fade_out, clip.duration * 0.45)))
    if fx:
        return clip.with_effects(fx)
    return clip


def apply_zoom(
    clip,
    start_scale: float = 0.3,
    end_scale: float = 1.0,
    duration: float | None = None,
    ease: Callable[[float], float] = ease_out_cubic,
):
    """Animated scale from start_scale → end_scale over the first part of the clip."""
    if duration is None:
        duration = min(0.5, clip.duration * 0.55)

    def scale_func(t):
        if t >= duration:
            return end_scale
        p = ease(t / duration)
        return start_scale + (end_scale - start_scale) * p

    return clip.with_effects([Resize(scale_func)])
