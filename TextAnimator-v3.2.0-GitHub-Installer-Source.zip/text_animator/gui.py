"""Tkinter desktop GUI for TextAnimator – polished UI, powerful batch, expanded settings."""

from __future__ import annotations

import os
import sys
import subprocess
import threading
import tkinter as tk
try:
    import ttkbootstrap as ttk
    _HAS_TTKBOOTSTRAP = True
except ImportError:  # Native ttk fallback keeps tests and minimal installs usable.
    from tkinter import ttk
    _HAS_TTKBOOTSTRAP = False

from tkinter import filedialog, messagebox, scrolledtext
from pathlib import Path

from . import __version__
from .config import (
    RESOLUTIONS, DEFAULTS, DEFAULT_OUTPUT, DEFAULT_BATCH_OUT,
    ENCODE_PRESETS, TRANSITIONS, load_user_config, save_user_config,
)
from .fonts import list_font_names, get_default_font
from .presets import PRESET_LABELS, PRESET_NAMES
from .renderer import VideoRenderer, RenderCancelled
from .preview import PreviewEngine
from .batch import (
    BatchRenderer, load_csv_rows, TITLE_KEYS, TEXT_KEYS,
    validate_rows, SAMPLE_CSV_CONTENT, safe_filename,
)
from .media_tools import (
    MediaProcessor, MediaCancelled, SUPPORTED_INPUT_EXTS, OUTPUT_FORMATS, FILTERS,
)
from .hardware import hardware_summary


class ToolTip:
    """Simple tooltip for Tk widgets."""

    def __init__(self, widget, text: str, delay: int = 450):
        self.widget = widget
        self.text = text
        self.delay = delay
        self._id = None
        self._tip = None
        widget.bind("<Enter>", self._schedule)
        widget.bind("<Leave>", self._hide)
        widget.bind("<ButtonPress>", self._hide)

    def _schedule(self, _event=None):
        self._hide()
        self._id = self.widget.after(self.delay, self._show)

    def _show(self):
        if self._tip or not self.text:
            return
        x = self.widget.winfo_rootx() + 20
        y = self.widget.winfo_rooty() + self.widget.winfo_height() + 4
        self._tip = tw = tk.Toplevel(self.widget)
        tw.wm_overrideredirect(True)
        tw.wm_geometry(f"+{x}+{y}")
        label = tk.Label(
            tw, text=self.text, justify=tk.LEFT,
            background="#1e3a54", foreground="#f0f4f8",
            relief=tk.SOLID, borderwidth=1,
            font=("Segoe UI", 9), padx=8, pady=5,
        )
        label.pack()

    def _hide(self, _event=None):
        if self._id:
            self.widget.after_cancel(self._id)
            self._id = None
        if self._tip:
            self._tip.destroy()
            self._tip = None


_WindowBase = ttk.Window if _HAS_TTKBOOTSTRAP else tk.Tk


class TextAnimatorApp(_WindowBase):
    def __init__(self):
        if _HAS_TTKBOOTSTRAP:
            super().__init__(themename="superhero")
        else:
            super().__init__()
        self.title(f"TextAnimator {__version__}  •  Kinetic Type Studio")
        self.geometry("1320x980")
        self.minsize(1040, 780)

        # Refined dark blue-slate theme
        # Mid-blue color scheme
        self._colors = {
            # Tuned to ttkbootstrap's Superhero dark theme.
            "bg_primary": "#2b3e50",
            "bg_secondary": "#203040",
            "bg_tertiary": "#4e5d6c",
            "bg_input": "#32465a",
            "fg_primary": "#ffffff",
            "fg_secondary": "#c8d3dd",
            "fg_dim": "#9aabba",
            "accent": "#df691a",
            "accent_hover": "#f07d2c",
            "success": "#62c462",
            "warning": "#f0ad4e",
            "danger": "#d9534f",
            "border": "#1b2a38",
            "header": "#375a7f",
            "row_done": "#24452f",
            "row_error": "#4a252a",
            "row_skip": "#4a4028",
            "row_run": "#304b64",
        }

        self.configure(bg=self._colors["bg_primary"])

        self.renderer = VideoRenderer()
        self.preview_engine = PreviewEngine()
        self.batch_renderer = BatchRenderer()
        self.media_processor = MediaProcessor()
        self._media_files: list[str] = []
        self.is_busy = False
        self._batch_rows: list[dict] = []
        self._batch_statuses: dict[int, str] = {}  # 1-based index -> status
        self._user_cfg = load_user_config()

        self._setup_style()
        self._build_menu()
        self._build_ui()
        self._bind_shortcuts()
        self.protocol("WM_DELETE_WINDOW", self._on_close)

        # Restore last paths if available
        if self._user_cfg.get("last_csv"):
            self.csv_entry.delete(0, tk.END)
            self.csv_entry.insert(0, self._user_cfg["last_csv"])
        if self._user_cfg.get("last_batch_out"):
            self.batch_out_entry.delete(0, tk.END)
            self.batch_out_entry.insert(0, self._user_cfg["last_batch_out"])
        if self._user_cfg.get("last_output"):
            self.out_entry.delete(0, tk.END)
            self.out_entry.insert(0, self._user_cfg["last_output"])

    # ------------------------------------------------------------------
    # Style
    # ------------------------------------------------------------------
    def _setup_style(self):
        style = ttk.Style()
        c = self._colors

        if _HAS_TTKBOOTSTRAP:
            # Keep ttkbootstrap's semantic widget styling intact instead of
            # repainting every T* style and defeating the selected theme.
            style.theme_use("superhero")
            style.configure("Accent.TButton", padding=(14, 8),
                            font=("Segoe UI", 10, "bold"))
            style.map("Accent.TButton", background=[("active", c["accent_hover"])])
            style.configure("Danger.TButton", padding=(12, 6),
                            font=("Segoe UI", 9, "bold"))
            style.configure("Success.TButton", padding=(12, 6),
                            font=("Segoe UI", 9, "bold"))
            style.configure("Treeview", rowheight=30, borderwidth=0)
            style.configure("Treeview.Heading", padding=(10, 8),
                            font=("Segoe UI", 9, "bold"))
            style.configure("Status.TLabel", font=("Segoe UI", 9), padding=(8, 4))
            style.configure("Card.TLabelframe", padding=10)
            style.configure("Card.TLabelframe.Label", font=("Segoe UI", 10, "bold"))
            return

        # Native ttk fallback for minimal installs.
        style.theme_use("clam")
        bg, fg = c["bg_primary"], c["fg_primary"]
        style.configure(".", background=bg, foreground=fg, font=("Segoe UI", 10))
        style.configure("TLabel", background=bg, foreground=fg)
        style.configure("TFrame", background=bg)
        style.configure("TLabelframe", background=bg, foreground=c["fg_secondary"], bordercolor=c["border"])
        style.configure("TLabelframe.Label", background=bg, foreground=c["accent"], font=("Segoe UI", 10, "bold"))
        style.configure("TButton", background=c["bg_tertiary"], foreground=fg, padding=(12, 6), borderwidth=0)
        style.map("TButton", background=[("active", c["accent"]), ("disabled", c["bg_secondary"])])
        style.configure("Accent.TButton", background=c["accent"], foreground="white",
                        padding=(14, 8), font=("Segoe UI", 10, "bold"))
        style.map("Accent.TButton", background=[("active", c["accent_hover"]), ("disabled", c["bg_secondary"])])
        style.configure("Danger.TButton", background=c["danger"], foreground="white", padding=(12, 6))
        style.map("Danger.TButton", background=[("active", "#f07070")])
        style.configure("Success.TButton", background=c["success"], foreground="white", padding=(12, 6))
        style.configure("TEntry", fieldbackground=c["bg_input"], foreground=fg, insertcolor=fg)
        style.configure("TCombobox", fieldbackground=c["bg_input"], foreground=fg, background=c["bg_input"])
        style.map("TCombobox", fieldbackground=[("readonly", c["bg_input"])],
                  selectbackground=[("readonly", c["accent"])])
        style.configure("TSpinbox", fieldbackground=c["bg_input"], foreground=fg)
        style.configure("TCheckbutton", background=bg, foreground=fg)
        style.configure("TRadiobutton", background=bg, foreground=fg)
        style.configure("TNotebook", background=bg, borderwidth=0)
        style.configure("TNotebook.Tab", background=c["bg_secondary"], foreground=c["fg_secondary"],
                        padding=(16, 8), font=("Segoe UI", 10, "bold"))
        style.map("TNotebook.Tab", background=[("selected", c["bg_tertiary"])],
                  foreground=[("selected", "white")])
        style.configure("Horizontal.TProgressbar", troughcolor=c["bg_secondary"],
                        background=c["accent"], bordercolor=c["border"], lightcolor=c["accent"],
                        darkcolor=c["accent"])
        style.configure("Treeview", background=c["bg_input"], foreground=fg,
                        fieldbackground=c["bg_input"], rowheight=30, borderwidth=0)
        style.configure("Treeview.Heading", background=c["bg_tertiary"], foreground=fg,
                        font=("Segoe UI", 9, "bold"), relief=tk.FLAT, padding=(10, 8))
        style.map("Treeview", background=[("selected", c["accent"])],
                  foreground=[("selected", "white")])
        style.configure("Status.TLabel", background=c["bg_secondary"], foreground=c["fg_secondary"],
                        font=("Segoe UI", 9), padding=(8, 4))

    # ------------------------------------------------------------------
    # Menu
    # ------------------------------------------------------------------
    def _build_menu(self):
        menubar = tk.Menu(self, bg=self._colors["bg_secondary"], fg=self._colors["fg_primary"],
                          activebackground=self._colors["accent"], activeforeground="white",
                          tearoff=0)
        self.config(menu=menubar)

        file_m = tk.Menu(menubar, tearoff=0, bg=self._colors["bg_secondary"],
                         fg=self._colors["fg_primary"], activebackground=self._colors["accent"])
        menubar.add_cascade(label="File", menu=file_m)
        file_m.add_command(label="Open CSV…", command=self._browse_csv, accelerator="Ctrl+O")
        file_m.add_command(label="Add Media Files…", command=self._media_add_files)
        file_m.add_command(label="Add Media Folder…", command=self._media_add_folder)
        file_m.add_command(label="Choose Background…", command=self._browse_bg)
        file_m.add_command(label="Choose Soundtrack…", command=self._browse_audio)
        file_m.add_separator()
        file_m.add_command(label="Save Sample CSV…", command=self._save_sample_csv)
        file_m.add_separator()
        file_m.add_command(label="Export Diagnostics…", command=self._export_diagnostics)
        file_m.add_separator()
        file_m.add_command(label="Exit", command=self._on_close, accelerator="Ctrl+Q")

        edit_m = tk.Menu(menubar, tearoff=0, bg=self._colors["bg_secondary"],
                         fg=self._colors["fg_primary"], activebackground=self._colors["accent"])
        menubar.add_cascade(label="Edit", menu=edit_m)
        edit_m.add_command(label="Clear text", command=self._clear_text)
        edit_m.add_command(label="Reset settings to defaults", command=self._reset_settings)
        edit_m.add_separator()
        edit_m.add_command(label="Generate (Single)", command=self._generate, accelerator="Ctrl+Enter")
        edit_m.add_command(label="Run Batch", command=self._run_batch, accelerator="Ctrl+B")
        edit_m.add_command(label="Cancel", command=self._cancel, accelerator="Esc")

        help_m = tk.Menu(menubar, tearoff=0, bg=self._colors["bg_secondary"],
                         fg=self._colors["fg_primary"], activebackground=self._colors["accent"])
        menubar.add_cascade(label="Help", menu=help_m)
        help_m.add_command(label="CSV format & columns", command=self._show_csv_help)
        help_m.add_command(label="Keyboard shortcuts", command=self._show_shortcuts)
        help_m.add_separator()
        help_m.add_command(label="About TextAnimator", command=self._show_about)

    def _show_error_dialog(self, title: str, message: str, detail: str = "") -> None:
        """Scrollable error dialog with Copy Details button."""
        dlg = tk.Toplevel(self)
        dlg.title(title)
        dlg.geometry("600x380")
        dlg.configure(bg=self._colors["bg_primary"])
        dlg.grab_set()

        tk.Label(dlg, text=message[:200], wraplength=560,
                 bg=self._colors["bg_primary"], fg=self._colors["danger"],
                 font=("Segoe UI", 10, "bold")).pack(padx=16, pady=(16, 4))

        if detail:
            txt = scrolledtext.ScrolledText(dlg, height=12, width=70,
                                            bg=self._colors["bg_input"],
                                            fg=self._colors["fg_primary"],
                                            font=("Courier New", 9))
            txt.insert(tk.END, detail)
            txt.configure(state=tk.DISABLED)
            txt.pack(padx=16, pady=4, fill=tk.BOTH, expand=True)

        btn_row = tk.Frame(dlg, bg=self._colors["bg_primary"])
        btn_row.pack(pady=8)

        full_text = f"{message}\n\n{detail}"

        def _copy():
            dlg.clipboard_clear()
            dlg.clipboard_append(full_text)

        ttk.Button(btn_row, text="Copy Details", command=_copy).pack(side=tk.LEFT, padx=4)
        ttk.Button(btn_row, text="Close", command=dlg.destroy).pack(side=tk.LEFT, padx=4)

    def _bind_shortcuts(self):
        self.bind("<Control-Return>", lambda e: self._generate())
        self.bind("<Control-o>", lambda e: self._browse_csv())
        self.bind("<Control-b>", lambda e: self._run_batch())
        self.bind("<Control-Shift-o>", lambda e: self._media_add_files())
        self.bind("<Control-q>", lambda e: self._on_close())
        self.bind("<Escape>", lambda e: self._cancel())
        self.bind("<Control-p>", lambda e: self.notebook.select(4) if hasattr(self, "notebook") else None)
        self.bind("<Control-Shift-u>", lambda e: _upload_selected(self) if hasattr(self, "_pub_tree") else None)

    # ------------------------------------------------------------------
    # UI construction
    # ------------------------------------------------------------------
    def _build_ui(self):
        c = self._colors

        # Header
        header = tk.Frame(self, bg=c["header"], height=56)
        header.pack(fill=tk.X)
        header.pack_propagate(False)
        tk.Label(header, text="TextAnimator", font=("Segoe UI", 16, "bold"),
                 bg=c["header"], fg="white").pack(side=tk.LEFT, padx=16, pady=10)
        tk.Label(header, text="Kinetic Type + Media Studio", font=("Segoe UI", 10),
                 bg=c["header"], fg=c["fg_secondary"]).pack(side=tk.LEFT, pady=12)
        self.header_counts = tk.Label(header, text="0 words  ·  0 chars",
                                      font=("Segoe UI", 9), bg=c["header"], fg=c["fg_dim"])
        self.header_counts.pack(side=tk.RIGHT, padx=16)

        # Notebook
        notebook = ttk.Notebook(self)
        notebook.pack(fill=tk.BOTH, expand=True, padx=10, pady=(8, 4))
        self.notebook = notebook

        self._build_single_tab(notebook)
        self._build_batch_tab(notebook)
        self._build_media_tab(notebook)
        self._build_settings_tab(notebook)

        # Bottom action bar
        action = tk.Frame(self, bg=c["bg_secondary"], padx=12, pady=10)
        action.pack(fill=tk.X, side=tk.BOTTOM)

        self.btn_preview = ttk.Button(action, text="▶  Preview", command=self._preview,
                                      **({"bootstyle": "info-outline"} if _HAS_TTKBOOTSTRAP else {}))
        self.btn_preview.pack(side=tk.LEFT, padx=(0, 6))
        ToolTip(self.btn_preview, "Generate a fast low-res preview video")

        self.btn_generate = ttk.Button(action, text="Generate Video", style="Accent.TButton",
                                       command=self._generate,
                                       **({"bootstyle": "primary"} if _HAS_TTKBOOTSTRAP else {}))
        self.btn_generate.pack(side=tk.LEFT, padx=(0, 6))
        ToolTip(self.btn_generate, "Render full-quality video (Ctrl+Enter)")

        self.btn_batch = ttk.Button(action, text="Run Batch", style="Success.TButton",
                                    command=self._run_batch,
                                    **({"bootstyle": "success"} if _HAS_TTKBOOTSTRAP else {}))
        self.btn_batch.pack(side=tk.LEFT, padx=(0, 6))
        ToolTip(self.btn_batch, "Process all CSV rows (Ctrl+B)")

        self.btn_cancel = ttk.Button(action, text="Cancel", style="Danger.TButton",
                                     command=self._cancel, state=tk.DISABLED,
                                     **({"bootstyle": "danger"} if _HAS_TTKBOOTSTRAP else {}))
        self.btn_cancel.pack(side=tk.LEFT, padx=(0, 12))

        self.progress = ttk.Progressbar(action, orient=tk.HORIZONTAL, mode="determinate", length=220)
        self.progress.pack(side=tk.LEFT, padx=(0, 10), fill=tk.X, expand=True)

        self.status_var = tk.StringVar(value="Ready")
        status_lbl = ttk.Label(action, textvariable=self.status_var, style="Status.TLabel")
        status_lbl.pack(side=tk.RIGHT)

    # ----- Single tab -----
    def _build_single_tab(self, notebook):
        c = self._colors
        single = ttk.Frame(notebook, padding=10)
        notebook.add(single, text="  Single  ")

        # Text input
        lf_text = ttk.LabelFrame(single, text="  Text  ", padding=8)
        lf_text.pack(fill=tk.X, pady=(0, 8))
        self.text_box = scrolledtext.ScrolledText(
            lf_text, height=4, wrap=tk.WORD, font=("Segoe UI", 11),
            bg=c["bg_input"], fg=c["fg_primary"], insertbackground=c["fg_primary"],
            relief=tk.FLAT, padx=8, pady=6,
        )
        self.text_box.pack(fill=tk.X)
        self.text_box.insert("1.0", "Words become motion")
        self.text_box.bind("<KeyRelease>", self._update_counts)

        # Preset + color
        row1 = ttk.Frame(single)
        row1.pack(fill=tk.X, pady=(0, 8))

        lf_preset = ttk.LabelFrame(row1, text="  Preset  ", padding=8)
        lf_preset.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 6))
        self.preset_var = tk.StringVar(value=DEFAULTS["preset"])
        # Display labels, store keys
        self._preset_label_to_key = {v: k for k, v in PRESET_LABELS.items()}
        self._preset_key_to_label = dict(PRESET_LABELS)
        self.preset_display = tk.StringVar(value=PRESET_LABELS.get(DEFAULTS["preset"], "Classic Kinetic"))
        preset_cb = ttk.Combobox(lf_preset, textvariable=self.preset_display,
                                 values=list(PRESET_LABELS.values()), state="readonly", width=24)
        preset_cb.pack(fill=tk.X)
        def _on_preset_select(_e=None):
            lab = self.preset_display.get()
            self.preset_var.set(self._preset_label_to_key.get(lab, "classic"))
        preset_cb.bind("<<ComboboxSelected>>", _on_preset_select)
        # also radios for quick pick
        radio_f = ttk.Frame(lf_preset)
        radio_f.pack(fill=tk.X, pady=(6, 0))
        for i, (key, label) in enumerate(PRESET_LABELS.items()):
            short = label.replace(" / ", " ")[:14]
            def _make_cmd(k=key, lab=label):
                def _cmd():
                    self.preset_var.set(k)
                    self.preset_display.set(lab)
                return _cmd
            ttk.Radiobutton(radio_f, text=short,
                            variable=self.preset_var, value=key,
                            command=_make_cmd()).grid(row=i // 3, column=i % 3, sticky=tk.W, padx=4)

        lf_color = ttk.LabelFrame(row1, text="  Color mode  ", padding=8)
        lf_color.pack(side=tk.LEFT, fill=tk.Y)
        self.color_var = tk.StringVar(value=DEFAULTS["color_mode"])
        ttk.Radiobutton(lf_color, text="White on Black", variable=self.color_var,
                        value="white_on_black").pack(anchor=tk.W)
        ttk.Radiobutton(lf_color, text="Black on White", variable=self.color_var,
                        value="black_on_white").pack(anchor=tk.W)

        # Effects
        lf_fx = ttk.LabelFrame(single, text="  Effects  ", padding=8)
        lf_fx.pack(fill=tk.X, pady=(0, 8))
        fx_row = ttk.Frame(lf_fx)
        fx_row.pack(fill=tk.X)
        self.outline_var = tk.BooleanVar(value=DEFAULTS["outline"])
        self.shadow_var = tk.BooleanVar(value=DEFAULTS["shadow"])
        ttk.Checkbutton(fx_row, text="Outline", variable=self.outline_var).pack(side=tk.LEFT, padx=(0, 12))
        ttk.Checkbutton(fx_row, text="Shadow", variable=self.shadow_var).pack(side=tk.LEFT, padx=(0, 12))
        self.autofit_var = tk.BooleanVar(value=DEFAULTS["auto_fit_font"])
        ttk.Checkbutton(fx_row, text="Auto-fit font size", variable=self.autofit_var).pack(side=tk.LEFT)

        # Background + Audio
        row_media = ttk.Frame(single)
        row_media.pack(fill=tk.X, pady=(0, 8))

        lf_bg = ttk.LabelFrame(row_media, text="  Background image  ", padding=6)
        lf_bg.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 6))
        bg_row = ttk.Frame(lf_bg)
        bg_row.pack(fill=tk.X)
        self.bg_entry = ttk.Entry(bg_row, font=("Segoe UI", 9))
        self.bg_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 4))
        ttk.Button(bg_row, text="Browse…", command=self._browse_bg).pack(side=tk.LEFT)
        ttk.Button(bg_row, text="Clear", command=lambda: self.bg_entry.delete(0, tk.END)).pack(side=tk.LEFT, padx=(4, 0))

        lf_audio = ttk.LabelFrame(row_media, text="  Soundtrack  ", padding=6)
        lf_audio.pack(side=tk.LEFT, fill=tk.X, expand=True)
        aud_row = ttk.Frame(lf_audio)
        aud_row.pack(fill=tk.X)
        self.audio_entry = ttk.Entry(aud_row, font=("Segoe UI", 9))
        self.audio_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 4))
        ttk.Button(aud_row, text="Browse…", command=self._browse_audio).pack(side=tk.LEFT)
        ttk.Button(aud_row, text="Clear", command=lambda: self.audio_entry.delete(0, tk.END)).pack(side=tk.LEFT, padx=(4, 0))

        # Font + timing
        row_ft = ttk.Frame(single)
        row_ft.pack(fill=tk.X, pady=(0, 8))

        lf_font = ttk.LabelFrame(row_ft, text="  Font  ", padding=6)
        lf_font.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 6))
        f_row = ttk.Frame(lf_font)
        f_row.pack(fill=tk.X)
        fonts = list_font_names()
        default_font = get_default_font()
        self.font_var = tk.StringVar(value=default_font if default_font in fonts else (fonts[0] if fonts else ""))
        ttk.Combobox(f_row, textvariable=self.font_var, values=fonts, width=28).pack(side=tk.LEFT, padx=(0, 8))
        ttk.Label(f_row, text="Size:").pack(side=tk.LEFT)
        self.font_size_var = tk.IntVar(value=DEFAULTS["font_size"])
        ttk.Spinbox(f_row, from_=20, to=300, textvariable=self.font_size_var, width=5).pack(side=tk.LEFT, padx=4)

        lf_time = ttk.LabelFrame(row_ft, text="  Timing (seconds)  ", padding=6)
        lf_time.pack(side=tk.LEFT, fill=tk.X, expand=True)
        t_row = ttk.Frame(lf_time)
        t_row.pack(fill=tk.X)
        ttk.Label(t_row, text="Word:").pack(side=tk.LEFT)
        self.word_dur_var = tk.DoubleVar(value=DEFAULTS["word_duration"])
        ttk.Spinbox(t_row, from_=0.2, to=5.0, increment=0.05, textvariable=self.word_dur_var, width=5).pack(side=tk.LEFT, padx=4)
        ttk.Label(t_row, text="Gap:").pack(side=tk.LEFT, padx=(8, 0))
        self.gap_var = tk.DoubleVar(value=DEFAULTS["gap"])
        ttk.Spinbox(t_row, from_=0.0, to=2.0, increment=0.02, textvariable=self.gap_var, width=5).pack(side=tk.LEFT, padx=4)
        ttk.Label(t_row, text="End hold:").pack(side=tk.LEFT, padx=(8, 0))
        self.end_hold_var = tk.DoubleVar(value=DEFAULTS["end_hold"])
        ttk.Spinbox(t_row, from_=0.0, to=10.0, increment=0.1, textvariable=self.end_hold_var, width=5).pack(side=tk.LEFT, padx=4)

        # Output options
        lf_out = ttk.LabelFrame(single, text="  Output  ", padding=8)
        lf_out.pack(fill=tk.X, pady=(0, 4))

        o1 = ttk.Frame(lf_out)
        o1.pack(fill=tk.X, pady=(0, 4))
        ttk.Label(o1, text="Resolution:").pack(side=tk.LEFT)
        self.res_var = tk.StringVar(value=DEFAULTS["resolution"])
        ttk.Combobox(o1, textvariable=self.res_var, values=list(RESOLUTIONS.keys()),
                     state="readonly", width=18).pack(side=tk.LEFT, padx=6)
        ttk.Label(o1, text="FPS:").pack(side=tk.LEFT, padx=(12, 0))
        self.fps_var = tk.IntVar(value=DEFAULTS["fps"])
        ttk.Spinbox(o1, from_=15, to=60, textvariable=self.fps_var, width=5).pack(side=tk.LEFT, padx=4)
        ttk.Label(o1, text="Transition:").pack(side=tk.LEFT, padx=(12, 0))
        self.trans_var = tk.StringVar(value="Smooth fade")
        ttk.Combobox(o1, textvariable=self.trans_var, values=list(TRANSITIONS.keys()),
                     state="readonly", width=14).pack(side=tk.LEFT, padx=4)

        o2 = ttk.Frame(lf_out)
        o2.pack(fill=tk.X)
        ttk.Label(o2, text="Save as:").pack(side=tk.LEFT)
        self.out_entry = ttk.Entry(o2, font=("Segoe UI", 9))
        self.out_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=6)
        self.out_entry.insert(0, DEFAULT_OUTPUT)
        ttk.Button(o2, text="Browse…", command=self._browse_out).pack(side=tk.LEFT)

        self._update_counts()

    # ----- Batch tab (heavily improved) -----
    def _build_batch_tab(self, notebook):
        c = self._colors
        batch = ttk.Frame(notebook, padding=10)
        notebook.add(batch, text="  Batch  ")

        # Keep queue setup and render defaults in separate, clear sub-tabs.
        # Batch defaults are intentionally independent from the Single tab.
        batch_tabs = ttk.Notebook(batch)
        batch_tabs.pack(fill=tk.BOTH, expand=True)
        self.batch_notebook = batch_tabs
        queue_page = ttk.Frame(batch_tabs, padding=8)
        settings_page = ttk.Frame(batch_tabs, padding=8)
        batch_tabs.add(queue_page, text="  Queue & Output  ")
        batch_tabs.add(settings_page, text="  Batch Render Settings  ")
        self._build_batch_render_settings(settings_page)

        # CSV source
        lf_csv = ttk.LabelFrame(queue_page, text="  CSV Source  ", padding=8)
        lf_csv.pack(fill=tk.X, pady=(0, 8))
        csv_row = ttk.Frame(lf_csv)
        csv_row.pack(fill=tk.X)
        self.csv_entry = ttk.Entry(csv_row, font=("Segoe UI", 9))
        self.csv_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 6))
        ttk.Button(csv_row, text="Browse…", command=self._browse_csv).pack(side=tk.LEFT, padx=(0, 4))
        ttk.Button(csv_row, text="Load & Validate", command=self._load_csv_preview).pack(side=tk.LEFT, padx=(0, 4))
        ttk.Button(csv_row, text="Sample CSV…", command=self._save_sample_csv).pack(side=tk.LEFT)
        ttk.Label(lf_csv, text="Required: title (or name) + sentence (or text).  Optional: preset, color_mode, font_size, "
                               "font, word_duration, gap, end_hold, fps, outline, shadow, resolution, transition, bg_image, audio",
                  foreground=c["fg_dim"], font=("Segoe UI", 8), wraplength=1000).pack(anchor=tk.W, pady=(6, 0))

        # Output + options
        opts = ttk.Frame(queue_page)
        opts.pack(fill=tk.X, pady=(0, 8))

        lf_bout = ttk.LabelFrame(opts, text="  Output Folder  ", padding=6)
        lf_bout.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 6))
        bout_row = ttk.Frame(lf_bout)
        bout_row.pack(fill=tk.X)
        self.batch_out_entry = ttk.Entry(bout_row, font=("Segoe UI", 9))
        self.batch_out_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 6))
        self.batch_out_entry.insert(0, DEFAULT_BATCH_OUT)
        ttk.Button(bout_row, text="Browse…", command=self._browse_batch_out).pack(side=tk.LEFT)

        lf_bopt = ttk.LabelFrame(opts, text="  Batch Options  ", padding=6)
        lf_bopt.pack(side=tk.LEFT, fill=tk.Y)
        self.skip_existing_var = tk.BooleanVar(value=DEFAULTS["skip_existing"])
        ttk.Checkbutton(lf_bopt, text="Skip existing files", variable=self.skip_existing_var).pack(anchor=tk.W)
        self.open_folder_var = tk.BooleanVar(value=DEFAULTS["open_folder_when_done"])
        ttk.Checkbutton(lf_bopt, text="Open folder when done", variable=self.open_folder_var).pack(anchor=tk.W)
        variant_row = ttk.Frame(lf_bopt)
        variant_row.pack(anchor=tk.W, pady=(4, 0))
        ttk.Label(variant_row, text="Variants / row:").pack(side=tk.LEFT)
        self.batch_variants_var = tk.IntVar(value=1)
        ttk.Spinbox(variant_row, from_=1, to=10, textvariable=self.batch_variants_var, width=4).pack(side=tk.LEFT, padx=5)

        lf_batch_audio = ttk.LabelFrame(queue_page, text="  Batch Soundtrack Assignment  ", padding=8)
        lf_batch_audio.pack(fill=tk.X, pady=(0, 8))
        audio_policy_row = ttk.Frame(lf_batch_audio)
        audio_policy_row.pack(fill=tk.X)
        ttk.Label(audio_policy_row, text="Fallback audio:").pack(side=tk.LEFT)
        batch_audio_labels = {
            "fixed": "Selected / CSV track",
            "random": "Random from folder",
            "none": "No fallback track",
        }
        self._batch_audio_label_to_key = {v: k for k, v in batch_audio_labels.items()}
        self.batch_audio_mode_var = tk.StringVar(
            value=batch_audio_labels.get(self._user_cfg.get("batch_audio_mode", "fixed"),
                                         batch_audio_labels["fixed"])
        )
        ttk.Combobox(
            audio_policy_row, textvariable=self.batch_audio_mode_var,
            values=list(batch_audio_labels.values()), state="readonly", width=22,
        ).pack(side=tk.LEFT, padx=(6, 12))
        ttk.Label(audio_policy_row, text="Audio folder for Random:").pack(side=tk.LEFT)
        self.batch_audio_folder_var = tk.StringVar(
            value=self._user_cfg.get("batch_audio_folder", "")
        )
        ttk.Entry(audio_policy_row, textvariable=self.batch_audio_folder_var).pack(
            side=tk.LEFT, fill=tk.X, expand=True, padx=6
        )
        ttk.Button(audio_policy_row, text="Browse…", command=self._browse_batch_audio_folder).pack(side=tk.LEFT)
        fixed_batch_row = ttk.Frame(lf_batch_audio)
        fixed_batch_row.pack(fill=tk.X, pady=(7, 0))
        ttk.Label(fixed_batch_row, text="Fixed batch track:").pack(side=tk.LEFT)
        self.batch_fixed_audio_var = tk.StringVar(
            value=self._user_cfg.get("batch_fixed_audio", "")
        )
        ttk.Entry(fixed_batch_row, textvariable=self.batch_fixed_audio_var).pack(
            side=tk.LEFT, fill=tk.X, expand=True, padx=6
        )
        ttk.Button(fixed_batch_row, text="Browse file…", command=self._browse_batch_fixed_audio).pack(side=tk.LEFT)
        ttk.Button(fixed_batch_row, text="Clear", command=lambda: self.batch_fixed_audio_var.set("")).pack(side=tk.LEFT, padx=(5, 0))
        ttk.Label(
            lf_batch_audio,
            text="Priority: CSV row audio → Fixed batch track → Random folder → no audio. CSV paths can be absolute or relative to the CSV file. Use 'none' in a row to force silence. Random tracks are shuffled without repeats until the folder has been cycled.",
            foreground=c["fg_dim"], font=("Segoe UI", 8), wraplength=1100,
        ).pack(anchor=tk.W, pady=(5, 0))

        # Treeview with richer columns
        lf_tree = ttk.LabelFrame(queue_page, text="  Rows  ", padding=6)
        lf_tree.pack(fill=tk.BOTH, expand=True, pady=(0, 6))

        cols = ("#", "title", "sentence", "preset", "color", "status")
        self.tree = ttk.Treeview(lf_tree, columns=cols, show="headings", height=14, selectmode="extended")
        self.tree.heading("#", text="#")
        self.tree.heading("title", text="Title / Filename")
        self.tree.heading("sentence", text="Text")
        self.tree.heading("preset", text="Preset")
        self.tree.heading("color", text="Color")
        self.tree.heading("status", text="Status")
        self.tree.column("#", width=40, anchor=tk.CENTER, stretch=False)
        self.tree.column("title", width=160, stretch=False)
        self.tree.column("sentence", width=380)
        self.tree.column("preset", width=100, stretch=False)
        self.tree.column("color", width=110, stretch=False)
        self.tree.column("status", width=140, stretch=False)

        scroll_y = ttk.Scrollbar(lf_tree, orient=tk.VERTICAL, command=self.tree.yview)
        scroll_x = ttk.Scrollbar(lf_tree, orient=tk.HORIZONTAL, command=self.tree.xview)
        self.tree.configure(yscrollcommand=scroll_y.set, xscrollcommand=scroll_x.set)
        self.tree.grid(row=0, column=0, sticky="nsew")
        scroll_y.grid(row=0, column=1, sticky="ns")
        scroll_x.grid(row=1, column=0, sticky="ew")
        lf_tree.rowconfigure(0, weight=1)
        lf_tree.columnconfigure(0, weight=1)

        # Tags for status coloring
        self.tree.tag_configure("done", background="#2a5a3a")
        self.tree.tag_configure("error", background="#5a2a2a")
        self.tree.tag_configure("skipped", background="#4a4a2a")
        self.tree.tag_configure("running", background="#2a4a6a")
        self.tree.tag_configure("pending", background=c["bg_input"])

        # Batch status line
        self.batch_status = ttk.Label(queue_page, text="No CSV loaded — click “Load & Validate” or drop a CSV path above",
                                      foreground=c["fg_dim"], font=("Segoe UI", 9))
        self.batch_status.pack(anchor=tk.W)

    def _build_batch_render_settings(self, parent):
        """Build a fully independent set of Batch rendering defaults."""
        c = self._colors
        saved = self._user_cfg.get("batch_render_settings", {})
        if not isinstance(saved, dict):
            saved = {}
        fonts = list_font_names()
        default_font = get_default_font()
        if default_font not in fonts and fonts:
            default_font = fonts[0]

        intro = ttk.Frame(parent)
        intro.pack(fill=tk.X, pady=(0, 8))
        ttk.Label(
            intro,
            text="These defaults are used only by Batch. CSV columns override them row by row when populated.",
            foreground=c["fg_secondary"], wraplength=1100,
        ).pack(side=tk.LEFT, anchor=tk.W)
        ttk.Label(intro, text="Independent from Single", foreground=c["success"]).pack(side=tk.RIGHT)

        grid = ttk.Frame(parent)
        grid.pack(fill=tk.BOTH, expand=True)
        for col in range(3):
            grid.columnconfigure(col, weight=1, uniform="batch-settings")

        # Typography and animation preset.
        lf_typo = ttk.LabelFrame(grid, text="  Typography & Preset  ", padding=8)
        lf_typo.grid(row=0, column=0, sticky="nsew", padx=(0, 6), pady=(0, 6))
        saved_preset = saved.get("preset", DEFAULTS["preset"])
        if saved_preset not in PRESET_LABELS:
            saved_preset = DEFAULTS["preset"]
        self.batch_preset_var = tk.StringVar(value=saved_preset)
        self.batch_preset_display_var = tk.StringVar(value=PRESET_LABELS[saved_preset])
        preset_cb = ttk.Combobox(
            lf_typo, textvariable=self.batch_preset_display_var,
            values=list(PRESET_LABELS.values()), state="readonly", width=25,
        )
        preset_cb.pack(fill=tk.X, pady=(0, 6))
        preset_cb.bind("<<ComboboxSelected>>", self._on_batch_preset_selected)
        ttk.Label(lf_typo, text="Color mode").pack(anchor=tk.W)
        self.batch_color_var = tk.StringVar(value=saved.get("color_mode", DEFAULTS["color_mode"]))
        color_row = ttk.Frame(lf_typo)
        color_row.pack(fill=tk.X, pady=(2, 5))
        ttk.Radiobutton(color_row, text="White on Black", variable=self.batch_color_var,
                        value="white_on_black").pack(side=tk.LEFT)
        ttk.Radiobutton(color_row, text="Black on White", variable=self.batch_color_var,
                        value="black_on_white").pack(side=tk.LEFT, padx=(8, 0))
        ttk.Label(lf_typo, text="Font").pack(anchor=tk.W)
        self.batch_font_var = tk.StringVar(value=saved.get("font", default_font))
        ttk.Combobox(lf_typo, textvariable=self.batch_font_var, values=fonts, width=30).pack(fill=tk.X, pady=(2, 5))
        font_size_row = ttk.Frame(lf_typo)
        font_size_row.pack(fill=tk.X)
        ttk.Label(font_size_row, text="Font size:").pack(side=tk.LEFT)
        self.batch_font_size_var = tk.IntVar(value=int(saved.get("font_size", DEFAULTS["font_size"])))
        ttk.Spinbox(font_size_row, from_=20, to=300, textvariable=self.batch_font_size_var, width=7).pack(side=tk.LEFT, padx=6)

        # Timing.
        lf_timing = ttk.LabelFrame(grid, text="  Timing (seconds)  ", padding=8)
        lf_timing.grid(row=0, column=1, sticky="nsew", padx=3, pady=(0, 6))
        timing_fields = (
            ("Word duration:", "batch_word_duration_var", "word_duration", 0.85, 0.2, 5.0, 0.05),
            ("Gap:", "batch_gap_var", "gap", 0.08, 0.0, 2.0, 0.02),
            ("End hold:", "batch_end_hold_var", "end_hold", 1.2, 0.0, 10.0, 0.1),
        )
        for label, attr, key, default, lower, upper, step in timing_fields:
            r = ttk.Frame(lf_timing)
            r.pack(fill=tk.X, pady=4)
            ttk.Label(r, text=label).pack(side=tk.LEFT)
            var = tk.DoubleVar(value=float(saved.get(key, DEFAULTS[key])))
            setattr(self, attr, var)
            ttk.Spinbox(r, from_=lower, to=upper, increment=step, textvariable=var, width=9).pack(side=tk.RIGHT)

        # Output.
        lf_output = ttk.LabelFrame(grid, text="  Output & Transitions  ", padding=8)
        lf_output.grid(row=0, column=2, sticky="nsew", padx=(6, 0), pady=(0, 6))
        ttk.Label(lf_output, text="Resolution").pack(anchor=tk.W)
        self.batch_resolution_var = tk.StringVar(value=saved.get("resolution", DEFAULTS["resolution"]))
        ttk.Combobox(lf_output, textvariable=self.batch_resolution_var, values=list(RESOLUTIONS.keys()),
                     state="readonly", width=27).pack(fill=tk.X, pady=(2, 6))
        output_row = ttk.Frame(lf_output)
        output_row.pack(fill=tk.X, pady=3)
        ttk.Label(output_row, text="FPS:").pack(side=tk.LEFT)
        self.batch_fps_var = tk.IntVar(value=int(saved.get("fps", DEFAULTS["fps"])))
        ttk.Spinbox(output_row, from_=15, to=60, textvariable=self.batch_fps_var, width=6).pack(side=tk.LEFT, padx=6)
        ttk.Label(lf_output, text="Transition").pack(anchor=tk.W, pady=(5, 0))
        self.batch_transition_label_to_key = dict(TRANSITIONS)
        self.batch_transition_key_to_label = {key: label for label, key in TRANSITIONS.items()}
        self.batch_transition_var = tk.StringVar(
            value=self.batch_transition_key_to_label.get(saved.get("transition", DEFAULTS["transition"]), "Smooth fade")
        )
        ttk.Combobox(lf_output, textvariable=self.batch_transition_var,
                     values=list(TRANSITIONS.keys()), state="readonly", width=25).pack(fill=tk.X, pady=(2, 5))
        td_row = ttk.Frame(lf_output)
        td_row.pack(fill=tk.X)
        ttk.Label(td_row, text="Transition duration:").pack(side=tk.LEFT)
        self.batch_transition_duration_var = tk.DoubleVar(
            value=float(saved.get("transition_duration", DEFAULTS["transition_duration"]))
        )
        ttk.Spinbox(td_row, from_=0.05, to=1.5, increment=0.05,
                    textvariable=self.batch_transition_duration_var, width=7).pack(side=tk.RIGHT)

        # Visual effects and background image.
        lf_effects = ttk.LabelFrame(grid, text="  Visual Effects  ", padding=8)
        lf_effects.grid(row=1, column=0, sticky="nsew", padx=(0, 6), pady=3)
        effect_top = ttk.Frame(lf_effects)
        effect_top.pack(fill=tk.X)
        self.batch_outline_var = tk.BooleanVar(value=bool(saved.get("outline", DEFAULTS["outline"])))
        self.batch_shadow_var = tk.BooleanVar(value=bool(saved.get("shadow", DEFAULTS["shadow"])))
        self.batch_autofit_var = tk.BooleanVar(value=bool(saved.get("auto_fit_font", DEFAULTS["auto_fit_font"])))
        ttk.Checkbutton(effect_top, text="Outline", variable=self.batch_outline_var).pack(side=tk.LEFT)
        ttk.Checkbutton(effect_top, text="Shadow", variable=self.batch_shadow_var).pack(side=tk.LEFT, padx=8)
        ttk.Checkbutton(lf_effects, text="Auto-fit font size", variable=self.batch_autofit_var).pack(anchor=tk.W, pady=(4, 4))
        outline_row = ttk.Frame(lf_effects)
        outline_row.pack(fill=tk.X, pady=2)
        ttk.Label(outline_row, text="Outline width (px):").pack(side=tk.LEFT)
        self.batch_outline_width_var = tk.IntVar(value=int(saved.get("outline_width", DEFAULTS["outline_width"])))
        ttk.Spinbox(outline_row, from_=1, to=16, textvariable=self.batch_outline_width_var, width=6).pack(side=tk.RIGHT)
        shadow_row = ttk.Frame(lf_effects)
        shadow_row.pack(fill=tk.X, pady=2)
        ttk.Label(shadow_row, text="Shadow offset (px):").pack(side=tk.LEFT)
        self.batch_shadow_offset_var = tk.IntVar(value=int(saved.get("shadow_offset", DEFAULTS["shadow_offset"])))
        ttk.Spinbox(shadow_row, from_=1, to=24, textvariable=self.batch_shadow_offset_var, width=6).pack(side=tk.RIGHT)

        lf_bg = ttk.LabelFrame(grid, text="  Background Image  ", padding=8)
        lf_bg.grid(row=1, column=1, sticky="nsew", padx=3, pady=3)
        self.batch_bg_var = tk.StringVar(value=saved.get("bg_image_path", ""))
        bg_entry = ttk.Entry(lf_bg, textvariable=self.batch_bg_var)
        bg_entry.pack(fill=tk.X, pady=(0, 7))
        bg_buttons = ttk.Frame(lf_bg)
        bg_buttons.pack(fill=tk.X)
        ttk.Button(bg_buttons, text="Browse…", command=self._browse_batch_bg).pack(side=tk.LEFT)
        ttk.Button(bg_buttons, text="Clear", command=lambda: self.batch_bg_var.set("")).pack(side=tk.LEFT, padx=6)
        ttk.Label(lf_bg, text="Used as the default background for rows without a CSV bg_image value.",
                  foreground=c["fg_dim"], wraplength=320).pack(anchor=tk.W, pady=(7, 0))

        lf_audio = ttk.LabelFrame(grid, text="  Audio Mix  ", padding=8)
        lf_audio.grid(row=1, column=2, sticky="nsew", padx=(6, 0), pady=3)
        audio_fields = (
            ("Volume (0–1):", "batch_audio_volume_var", "audio_volume", DEFAULTS["audio_volume"], 0.0, 1.0, 0.05),
            ("Fade in (s):", "batch_audio_fade_in_var", "audio_fade_in", DEFAULTS["audio_fade_in"], 0.0, 10.0, 0.05),
            ("Fade out (s):", "batch_audio_fade_out_var", "audio_fade_out", DEFAULTS["audio_fade_out"], 0.0, 10.0, 0.05),
        )
        for label, attr, key, default, lower, upper, step in audio_fields:
            r = ttk.Frame(lf_audio)
            r.pack(fill=tk.X, pady=4)
            ttk.Label(r, text=label).pack(side=tk.LEFT)
            var = tk.DoubleVar(value=float(saved.get(key, default)))
            setattr(self, attr, var)
            ttk.Spinbox(r, from_=lower, to=upper, increment=step, textvariable=var, width=8).pack(side=tk.RIGHT)
        ttk.Label(lf_audio, text="Track selection is configured in Queue & Output → Batch Soundtrack Assignment.",
                  foreground=c["fg_dim"], wraplength=320).pack(anchor=tk.W, pady=(5, 0))

        lf_encoding = ttk.LabelFrame(grid, text="  Encoding & Hardware  ", padding=8)
        lf_encoding.grid(row=2, column=0, columnspan=3, sticky="ew", pady=(3, 6))
        enc_row = ttk.Frame(lf_encoding)
        enc_row.pack(fill=tk.X)
        ttk.Label(enc_row, text="Quality preset:").pack(side=tk.LEFT)
        self.batch_encode_var = tk.StringVar(value=saved.get("encode_preset_label", DEFAULTS["encode_preset"]))
        ttk.Combobox(enc_row, textvariable=self.batch_encode_var, values=list(ENCODE_PRESETS.keys()),
                     state="readonly", width=21).pack(side=tk.LEFT, padx=(6, 18))
        ttk.Label(enc_row, text="Hardware encoder:").pack(side=tk.LEFT)
        batch_hw_labels = {
            "auto": "Auto (recommended)", "nvidia": "NVIDIA NVENC",
            "intel": "Intel Quick Sync", "cpu": "CPU only",
        }
        self.batch_hardware_label_to_key = {v: k for k, v in batch_hw_labels.items()}
        self.batch_hardware_var = tk.StringVar(
            value=batch_hw_labels.get(saved.get("hardware_backend", "auto"), batch_hw_labels["auto"])
        )
        ttk.Combobox(enc_row, textvariable=self.batch_hardware_var, values=list(batch_hw_labels.values()),
                     state="readonly", width=22).pack(side=tk.LEFT, padx=6)
        ttk.Label(lf_encoding,
                  text="Auto tries NVIDIA NVENC, then Intel Quick Sync, then CPU. Frame composition remains CPU-based.",
                  foreground=c["fg_dim"], wraplength=1050).pack(anchor=tk.W, pady=(6, 0))
        hw_actions = ttk.Frame(lf_encoding)
        hw_actions.pack(fill=tk.X, pady=(5, 0))
        ttk.Button(hw_actions, text="Detect available FFmpeg encoders",
                   command=self._detect_hardware_encoders).pack(side=tk.LEFT)
        self.batch_hardware_status_var = tk.StringVar(value="Encoder detection runs against the FFmpeg build selected by TextAnimator.")
        ttk.Label(hw_actions, textvariable=self.batch_hardware_status_var,
                  foreground=c["fg_dim"]).pack(side=tk.LEFT, padx=10)

        actions = ttk.Frame(parent)
        actions.pack(fill=tk.X, pady=(8, 0))
        ttk.Button(actions, text="Save Batch Defaults", command=self._save_batch_render_settings).pack(side=tk.LEFT)
        ttk.Button(actions, text="Copy Single Settings → Batch", command=self._copy_single_to_batch).pack(side=tk.LEFT, padx=6)
        ttk.Button(actions, text="Reset Batch Defaults", command=self._reset_batch_render_settings).pack(side=tk.LEFT)
        self.batch_settings_status_var = tk.StringVar(value="Batch defaults are independent and saved when you run a batch.")
        ttk.Label(actions, textvariable=self.batch_settings_status_var,
                  foreground=c["fg_dim"]).pack(side=tk.RIGHT)

    def _on_batch_preset_selected(self, _event=None):
        label = self.batch_preset_display_var.get()
        self.batch_preset_var.set(self._preset_label_to_key.get(label, "classic"))

    def _batch_render_settings_payload(self):
        bg = self.batch_bg_var.get().strip() or None
        if bg and not os.path.isfile(bg):
            bg = None
        return {
            "preset": self.batch_preset_var.get(),
            "color_mode": self.batch_color_var.get(),
            "font": self.batch_font_var.get().strip(),
            "font_size": int(self.batch_font_size_var.get()),
            "word_duration": float(self.batch_word_duration_var.get()),
            "gap": float(self.batch_gap_var.get()),
            "end_hold": float(self.batch_end_hold_var.get()),
            "fps": int(self.batch_fps_var.get()),
            "resolution": self.batch_resolution_var.get(),
            "outline": bool(self.batch_outline_var.get()),
            "shadow": bool(self.batch_shadow_var.get()),
            "outline_width": int(self.batch_outline_width_var.get()),
            "shadow_offset": int(self.batch_shadow_offset_var.get()),
            "auto_fit_font": bool(self.batch_autofit_var.get()),
            "bg_image_path": bg,
            "encode_preset_label": self.batch_encode_var.get(),
            "encode_preset": ENCODE_PRESETS.get(self.batch_encode_var.get(), "medium"),
            "hardware_backend": self.batch_hardware_label_to_key.get(self.batch_hardware_var.get(), "auto"),
            "transition": self.batch_transition_label_to_key.get(self.batch_transition_var.get(), "fade"),
            "transition_duration": float(self.batch_transition_duration_var.get()),
            "audio_volume": float(self.batch_audio_volume_var.get()),
            "audio_fade_in": float(self.batch_audio_fade_in_var.get()),
            "audio_fade_out": float(self.batch_audio_fade_out_var.get()),
        }

    def _save_batch_render_settings(self):
        try:
            payload = self._batch_render_settings_payload()
            save_user_config({"batch_render_settings": payload})
            self._user_cfg["batch_render_settings"] = payload
            self.batch_settings_status_var.set("Batch defaults saved")
        except (ValueError, tk.TclError) as exc:
            messagebox.showerror("Invalid Batch settings", f"Check the Batch render values: {exc}")

    def _copy_single_to_batch(self):
        """Explicit one-time copy; later edits stay independent."""
        params = self._gather_params()
        self.batch_preset_var.set(params["preset_name"])
        self.batch_preset_display_var.set(PRESET_LABELS.get(params["preset_name"], "Classic Kinetic"))
        self.batch_color_var.set(params["color_mode"])
        self.batch_font_var.set(params["font_name_or_path"])
        self.batch_font_size_var.set(params["font_size"])
        self.batch_word_duration_var.set(params["word_duration"])
        self.batch_gap_var.set(params["gap"])
        self.batch_end_hold_var.set(params["end_hold"])
        self.batch_fps_var.set(params["fps"])
        for label, size in RESOLUTIONS.items():
            if size == params["size"]:
                self.batch_resolution_var.set(label)
                break
        self.batch_outline_var.set(params["outline"])
        self.batch_shadow_var.set(params["shadow"])
        self.batch_outline_width_var.set(params["outline_width"])
        self.batch_shadow_offset_var.set(params["shadow_offset"])
        self.batch_autofit_var.set(params["auto_fit_font"])
        self.batch_bg_var.set(params["bg_image_path"] or "")
        self.batch_encode_var.set(self.encode_var.get())
        self.batch_hardware_var.set(self.hardware_backend_var.get())
        self.batch_transition_var.set(self.trans_var.get())
        self.batch_transition_duration_var.set(params["transition_duration"])
        self.batch_audio_volume_var.set(params["audio_volume"])
        self.batch_audio_fade_in_var.set(params["audio_fade_in"])
        self.batch_audio_fade_out_var.set(params["audio_fade_out"])
        self.batch_settings_status_var.set("Copied once from Single; Batch settings are now independent")

    def _reset_batch_render_settings(self):
        self.batch_preset_var.set(DEFAULTS["preset"])
        self.batch_preset_display_var.set(PRESET_LABELS.get(DEFAULTS["preset"], "Classic Kinetic"))
        self.batch_color_var.set(DEFAULTS["color_mode"])
        default_font = get_default_font()
        fonts = list_font_names()
        self.batch_font_var.set(default_font if default_font in fonts else (fonts[0] if fonts else ""))
        self.batch_font_size_var.set(DEFAULTS["font_size"])
        self.batch_word_duration_var.set(DEFAULTS["word_duration"])
        self.batch_gap_var.set(DEFAULTS["gap"])
        self.batch_end_hold_var.set(DEFAULTS["end_hold"])
        self.batch_fps_var.set(DEFAULTS["fps"])
        self.batch_resolution_var.set(DEFAULTS["resolution"])
        self.batch_outline_var.set(DEFAULTS["outline"])
        self.batch_shadow_var.set(DEFAULTS["shadow"])
        self.batch_outline_width_var.set(DEFAULTS["outline_width"])
        self.batch_shadow_offset_var.set(DEFAULTS["shadow_offset"])
        self.batch_autofit_var.set(DEFAULTS["auto_fit_font"])
        self.batch_bg_var.set("")
        self.batch_encode_var.set(DEFAULTS["encode_preset"])
        self.batch_hardware_var.set("Auto (recommended)")
        self.batch_transition_var.set("Smooth fade")
        self.batch_transition_duration_var.set(DEFAULTS["transition_duration"])
        self.batch_audio_volume_var.set(DEFAULTS["audio_volume"])
        self.batch_audio_fade_in_var.set(DEFAULTS["audio_fade_in"])
        self.batch_audio_fade_out_var.set(DEFAULTS["audio_fade_out"])
        self._save_batch_render_settings()
        self.batch_settings_status_var.set("Batch defaults reset")

    def _browse_batch_bg(self):
        path = filedialog.askopenfilename(
            title="Choose the default Batch background image",
            filetypes=[("Images", "*.png *.jpg *.jpeg *.webp *.bmp"), ("All files", "*.*")],
        )
        if path:
            self.batch_bg_var.set(path)

    # ----- Media Studio tab -----
    def _build_media_tab(self, notebook):
        c = self._colors
        media = ttk.Frame(notebook, padding=10)
        notebook.add(media, text="  Media Studio  ")

        head = tk.Frame(media, bg=c["bg_secondary"], padx=12, pady=8)
        head.pack(fill=tk.X, pady=(0, 8))
        tk.Label(head, text="Batch Media Studio", bg=c["bg_secondary"], fg="white",
                 font=("Segoe UI", 12, "bold")).pack(anchor=tk.W)
        tk.Label(head, text="Convert, resize and apply effects to image, video and audio files — processed locally.",
                 bg=c["bg_secondary"], fg=c["fg_secondary"], font=("Segoe UI", 9)).pack(anchor=tk.W, pady=(2, 0))

        lf_queue = ttk.LabelFrame(media, text="  Processing Queue  ", padding=8)
        lf_queue.pack(fill=tk.BOTH, expand=True, pady=(0, 8))
        tools = ttk.Frame(lf_queue)
        tools.pack(fill=tk.X, pady=(0, 6))
        ttk.Button(tools, text="＋ Add Files", command=self._media_add_files).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(tools, text="＋ Add Folder", command=self._media_add_folder).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(tools, text="Remove Selected", command=self._media_remove_selected).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(tools, text="Clear Queue", command=self._media_clear_queue).pack(side=tk.LEFT, padx=(0, 5))
        self.media_queue_count = ttk.Label(tools, text="0 files", foreground=c["fg_dim"])
        self.media_queue_count.pack(side=tk.RIGHT)

        columns = ("number", "file", "type", "format", "status")
        queue_grid = ttk.Frame(lf_queue)
        queue_grid.pack(fill=tk.BOTH, expand=True)
        self.media_tree = ttk.Treeview(queue_grid, columns=columns, show="headings", height=9,
                                       selectmode="extended")
        for col, title in (("number", "#"), ("file", "File"), ("type", "Type"),
                           ("format", "Source format"), ("status", "Status")):
            self.media_tree.heading(col, text=title)
        self.media_tree.column("number", width=44, anchor=tk.CENTER, stretch=False)
        self.media_tree.column("file", width=500, anchor=tk.W)
        self.media_tree.column("type", width=90, anchor=tk.CENTER, stretch=False)
        self.media_tree.column("format", width=110, anchor=tk.CENTER, stretch=False)
        self.media_tree.column("status", width=300, anchor=tk.W)
        qy = ttk.Scrollbar(queue_grid, orient=tk.VERTICAL, command=self.media_tree.yview)
        qx = ttk.Scrollbar(queue_grid, orient=tk.HORIZONTAL, command=self.media_tree.xview)
        self.media_tree.configure(yscrollcommand=qy.set, xscrollcommand=qx.set)
        self.media_tree.grid(row=0, column=0, sticky="nsew")
        qy.grid(row=0, column=1, sticky="ns")
        qx.grid(row=1, column=0, sticky="ew")
        queue_grid.rowconfigure(0, weight=1)
        queue_grid.columnconfigure(0, weight=1)
        self.media_tree.tag_configure("done", background="#2a5a3a")
        self.media_tree.tag_configure("error", background="#5a2a2a")
        self.media_tree.tag_configure("running", background="#2a4a6a")
        self.media_tree.tag_configure("pending", background=c["bg_input"])

        out_row = ttk.Frame(media)
        out_row.pack(fill=tk.X, pady=(0, 8))
        ttk.Label(out_row, text="Output folder:").pack(side=tk.LEFT)
        self.media_out_var = tk.StringVar(
            value=self._user_cfg.get("last_media_out", str(Path.home() / "TextAnimator_media"))
        )
        ttk.Entry(out_row, textvariable=self.media_out_var).pack(side=tk.LEFT, fill=tk.X, expand=True, padx=6)
        ttk.Button(out_row, text="Browse…", command=self._media_browse_output).pack(side=tk.LEFT)
        self.media_open_folder_var = tk.BooleanVar(value=True)

        # Export and transform settings
        settings_row = ttk.Frame(media)
        settings_row.pack(fill=tk.X, pady=(0, 8))
        lf_export = ttk.LabelFrame(settings_row, text="  Export / Resize  ", padding=8)
        lf_export.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 6))
        row = ttk.Frame(lf_export)
        row.pack(fill=tk.X, pady=(0, 5))
        ttk.Label(row, text="Output format:").pack(side=tk.LEFT)
        self.media_format_var = tk.StringVar(value="Keep source")
        ttk.Combobox(row, textvariable=self.media_format_var, values=OUTPUT_FORMATS,
                     state="readonly", width=13).pack(side=tk.LEFT, padx=(5, 12))
        ttk.Label(row, text="Resize:").pack(side=tk.LEFT)
        self.media_size_var = tk.StringVar(value="Original")
        size_options = ["Original", "640 x 360", "854 x 480", "1280 x 720", "1920 x 1080",
                        "2560 x 1440", "3840 x 2160", "1080 x 1080", "1080 x 1920", "1080 x 1350", "Custom"]
        size_cb = ttk.Combobox(row, textvariable=self.media_size_var, values=size_options,
                               state="readonly", width=15)
        size_cb.pack(side=tk.LEFT, padx=5)
        size_cb.bind("<<ComboboxSelected>>", self._media_size_changed)
        ttk.Label(row, text="Mode:").pack(side=tk.LEFT, padx=(7, 0))
        self.media_resize_mode_var = tk.StringVar(value="Fit")
        ttk.Combobox(row, textvariable=self.media_resize_mode_var,
                     values=["Fit", "Fill", "Stretch"], state="readonly", width=9).pack(side=tk.LEFT, padx=5)

        row2 = ttk.Frame(lf_export)
        row2.pack(fill=tk.X, pady=(0, 5))
        ttk.Label(row2, text="Width:").pack(side=tk.LEFT)
        self.media_width_var = tk.StringVar(value="")
        ttk.Entry(row2, textvariable=self.media_width_var, width=7).pack(side=tk.LEFT, padx=(4, 10))
        ttk.Label(row2, text="Height:").pack(side=tk.LEFT)
        self.media_height_var = tk.StringVar(value="")
        ttk.Entry(row2, textvariable=self.media_height_var, width=7).pack(side=tk.LEFT, padx=(4, 10))
        ttk.Label(row2, text="Rotate / flip:").pack(side=tk.LEFT)
        self.media_rotation_var = tk.StringVar(value="0°")
        ttk.Combobox(row2, textvariable=self.media_rotation_var,
                     values=["0°", "90°", "180°", "270°", "Flip horizontal", "Flip vertical"],
                     state="readonly", width=16).pack(side=tk.LEFT, padx=5)

        row3 = ttk.Frame(lf_export)
        row3.pack(fill=tk.X)
        ttk.Label(row3, text="FPS:").pack(side=tk.LEFT)
        self.media_fps_var = tk.IntVar(value=30)
        ttk.Spinbox(row3, from_=5, to=60, textvariable=self.media_fps_var, width=5).pack(side=tk.LEFT, padx=(4, 12))
        ttk.Label(row3, text="Speed:").pack(side=tk.LEFT)
        self.media_speed_var = tk.DoubleVar(value=1.0)
        ttk.Spinbox(row3, from_=0.5, to=2.0, increment=0.1, textvariable=self.media_speed_var, width=6).pack(side=tk.LEFT, padx=(4, 12))
        ttk.Label(row3, text="Quality / CRF:").pack(side=tk.LEFT)
        self.media_quality_var = tk.IntVar(value=20)
        ttk.Spinbox(row3, from_=0, to=40, textvariable=self.media_quality_var, width=5).pack(side=tk.LEFT, padx=4)

        lf_effects = ttk.LabelFrame(settings_row, text="  Filters / Effects  ", padding=8)
        lf_effects.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        ef1 = ttk.Frame(lf_effects)
        ef1.pack(fill=tk.X, pady=(0, 5))
        ttk.Label(ef1, text="Filter:").pack(side=tk.LEFT)
        self.media_filter_var = tk.StringVar(value="None")
        ttk.Combobox(ef1, textvariable=self.media_filter_var, values=FILTERS,
                     state="readonly", width=13).pack(side=tk.LEFT, padx=5)
        ttk.Label(ef1, text="Blur:").pack(side=tk.LEFT, padx=(8, 0))
        self.media_blur_var = tk.DoubleVar(value=0.0)
        ttk.Spinbox(ef1, from_=0.0, to=20.0, increment=0.5,
                    textvariable=self.media_blur_var, width=5).pack(side=tk.LEFT, padx=4)
        ttk.Label(ef1, text="Sharpen:").pack(side=tk.LEFT, padx=(7, 0))
        self.media_sharpen_var = tk.DoubleVar(value=0.0)
        ttk.Spinbox(ef1, from_=0.0, to=5.0, increment=0.1,
                    textvariable=self.media_sharpen_var, width=5).pack(side=tk.LEFT, padx=4)

        ef2 = ttk.Frame(lf_effects)
        ef2.pack(fill=tk.X, pady=(0, 5))
        self.media_brightness_var = tk.DoubleVar(value=0.0)
        self.media_contrast_var = tk.DoubleVar(value=0.0)
        self.media_saturation_var = tk.DoubleVar(value=0.0)
        for label, variable in (("Brightness", self.media_brightness_var),
                                ("Contrast", self.media_contrast_var),
                                ("Saturation", self.media_saturation_var)):
            ttk.Label(ef2, text=label + ":").pack(side=tk.LEFT)
            ttk.Spinbox(ef2, from_=-1.0, to=1.0, increment=0.05,
                        textvariable=variable, width=6).pack(side=tk.LEFT, padx=(3, 9))

        ef3 = ttk.Frame(lf_effects)
        ef3.pack(fill=tk.X)
        ttk.Label(ef3, text="Audio volume:").pack(side=tk.LEFT)
        self.media_volume_var = tk.DoubleVar(value=1.0)
        ttk.Spinbox(ef3, from_=0.0, to=4.0, increment=0.1,
                    textvariable=self.media_volume_var, width=6).pack(side=tk.LEFT, padx=4)
        self.media_normalize_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(ef3, text="Normalize audio", variable=self.media_normalize_var).pack(side=tk.LEFT, padx=(8, 0))
        self.media_metadata_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(ef3, text="Preserve image metadata", variable=self.media_metadata_var).pack(side=tk.LEFT, padx=(8, 0))

        lf_audio_replace = ttk.LabelFrame(media, text="  Replace Video Audio  ", padding=8)
        lf_audio_replace.pack(fill=tk.X, pady=(0, 8))
        audio_replace_row = ttk.Frame(lf_audio_replace)
        audio_replace_row.pack(fill=tk.X)
        ttk.Label(audio_replace_row, text="Mode:").pack(side=tk.LEFT)
        media_audio_labels = {
            "keep": "Keep original",
            "random": "Random from folder",
            "fixed": "Use fixed track",
        }
        self._media_audio_label_to_key = {v: k for k, v in media_audio_labels.items()}
        self.media_audio_mode_var = tk.StringVar(
            value=media_audio_labels.get(self._user_cfg.get("media_audio_mode", "keep"),
                                         media_audio_labels["keep"])
        )
        ttk.Combobox(
            audio_replace_row, textvariable=self.media_audio_mode_var,
            values=list(media_audio_labels.values()), state="readonly", width=20,
        ).pack(side=tk.LEFT, padx=(5, 12))
        ttk.Label(audio_replace_row, text="Audio folder (Random):").pack(side=tk.LEFT)
        self.media_audio_folder_var = tk.StringVar(
            value=self._user_cfg.get("media_audio_folder", "")
        )
        ttk.Entry(audio_replace_row, textvariable=self.media_audio_folder_var).pack(
            side=tk.LEFT, fill=tk.X, expand=True, padx=5
        )
        ttk.Button(audio_replace_row, text="Browse folder…", command=self._media_browse_audio_folder).pack(side=tk.LEFT, padx=(0, 8))
        ttk.Label(audio_replace_row, text="Fixed track:").pack(side=tk.LEFT)
        self.media_replacement_audio_var = tk.StringVar(
            value=self._user_cfg.get("media_replacement_audio", "")
        )
        ttk.Entry(audio_replace_row, textvariable=self.media_replacement_audio_var, width=28).pack(side=tk.LEFT, padx=5)
        ttk.Button(audio_replace_row, text="Browse file…", command=self._media_browse_replacement_audio).pack(side=tk.LEFT)
        ttk.Label(
            lf_audio_replace,
            text="Applies to queued video files only. Random mode replaces the original audio and cycles through tracks without repeats; Fixed mode uses the selected track. Other media types are untouched.",
            foreground=c["fg_dim"], font=("Segoe UI", 8), wraplength=1100,
        ).pack(anchor=tk.W, pady=(5, 0))

        action = ttk.Frame(media)
        action.pack(fill=tk.X, pady=(0, 4))
        self.media_run_btn = ttk.Button(action, text="Process Queue", style="Accent.TButton",
                                        command=self._media_run)
        self.media_run_btn.pack(side=tk.LEFT, padx=(0, 8))
        ttk.Button(action, text="Open Output Folder", command=lambda: self._open_file(self.media_out_var.get())).pack(side=tk.LEFT)
        auto_open = ttk.Checkbutton(action, text="Auto-open", variable=self.media_open_folder_var)
        auto_open.pack(side=tk.LEFT, padx=(10, 0))
        ToolTip(auto_open, "Open the output folder when processing finishes")
        self.media_status_var = tk.StringVar(value="Add files or a folder to begin.")
        status_line = ttk.Frame(media)
        status_line.pack(fill=tk.X, pady=(2, 0))
        ttk.Label(status_line, textvariable=self.media_status_var, foreground=c["fg_secondary"],
                  anchor=tk.W).pack(fill=tk.X)

    def _media_add_files(self):
        if self.is_busy:
            return
        filetypes = [
            ("Supported media", "*.png *.jpg *.jpeg *.webp *.bmp *.tif *.tiff *.gif *.ico *.mp4 *.m4v *.mov *.mkv *.avi *.wmv *.flv *.webm *.mpeg *.mpg *.m2ts *.mts *.ts *.3gp *.ogv *.mp3 *.wav *.aac *.m4a *.flac *.ogg *.opus *.wma *.aiff *.aif *.alac"),
            ("All files", "*.*"),
        ]
        paths = filedialog.askopenfilenames(title="Add media files", filetypes=filetypes)
        if paths:
            self._media_append_files(list(paths))

    def _media_add_folder(self):
        if self.is_busy:
            return
        folder = filedialog.askdirectory(title="Add media folder")
        if not folder:
            return
        paths = []
        for path in Path(folder).rglob("*"):
            if path.is_file() and path.suffix.lower() in SUPPORTED_INPUT_EXTS:
                paths.append(str(path))
        paths.sort(key=str.casefold)
        self._media_append_files(paths)

    def _media_append_files(self, paths):
        existing = {os.path.normcase(os.path.abspath(p)) for p in self._media_files}
        added = 0
        for raw in paths:
            path = os.path.abspath(os.path.expanduser(str(raw)))
            if not os.path.isfile(path) or Path(path).suffix.lower() not in SUPPORTED_INPUT_EXTS:
                continue
            key = os.path.normcase(path)
            if key in existing:
                continue
            existing.add(key)
            self._media_files.append(path)
            index = len(self._media_files)
            kind = self.media_processor.media_kind(path).title()
            self.media_tree.insert("", tk.END, iid=str(index),
                                   values=(index, path, kind, Path(path).suffix.lstrip(".").upper(), "Pending"),
                                   tags=("pending",))
            added += 1
        self.media_queue_count.config(text=f"{len(self._media_files)} files")
        self.media_status_var.set(f"Added {added} file(s). {len(self._media_files)} queued.")

    def _media_remove_selected(self):
        if self.is_busy:
            return
        selected = self.media_tree.selection()
        if not selected:
            return
        remove = {int(iid) - 1 for iid in selected if iid.isdigit()}
        self._media_files = [p for i, p in enumerate(self._media_files) if i not in remove]
        self._media_rebuild_tree()

    def _media_clear_queue(self):
        if self.is_busy:
            return
        self._media_files.clear()
        self._media_rebuild_tree()
        self.media_status_var.set("Queue cleared.")

    def _media_rebuild_tree(self):
        for iid in self.media_tree.get_children():
            self.media_tree.delete(iid)
        for index, path in enumerate(self._media_files, 1):
            self.media_tree.insert("", tk.END, iid=str(index),
                                   values=(index, path, self.media_processor.media_kind(path).title(),
                                           Path(path).suffix.lstrip(".").upper(), "Pending"),
                                   tags=("pending",))
        self.media_queue_count.config(text=f"{len(self._media_files)} files")

    def _media_browse_output(self):
        folder = filedialog.askdirectory(title="Choose processed media output folder",
                                         initialdir=self.media_out_var.get() or str(Path.home()))
        if folder:
            self.media_out_var.set(folder)

    def _media_size_changed(self, _event=None):
        value = self.media_size_var.get()
        if value == "Original":
            self.media_width_var.set("")
            self.media_height_var.set("")
        elif value == "Custom":
            return
        else:
            try:
                w, h = value.split("x")
                self.media_width_var.set(w.strip())
                self.media_height_var.set(h.strip())
            except ValueError:
                pass

    def _media_run(self):
        if self.is_busy:
            return
        if not self._media_files:
            messagebox.showwarning("Empty queue", "Add one or more image, video or audio files first.")
            return
        output_dir = self.media_out_var.get().strip()
        if not output_dir:
            messagebox.showwarning("Output folder", "Choose an output folder first.")
            return
        try:
            width = int(self.media_width_var.get()) if self.media_width_var.get().strip() else None
            height = int(self.media_height_var.get()) if self.media_height_var.get().strip() else None
            if (width is None) != (height is None):
                raise ValueError("Enter both width and height, or leave both empty.")
            if width is not None and (width < 1 or height < 1 or width > 16384 or height > 16384):
                raise ValueError("Width and height must be between 1 and 16384 pixels.")
            params = {
                "output_format": self.media_format_var.get(),
                "audio_replace_mode": self._media_audio_label_to_key.get(self.media_audio_mode_var.get(), "keep"),
                "audio_folder": self.media_audio_folder_var.get().strip() or None,
                "replacement_audio_path": self.media_replacement_audio_var.get().strip() or None,
                "hardware_backend": self._hardware_label_to_key.get(self.hardware_backend_var.get(), "auto"),
                "width": width, "height": height,
                "resize_mode": self.media_resize_mode_var.get(),
                "filter_name": self.media_filter_var.get(),
                "brightness": self.media_brightness_var.get(),
                "contrast": self.media_contrast_var.get(),
                "saturation": self.media_saturation_var.get(),
                "blur": self.media_blur_var.get(),
                "sharpen": self.media_sharpen_var.get(),
                "rotation": self.media_rotation_var.get(),
                "fps": self.media_fps_var.get(),
                "speed": self.media_speed_var.get(),
                "volume": self.media_volume_var.get(),
                "normalize_audio": self.media_normalize_var.get(),
                "quality": self.media_quality_var.get(),
                "preserve_metadata": self.media_metadata_var.get(),
            }
        except (ValueError, tk.TclError) as exc:
            messagebox.showerror("Invalid settings", str(exc))
            return

        files = list(self._media_files)
        open_folder_when_done = self.media_open_folder_var.get()
        self._set_busy(True)
        self.media_status_var.set("Processing queue…")
        save_user_config({
            "last_media_out": output_dir,
            "media_audio_mode": self._media_audio_label_to_key.get(self.media_audio_mode_var.get(), "keep"),
            "media_audio_folder": self.media_audio_folder_var.get().strip(),
            "media_replacement_audio": self.media_replacement_audio_var.get().strip(),
            "hardware_backend": self._hardware_label_to_key.get(self.hardware_backend_var.get(), "auto"),
        })
        for iid in self.media_tree.get_children():
            vals = list(self.media_tree.item(iid, "values"))
            vals[4] = "Pending"
            self.media_tree.item(iid, values=vals, tags=("pending",))

        def progress(current, total, message):
            self._progress_cb(current, total, message)

        def item_status(index, status, message):
            def update():
                iid = str(index)
                if self.media_tree.exists(iid):
                    vals = list(self.media_tree.item(iid, "values"))
                    vals[4] = {"running": "Processing…", "done": "✓ Done", "error": "✗ " + message,
                               "cancelled": "Cancelled"}.get(status, status)
                    self.media_tree.item(iid, values=vals, tags=(status if status in ("done", "error", "running") else "pending",))
                if status == "error":
                    self.media_status_var.set(f"{Path(files[index - 1]).name}: {message[:90]}")
            self.after(0, update)

        def worker():
            try:
                results = self.media_processor.process_many(
                    files, output_dir, progress_callback=progress,
                    item_callback=item_status, **params,
                )
                failed = len(files) - len(results)
                replaced = len(self.media_processor.last_audio_selections)
                encoder_label = self.media_processor.last_video_encoder_label
                msg = f"Completed {len(results)} of {len(files)} file(s) · {failed} failed · audio replaced in {replaced} video(s) · {encoder_label}. Saved to {output_dir}"
                self.after(0, lambda: self.media_status_var.set(msg))
                self.after(0, lambda: self._set_status(msg))
                if results:
                    self.after(0, lambda: self.progress.configure(value=100))
                if open_folder_when_done and results:
                    self.after(0, lambda: self._open_file(output_dir))
            except MediaCancelled:
                self.after(0, lambda: self.media_status_var.set("Processing cancelled."))
                self.after(0, lambda: self._set_status("Media processing cancelled"))
            except Exception as exc:
                error_message = str(exc)
                self.after(0, lambda error=error_message: self.media_status_var.set(f"Error: {error}"))
                self.after(0, lambda error=error_message: messagebox.showerror("Media processing error", error))
            finally:
                self.after(0, lambda: self._set_busy(False))

        threading.Thread(target=worker, daemon=True).start()

    # ----- Settings tab -----
    def _build_settings_tab(self, notebook):
        c = self._colors
        settings = ttk.Frame(notebook, padding=10)
        notebook.add(settings, text="  Settings  ")

        settings_header = tk.Frame(settings, bg=c["bg_secondary"], padx=12, pady=8)
        settings_header.pack(fill=tk.X, pady=(0, 10))
        tk.Label(settings_header, text="Advanced Settings", font=("Segoe UI", 12, "bold"),
                 bg=c["bg_secondary"], fg="white").pack(anchor=tk.W)
        tk.Label(settings_header, text="These advanced values apply to Single. Batch has its own independent Render Settings panel.",
                 font=("Segoe UI", 9), bg=c["bg_secondary"], fg=c["fg_secondary"]).pack(anchor=tk.W)

        # Outline & shadow
        lf_os = ttk.LabelFrame(settings, text="  Outline & Shadow  ", padding=10)
        lf_os.pack(fill=tk.X, pady=(0, 10))
        effects_row = ttk.Frame(lf_os)
        effects_row.pack(fill=tk.X)
        ttk.Label(effects_row, text="Outline width:").pack(side=tk.LEFT)
        self.outline_width = tk.IntVar(value=DEFAULTS["outline_width"])
        ttk.Spinbox(effects_row, from_=1, to=16, textvariable=self.outline_width, width=5).pack(side=tk.LEFT, padx=6)
        ttk.Label(effects_row, text="px").pack(side=tk.LEFT)
        ttk.Label(effects_row, text="Shadow offset:").pack(side=tk.LEFT, padx=(20, 0))
        self.shadow_offset = tk.IntVar(value=DEFAULTS["shadow_offset"])
        ttk.Spinbox(effects_row, from_=1, to=24, textvariable=self.shadow_offset, width=5).pack(side=tk.LEFT, padx=6)
        ttk.Label(effects_row, text="px").pack(side=tk.LEFT)

        # Encoding
        lf_enc = ttk.LabelFrame(settings, text="  Video Encoding  ", padding=10)
        lf_enc.pack(fill=tk.X, pady=(0, 10))
        enc_row = ttk.Frame(lf_enc)
        enc_row.pack(fill=tk.X)
        ttk.Label(enc_row, text="Encode quality (MoviePy):").pack(side=tk.LEFT)
        self.encode_var = tk.StringVar(value=DEFAULTS["encode_preset"])
        ttk.Combobox(enc_row, textvariable=self.encode_var, values=list(ENCODE_PRESETS.keys()),
                     state="readonly", width=20).pack(side=tk.LEFT, padx=8)
        ttk.Label(enc_row, text="CPU quality preset", foreground=c["fg_dim"]).pack(side=tk.LEFT)

        gpu_row = ttk.Frame(lf_enc)
        gpu_row.pack(fill=tk.X, pady=(8, 0))
        ttk.Label(gpu_row, text="Hardware encoder:").pack(side=tk.LEFT)
        hardware_labels = {
            "auto": "Auto (recommended)",
            "nvidia": "NVIDIA NVENC",
            "intel": "Intel Quick Sync",
            "cpu": "CPU only",
        }
        self._hardware_label_to_key = {v: k for k, v in hardware_labels.items()}
        self.hardware_backend_var = tk.StringVar(
            value=hardware_labels.get(self._user_cfg.get("hardware_backend", "auto"),
                                      hardware_labels["auto"])
        )
        ttk.Combobox(
            gpu_row, textvariable=self.hardware_backend_var,
            values=list(hardware_labels.values()), state="readonly", width=22,
        ).pack(side=tk.LEFT, padx=8)
        ttk.Label(
            gpu_row,
            text="Auto: NVIDIA NVENC → Intel Quick Sync → CPU. Frame composition remains CPU-based.",
            foreground=c["fg_dim"],
        ).pack(side=tk.LEFT)
        self.hardware_status_var = tk.StringVar(value="Checking FFmpeg encoders…")
        ttk.Label(lf_enc, textvariable=self.hardware_status_var,
                  foreground=c["fg_secondary"], wraplength=1100).pack(anchor=tk.W, pady=(6, 0))
        ttk.Button(lf_enc, text="Detect FFmpeg encoders", command=self._detect_hardware_encoders).pack(anchor=tk.W, pady=(5, 0))

        # Transition & audio defaults
        lf_tr = ttk.LabelFrame(settings, text="  Transition & Audio defaults  ", padding=10)
        lf_tr.pack(fill=tk.X, pady=(0, 10))
        tr_row = ttk.Frame(lf_tr)
        tr_row.pack(fill=tk.X)
        ttk.Label(tr_row, text="Transition duration:").pack(side=tk.LEFT)
        self.trans_dur_var = tk.DoubleVar(value=DEFAULTS["transition_duration"])
        ttk.Spinbox(tr_row, from_=0.05, to=1.5, increment=0.05, textvariable=self.trans_dur_var, width=5).pack(side=tk.LEFT, padx=6)
        ttk.Label(tr_row, text="s").pack(side=tk.LEFT)
        ttk.Label(tr_row, text="Audio volume:").pack(side=tk.LEFT, padx=(16, 0))
        self.audio_vol_var = tk.DoubleVar(value=DEFAULTS["audio_volume"])
        ttk.Spinbox(tr_row, from_=0.0, to=1.0, increment=0.05, textvariable=self.audio_vol_var, width=5).pack(side=tk.LEFT, padx=6)
        ttk.Label(tr_row, text="Fade in:").pack(side=tk.LEFT, padx=(12, 0))
        self.audio_fi_var = tk.DoubleVar(value=DEFAULTS["audio_fade_in"])
        ttk.Spinbox(tr_row, from_=0.0, to=3.0, increment=0.05, textvariable=self.audio_fi_var, width=5).pack(side=tk.LEFT, padx=4)
        ttk.Label(tr_row, text="Fade out:").pack(side=tk.LEFT, padx=(8, 0))
        self.audio_fo_var = tk.DoubleVar(value=DEFAULTS["audio_fade_out"])
        ttk.Spinbox(tr_row, from_=0.0, to=3.0, increment=0.05, textvariable=self.audio_fo_var, width=5).pack(side=tk.LEFT, padx=4)

        # Preview info
        lf_prev = ttk.LabelFrame(settings, text="  Preview  ", padding=10)
        lf_prev.pack(fill=tk.X, pady=(0, 10))
        ttk.Label(lf_prev, text="Preview always renders at 640×360 @ 20 FPS with slightly faster timings for quick feedback.",
                  foreground=c["fg_secondary"]).pack(anchor=tk.W)

        # Actions
        btn_row = ttk.Frame(settings)
        btn_row.pack(fill=tk.X, pady=(8, 0))
        ttk.Button(btn_row, text="Reset all settings to defaults", command=self._reset_settings).pack(side=tk.LEFT)
        ttk.Label(btn_row, text=f"  Config file: {Path.home() / '.textanimator_config.json'}",
                  foreground=c["fg_dim"]).pack(side=tk.LEFT, padx=12)

        # System info
        lf_info = ttk.LabelFrame(settings, text="  About this build  ", padding=10)
        lf_info.pack(fill=tk.X, pady=(12, 0))
        ttk.Label(lf_info, text=f"TextAnimator {__version__}  ·  MoviePy-powered kinetic typography",
                  font=("Segoe UI", 9)).pack(anchor=tk.W)
        ttk.Label(lf_info, text="10 animation presets · Multi-variant CSV batch · Image / video / audio processing",
                  foreground=c["fg_dim"]).pack(anchor=tk.W)
        self.after(700, self._detect_hardware_encoders)

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------
    def _update_counts(self, _event=None):
        text = self.text_box.get("1.0", tk.END).strip()
        words = len(text.split()) if text else 0
        chars = len(text)
        self.header_counts.config(text=f"{words} words  ·  {chars} chars")

    def _set_status(self, msg: str):
        self.status_var.set(msg)

    def _set_busy(self, busy: bool):
        self.is_busy = busy
        state = tk.DISABLED if busy else tk.NORMAL
        self.btn_preview.configure(state=state)
        self.btn_generate.configure(state=state)
        self.btn_batch.configure(state=state)
        self.btn_cancel.configure(state=tk.NORMAL if busy else tk.DISABLED)
        if hasattr(self, "media_run_btn"):
            self.media_run_btn.configure(state=state)
        if not busy:
            self.progress["value"] = 0

    def _progress_cb(self, current: int, total: int, msg: str):
        def update():
            if total > 0:
                self.progress["value"] = min(100, int(100 * current / total))
            self._set_status(msg)
        self.after(0, update)

    def _row_status_cb(self, index: int, status: str, message: str):
        def update():
            self._batch_statuses[index] = status
            # find tree item by index (iid is str of index)
            iid = str(index)
            if self.tree.exists(iid):
                vals = list(self.tree.item(iid, "values"))
                if len(vals) >= 6:
                    display = {
                        "pending": "Pending",
                        "running": "Rendering…",
                        "done": "✓ Done",
                        "skipped": "Skipped",
                        "error": f"✗ {message[:40]}",
                        "cancelled": "Cancelled",
                    }.get(status, status)
                    vals[5] = display
                    self.tree.item(iid, values=vals, tags=(status,))
        self.after(0, update)

    def _gather_params(self) -> dict:
        res_label = self.res_var.get()
        size = RESOLUTIONS.get(res_label, (1280, 720))
        trans_label = self.trans_var.get()
        transition = TRANSITIONS.get(trans_label, "fade")
        encode = ENCODE_PRESETS.get(self.encode_var.get(), "medium")

        bg = self.bg_entry.get().strip() or None
        if bg and not os.path.isfile(bg):
            bg = None
        audio = self.audio_entry.get().strip() or None
        if audio and not os.path.isfile(audio):
            audio = None

        return {
            "preset_name": self.preset_var.get(),
            "size": size,
            "font_name_or_path": self.font_var.get(),
            "font_size": self.font_size_var.get(),
            "color_mode": self.color_var.get(),
            "word_duration": self.word_dur_var.get(),
            "gap": self.gap_var.get(),
            "end_hold": self.end_hold_var.get(),
            "fps": self.fps_var.get(),
            "outline": self.outline_var.get(),
            "shadow": self.shadow_var.get(),
            "outline_width": self.outline_width.get(),
            "shadow_offset": self.shadow_offset.get(),
            "bg_image_path": bg,
            "auto_fit_font": self.autofit_var.get(),
            "encode_preset": encode,
            "hardware_backend": self._hardware_label_to_key.get(self.hardware_backend_var.get(), "auto"),
            "transition": transition,
            "transition_duration": self.trans_dur_var.get(),
            "audio_path": audio,
            "audio_volume": self.audio_vol_var.get(),
            "audio_fade_in": self.audio_fi_var.get(),
            "audio_fade_out": self.audio_fo_var.get(),
        }

    def _gather_batch_params(self) -> dict:
        """Return Batch-only rendering parameters; never reads Single controls."""
        settings = self._batch_render_settings_payload()
        return {
            "preset_name": settings["preset"],
            "size": RESOLUTIONS.get(settings["resolution"], (1280, 720)),
            "font_name_or_path": settings["font"],
            "font_size": settings["font_size"],
            "color_mode": settings["color_mode"],
            "word_duration": settings["word_duration"],
            "gap": settings["gap"],
            "end_hold": settings["end_hold"],
            "fps": settings["fps"],
            "outline": settings["outline"],
            "shadow": settings["shadow"],
            "outline_width": settings["outline_width"],
            "shadow_offset": settings["shadow_offset"],
            "bg_image_path": settings["bg_image_path"],
            "auto_fit_font": settings["auto_fit_font"],
            "encode_preset": settings["encode_preset"],
            "hardware_backend": settings["hardware_backend"],
            "transition": settings["transition"],
            "transition_duration": settings["transition_duration"],
            "audio_path": None,
            "audio_volume": settings["audio_volume"],
            "audio_fade_in": settings["audio_fade_in"],
            "audio_fade_out": settings["audio_fade_out"],
        }

    # ------------------------------------------------------------------
    # File dialogs
    # ------------------------------------------------------------------
    def _browse_csv(self):
        path = filedialog.askopenfilename(
            title="Open batch CSV",
            filetypes=[("CSV files", "*.csv"), ("All files", "*.*")],
        )
        if path:
            self.csv_entry.delete(0, tk.END)
            self.csv_entry.insert(0, path)
            self._load_csv_preview()

    def _browse_batch_out(self):
        path = filedialog.askdirectory(title="Batch output folder")
        if path:
            self.batch_out_entry.delete(0, tk.END)
            self.batch_out_entry.insert(0, path)

    def _browse_batch_audio_folder(self):
        path = filedialog.askdirectory(
            title="Choose the folder containing batch soundtrack files",
            initialdir=self.batch_audio_folder_var.get().strip() or str(Path.home()),
        )
        if path:
            self.batch_audio_folder_var.set(path)

    def _browse_batch_fixed_audio(self):
        path = filedialog.askopenfilename(
            title="Choose the fixed batch soundtrack",
            filetypes=[("Audio files", "*.mp3 *.wav *.m4a *.aac *.flac *.ogg *.opus *.aiff *.wma"),
                       ("All files", "*.*")],
            initialdir=str(Path(self.batch_fixed_audio_var.get()).expanduser().parent)
            if self.batch_fixed_audio_var.get().strip() else str(Path.home()),
        )
        if path:
            self.batch_fixed_audio_var.set(path)

    def _media_browse_audio_folder(self):
        path = filedialog.askdirectory(
            title="Choose the folder containing replacement audio tracks",
            initialdir=self.media_audio_folder_var.get().strip() or str(Path.home()),
        )
        if path:
            self.media_audio_folder_var.set(path)

    def _media_browse_replacement_audio(self):
        path = filedialog.askopenfilename(
            title="Choose the fixed replacement soundtrack",
            filetypes=[("Audio", "*.mp3 *.wav *.m4a *.aac *.flac *.ogg *.opus *.aiff *.wma"),
                       ("All files", "*.*")],
            initialdir=str(Path(self.media_replacement_audio_var.get()).expanduser().parent)
            if self.media_replacement_audio_var.get().strip() else str(Path.home()),
        )
        if path:
            self.media_replacement_audio_var.set(path)

    def _detect_hardware_encoders(self):
        self.hardware_status_var.set("Detecting encoders in the selected FFmpeg build…")

        def worker():
            try:
                info = hardware_summary()
                found = []
                if info.get("nvenc"):
                    found.append("NVIDIA NVENC")
                if info.get("qsv"):
                    found.append("Intel Quick Sync")
                if info.get("x264"):
                    found.append("CPU / x264")
                message = (
                    f"FFmpeg: {info['ffmpeg']} · Compiled encoders: {', '.join(found) or 'none detected'}. "
                    "Driver/GPU operation is confirmed only when a real render successfully uses that encoder."
                )
            except Exception as exc:
                message = f"Encoder detection failed: {exc}"
            def update_status(value=message):
                self.hardware_status_var.set(value)
                if hasattr(self, "batch_hardware_status_var"):
                    self.batch_hardware_status_var.set(value)
            self.after(0, update_status)

        threading.Thread(target=worker, daemon=True).start()

    def _browse_out(self):
        path = filedialog.asksaveasfilename(
            title="Save video as",
            defaultextension=".mp4",
            filetypes=[("MP4 video", "*.mp4")],
            initialfile=Path(self.out_entry.get()).name or "animated_text.mp4",
        )
        if path:
            self.out_entry.delete(0, tk.END)
            self.out_entry.insert(0, path)

    def _browse_bg(self):
        path = filedialog.askopenfilename(
            title="Background image",
            filetypes=[("Images", "*.jpg *.jpeg *.png *.webp *.bmp *.tif *.tiff *.gif *.ppm"), ("All files", "*.*")],
        )
        if path:
            self.bg_entry.delete(0, tk.END)
            self.bg_entry.insert(0, path)

    def _browse_audio(self):
        path = filedialog.askopenfilename(
            title="Soundtrack",
            filetypes=[("Audio", "*.mp3 *.wav *.m4a *.aac *.flac *.ogg *.opus *.aiff *.wma *.alac"), ("All files", "*.*")],
        )
        if path:
            self.audio_entry.delete(0, tk.END)
            self.audio_entry.insert(0, path)

    def _save_sample_csv(self):
        path = filedialog.asksaveasfilename(
            title="Save sample CSV",
            defaultextension=".csv",
            filetypes=[("CSV", "*.csv")],
            initialfile="sample_batch.csv",
        )
        if path:
            with open(path, "w", encoding="utf-8", newline="") as f:
                f.write(SAMPLE_CSV_CONTENT)
            self._set_status(f"Sample CSV saved: {path}")
            messagebox.showinfo("Sample CSV", f"Saved example batch file with all optional columns:\n{path}")

    # ------------------------------------------------------------------
    # Batch load / validate
    # ------------------------------------------------------------------
    def _load_csv_preview(self):
        path = self.csv_entry.get().strip()
        if not path:
            messagebox.showwarning("No CSV", "Enter or browse to a CSV file first.")
            return
        if not os.path.isfile(path):
            messagebox.showerror("Not found", f"File does not exist:\n{path}")
            return
        try:
            rows = load_csv_rows(path)
        except Exception as e:
            messagebox.showerror("CSV error", str(e))
            return

        self._batch_rows = rows
        self._batch_statuses = {}
        for item in self.tree.get_children():
            self.tree.delete(item)

        def _pick(row, keys, default=""):
            for k in keys:
                if k in row and row[k]:
                    return row[k]
            return default
        for i, row in enumerate(rows, 1):
            title = _pick(row, TITLE_KEYS, default=f"row_{i}")
            text = _pick(row, TEXT_KEYS)
            preset = row.get("preset") or "(default)"
            color = row.get("color_mode") or "(default)"
            self.tree.insert("", tk.END, iid=str(i),
                             values=(i, title, text[:80] + ("…" if len(text) > 80 else ""),
                                     preset, color, "Pending"),
                             tags=("pending",))

        warnings = validate_rows(rows)
        n = len(rows)
        empty = sum(1 for r in rows if not _pick(r, TEXT_KEYS))
        msg = f"Loaded {n} row(s)"
        if empty:
            msg += f"  ·  {empty} empty text (will skip)"
        if warnings and len(warnings) > empty:
            msg += f"  ·  {len(warnings)} note(s)"
        self.batch_status.config(text=msg, foreground=self._colors["fg_secondary"])
        self._set_status(msg)

        # Persist path
        save_user_config({"last_csv": path})

        if warnings and any("empty" not in w.lower() for w in warnings):
            messagebox.showinfo("Validation notes", "\n".join(warnings[:12]))

    # ------------------------------------------------------------------
    # Actions: preview / generate / batch / cancel
    # ------------------------------------------------------------------
    def _preview(self):
        if self.is_busy:
            return
        text = self.text_box.get("1.0", tk.END).strip()
        if not text:
            messagebox.showwarning("Empty", "Enter some text to preview.")
            return
        params = self._gather_params()
        self._set_busy(True)
        self._set_status("Building preview…")
        self.progress["value"] = 5

        def worker():
            try:
                path = self.preview_engine.generate(
                    text,
                    preset_name=params["preset_name"],
                    font_name_or_path=params["font_name_or_path"],
                    font_size=params["font_size"],
                    color_mode=params["color_mode"],
                    word_duration=params["word_duration"],
                    gap=params["gap"],
                    end_hold=params["end_hold"],
                    outline=params["outline"],
                    shadow=params["shadow"],
                    outline_width=params["outline_width"],
                    shadow_offset=params["shadow_offset"],
                    auto_fit_font=params["auto_fit_font"],
                    transition=params["transition"],
                    transition_duration=params["transition_duration"],
                    audio_path=params["audio_path"],
                    audio_volume=params["audio_volume"],
                    audio_fade_in=params["audio_fade_in"],
                    audio_fade_out=params["audio_fade_out"],
                    bg_image_path=params["bg_image_path"],
                    hardware_backend=params["hardware_backend"],
                    progress_callback=self._progress_cb,
                )
                self.after(0, lambda: self.progress.configure(value=100))
                self.after(0, lambda: self._set_status("Preview ready — opening…"))
                self.after(0, lambda: self._open_file(path))
            except RenderCancelled:
                self.after(0, lambda: self._set_status("Preview cancelled"))
            except Exception as e:
                error_message = str(e)
                self.after(0, lambda error=error_message: self._set_status(f"Preview error: {error}"))
                self.after(0, lambda error=error_message: messagebox.showerror("Preview error", error))
            finally:
                self.after(0, lambda: self._set_busy(False))

        threading.Thread(target=worker, daemon=True).start()

    def _generate(self):
        if self.is_busy:
            return
        text = self.text_box.get("1.0", tk.END).strip()
        if not text:
            messagebox.showwarning("Empty", "Enter some text to generate.")
            return
        out = self.out_entry.get().strip()
        if not out:
            messagebox.showwarning("No path", "Choose an output path.")
            return
        params = self._gather_params()
        self._set_busy(True)
        self._set_status("Rendering…")
        self.progress["value"] = 3
        save_user_config({"last_output": out, "hardware_backend": params["hardware_backend"]})

        def worker():
            try:
                self.renderer.render_to_file(
                    text, out,
                    progress_callback=self._progress_cb,
                    **{k: v for k, v in params.items()},
                )
                self.after(0, lambda: self.progress.configure(value=100))
                encoder_label = self.renderer.last_encoder_label
                self.after(0, lambda: self._set_status(f"Saved: {out} · {encoder_label}"))
                self.after(0, lambda: messagebox.showinfo("Done", f"Video saved:\n{out}\n\nEncoder: {encoder_label}"))
                self.after(0, lambda: self._open_file(out))
            except RenderCancelled:
                self.after(0, lambda: self._set_status("Cancelled"))
            except Exception as e:
                import traceback
                error_message = str(e)
                details = traceback.format_exc()[:600]
                self.after(0, lambda error=error_message: self._set_status(f"Error: {error}"))
                self.after(0, lambda error=error_message, trace=details: messagebox.showerror("Render error", f"{error}\n\n{trace}"))
            finally:
                self.after(0, lambda: self._set_busy(False))

        threading.Thread(target=worker, daemon=True).start()

    def _run_batch(self):
        if self.is_busy:
            return
        csv_path = self.csv_entry.get().strip()
        out_dir = self.batch_out_entry.get().strip()
        if not csv_path or not os.path.isfile(csv_path):
            messagebox.showwarning("CSV required", "Load a valid CSV first (Batch tab).")
            self.notebook.select(1)
            return
        if not out_dir:
            messagebox.showwarning("Output folder", "Choose a batch output folder.")
            return

        # Auto-load if tree empty
        if not self._batch_rows:
            self._load_csv_preview()
            if not self._batch_rows:
                return

        params = self._gather_batch_params()
        skip_existing = self.skip_existing_var.get()
        variants_per_row = self.batch_variants_var.get()
        open_folder_when_done = self.open_folder_var.get()
        batch_audio_mode = self._batch_audio_label_to_key.get(self.batch_audio_mode_var.get(), "fixed")
        batch_audio_folder = self.batch_audio_folder_var.get().strip() or None
        batch_fixed_audio = self.batch_fixed_audio_var.get().strip() or None
        self._set_busy(True)
        self._set_status("Starting batch…")
        self.progress["value"] = 2
        save_user_config({
            "last_csv": csv_path, "last_batch_out": out_dir,
            "batch_audio_mode": batch_audio_mode,
            "batch_audio_folder": batch_audio_folder or "",
            "batch_fixed_audio": batch_fixed_audio or "",
            "batch_render_settings": self._batch_render_settings_payload(),
        })

        # Reset status column
        for iid in self.tree.get_children():
            vals = list(self.tree.item(iid, "values"))
            if len(vals) >= 6:
                vals[5] = "Pending"
                self.tree.item(iid, values=vals, tags=("pending",))

        def worker():
            try:
                results = self.batch_renderer.run(
                    csv_path,
                    out_dir,
                    default_preset=params["preset_name"],
                    default_size=params["size"],
                    default_font=params["font_name_or_path"],
                    default_font_size=params["font_size"],
                    default_color_mode=params["color_mode"],
                    default_word_duration=params["word_duration"],
                    default_gap=params["gap"],
                    default_end_hold=params["end_hold"],
                    default_fps=params["fps"],
                    outline=params["outline"],
                    shadow=params["shadow"],
                    outline_width=params["outline_width"],
                    shadow_offset=params["shadow_offset"],
                    bg_image_path=params["bg_image_path"],
                    auto_fit_font=params["auto_fit_font"],
                    encode_preset=params["encode_preset"],
                    hardware_backend=params["hardware_backend"],
                    audio_mode={"fixed": "fixed", "random": "random", "none": "none"}.get(batch_audio_mode, "fixed"),
                    audio_folder=batch_audio_folder,
                    fixed_audio_path=batch_fixed_audio,
                    transition=params["transition"],
                    transition_duration=params["transition_duration"],
                    audio_path=None,
                    audio_volume=params["audio_volume"],
                    audio_fade_in=params["audio_fade_in"],
                    audio_fade_out=params["audio_fade_out"],
                    skip_existing=skip_existing,
                    variants_per_row=variants_per_row,
                    progress_callback=self._progress_cb,
                    row_status_callback=self._row_status_cb,
                )
                done = sum(1 for r in self.batch_renderer.last_results if r["status"] == "done")
                skipped = sum(1 for r in self.batch_renderer.last_results if r["status"] == "skipped")
                errors = sum(1 for r in self.batch_renderer.last_results if r["status"] == "error")
                self.after(0, lambda: self.progress.configure(value=100))
                encoder_label = self.batch_renderer.renderer.last_encoder_label
                msg = f"Batch finished — {done} rendered, {skipped} skipped, {errors} errors · {encoder_label} → {out_dir}"
                self.after(0, lambda: self._set_status(msg))
                self.after(0, lambda: self.batch_status.config(text=msg))
                self.after(0, lambda: messagebox.showinfo("Batch complete", msg))
                if open_folder_when_done and results:
                    self.after(0, lambda: self._open_file(out_dir))
                # Phase 7: post-batch publish bridge
                _done = done
                self.after(500, lambda d=_done: _post_batch_publish_prompt(self, d))
            except RenderCancelled:
                self.after(0, lambda: self._set_status("Batch cancelled"))
            except Exception as e:
                import traceback
                error_message = str(e)
                details = traceback.format_exc()[:500]
                self.after(0, lambda error=error_message: self._set_status(f"Batch error: {error}"))
                self.after(0, lambda error=error_message, trace=details: self._show_error_dialog("Batch error", error, trace))
            finally:
                self.after(0, lambda: self._set_busy(False))

        threading.Thread(target=worker, daemon=True).start()

    def _cancel(self):
        if not self.is_busy:
            return
        self.renderer.cancel()
        self.preview_engine.cancel()
        self.batch_renderer.cancel()
        self.media_processor.cancel()
        self._set_status("Cancelling…")

    # ------------------------------------------------------------------
    # Misc
    # ------------------------------------------------------------------
    def _clear_text(self):
        self.text_box.delete("1.0", tk.END)
        self._update_counts()

    def _reset_settings(self):
        self.outline_width.set(DEFAULTS["outline_width"])
        self.shadow_offset.set(DEFAULTS["shadow_offset"])
        self.encode_var.set(DEFAULTS["encode_preset"])
        if hasattr(self, "hardware_backend_var"):
            self.hardware_backend_var.set("Auto (recommended)")
        self.trans_dur_var.set(DEFAULTS["transition_duration"])
        self.audio_vol_var.set(DEFAULTS["audio_volume"])
        self.audio_fi_var.set(DEFAULTS["audio_fade_in"])
        self.audio_fo_var.set(DEFAULTS["audio_fade_out"])
        self.skip_existing_var.set(DEFAULTS["skip_existing"])
        self.open_folder_var.set(DEFAULTS["open_folder_when_done"])
        self.outline_var.set(DEFAULTS["outline"])
        self.shadow_var.set(DEFAULTS["shadow"])
        self.autofit_var.set(DEFAULTS["auto_fit_font"])
        self.word_dur_var.set(DEFAULTS["word_duration"])
        self.gap_var.set(DEFAULTS["gap"])
        self.end_hold_var.set(DEFAULTS["end_hold"])
        self.font_size_var.set(DEFAULTS["font_size"])
        self.fps_var.set(DEFAULTS["fps"])
        self.res_var.set(DEFAULTS["resolution"])
        self.color_var.set(DEFAULTS["color_mode"])
        self.preset_var.set(DEFAULTS["preset"])
        if hasattr(self, "preset_display"):
            self.preset_display.set(PRESET_LABELS.get(DEFAULTS["preset"], "Classic Kinetic"))
        self.trans_var.set("Smooth fade")
        self._set_status("Settings reset to defaults")

    def _open_file(self, path: str):
        try:
            if os.name == "nt":
                os.startfile(path)
            elif sys.platform == "darwin":
                subprocess.Popen(["open", path])
            else:
                subprocess.Popen(["xdg-open", path])
        except Exception:
            self._set_status(f"Open manually: {path}")

    def _show_csv_help(self):
        msg = """CSV format for Batch mode

Required columns (any name from the group):
  • title | name | id | filename | slug
  • sentence | text | content | body | line | quote

Optional per-row overrides:
  preset          classic, typewriter, pop_hold, slide_cascade, glitch, fade_black, bounce, slide_up, rotate_in, zoom_pulse
  color_mode      white_on_black | black_on_white
  font_size       integer (e.g. 90)
  font            font family name
  word_duration   seconds (e.g. 0.85)
  gap             seconds between words
  end_hold        seconds hold at end
  fps             15–60
  outline         true/false
  outline_width   pixels (1–16)
  shadow          true/false
  shadow_offset   pixels (1–24)
  auto_fit_font   true/false
  resolution      1280x720 or a known label
  transition      fade | cut | zoom
  transition_duration seconds
  bg_image        full path to image
  encode_preset   ultrafast | fast | medium | slow
  hardware_backend auto | nvidia | intel | cpu
  audio           full path to audio file, or 'none'
  audio_volume    0.0–1.0
  audio_fade_in   seconds
  audio_fade_out  seconds
  filename        explicit output name (without .mp4)

Use File → Save Sample CSV… for a ready-to-edit template.
Set Variants / row in the Batch tab to create multiple MP4s per CSV row, cycling through animation presets.
Batch Render Settings are used as defaults for any missing columns. Batch defaults are independent from the Single tab.
"""
        messagebox.showinfo("CSV format", msg)

    def _show_shortcuts(self):
        messagebox.showinfo("Shortcuts",
                            "Ctrl+Enter   Generate video\n"
                            "Ctrl+B       Run batch\n"
                            "Ctrl+O       Open CSV\n"
                            "Esc          Cancel current job\n"
                            "Ctrl+Q       Quit")

    def _show_about(self):
        messagebox.showinfo(
            "About TextAnimator",
            f"TextAnimator {__version__}\n"
            "Kinetic black & white text video studio\n\n"
            "10 animation presets · Multi-variant batch generation · Media Studio\n"
            "Outline / shadow · Custom background & soundtrack\n"
            "Built with MoviePy + Pillow + Tkinter",
        )

    def _export_diagnostics(self):
        """Bundle logs + config snapshot into a zip for support."""
        import zipfile, json, io
        from .log_setup import log_dir
        dest = filedialog.asksaveasfilename(
            title="Export Diagnostics",
            defaultextension=".zip",
            filetypes=[("Zip archive", "*.zip")],
            initialfile="textanimator_diagnostics.zip",
        )
        if not dest:
            return
        try:
            with zipfile.ZipFile(dest, "w", zipfile.ZIP_DEFLATED) as zf:
                log_d = log_dir()
                if log_d.exists():
                    for lf in sorted(log_d.iterdir()):
                        zf.write(lf, f"logs/{lf.name}")
                # config snapshot (no secrets)
                cfg_snap = {k: v for k, v in self._user_cfg.items()
                            if "token" not in k.lower() and "secret" not in k.lower()}
                zf.writestr("config_snapshot.json", json.dumps(cfg_snap, indent=2))
                # platform info
                import sys, platform as _plat
                info = {
                    "python": sys.version,
                    "platform": _plat.platform(),
                    "app_version": __version__,
                }
                zf.writestr("system_info.json", json.dumps(info, indent=2))
            messagebox.showinfo("Diagnostics exported", f"Saved to:\n{dest}")
        except Exception as exc:
            messagebox.showerror("Export error", str(exc))

    def _on_close(self):
        if self.is_busy:
            if not messagebox.askyesno("Busy", "A render is in progress. Cancel and quit?"):
                return
            self._cancel()
        self.preview_engine.cleanup()
        self.media_processor.cancel()
        self.destroy()


# ==========================================================================
# Job registry + Publish tab — appended by v3.0.0 social build
# ==========================================================================

import dataclasses
import json
import webbrowser
from typing import Optional

# ---------------------------------------------------------------------------
# Job registry helpers
# ---------------------------------------------------------------------------

@dataclasses.dataclass
class _Job:
    """One cancellable task (render, preview, batch, media, upload)."""

    job_id: str
    kind: str              # "render" | "preview" | "batch" | "media" | "upload"
    label: str
    cancel_fn: callable
    done: bool = False
    error: str = ""


def _patch_job_registry(app: "TextAnimatorApp") -> None:
    """Monkey-patch job registry methods onto an existing TextAnimatorApp instance."""

    app._jobs: dict[str, _Job] = {}
    app._jobs_lock = threading.Lock()

    def _job_started(kind: str, label: str, cancel_fn) -> str:
        import uuid
        job_id = str(uuid.uuid4())[:8]
        with app._jobs_lock:
            app._jobs[job_id] = _Job(job_id=job_id, kind=kind, label=label, cancel_fn=cancel_fn)
        app.after(0, _refresh_job_strip)
        return job_id

    def _job_finished(job_id: str, error: str = "") -> None:
        with app._jobs_lock:
            job = app._jobs.get(job_id)
            if job:
                job.done = True
                job.error = error
        app.after(0, _refresh_job_strip)
        # Remove completed jobs after a short delay
        app.after(3000, lambda: _remove_job(job_id))

    def _remove_job(job_id: str) -> None:
        with app._jobs_lock:
            app._jobs.pop(job_id, None)
        _refresh_job_strip()

    def _refresh_job_strip() -> None:
        if not hasattr(app, "_job_strip_frame"):
            return
        frame = app._job_strip_frame
        for w in frame.winfo_children():
            w.destroy()
        with app._jobs_lock:
            jobs = list(app._jobs.values())
        active = [j for j in jobs if not j.done]
        if not active:
            lbl = tk.Label(frame, text="No active jobs", bg=app._colors["bg_secondary"],
                           fg=app._colors["fg_dim"], font=("Segoe UI", 9))
            lbl.pack(side=tk.LEFT, padx=8)
            return
        for job in active:
            chip = tk.Frame(frame, bg=app._colors["bg_tertiary"], padx=4, pady=2)
            chip.pack(side=tk.LEFT, padx=4)
            lbl_text = f"[{job.kind}] {job.label[:30]}"
            tk.Label(chip, text=lbl_text, bg=app._colors["bg_tertiary"],
                     fg=app._colors["fg_primary"], font=("Segoe UI", 8)).pack(side=tk.LEFT)
            btn = tk.Button(chip, text="✕", bg=app._colors["danger"], fg="white",
                            font=("Segoe UI", 8), relief=tk.FLAT, padx=2,
                            command=lambda jid=job.job_id: _cancel_job(jid))
            btn.pack(side=tk.LEFT, padx=(2, 0))

    def _cancel_job(job_id: str) -> None:
        with app._jobs_lock:
            job = app._jobs.get(job_id)
        if job and not job.done:
            try:
                job.cancel_fn()
            except Exception:
                pass

    app._job_started = _job_started
    app._job_finished = _job_finished
    app._refresh_job_strip = _refresh_job_strip


# ---------------------------------------------------------------------------
# Publish tab builder (standalone function, called from __init__ extension)
# ---------------------------------------------------------------------------

def _build_publish_tab(app: "TextAnimatorApp", notebook) -> None:
    """Add the Publish tab to an existing TextAnimatorApp notebook."""
    c = app._colors

    # --- Social extras guard ---
    _SOCIAL_AVAILABLE = True
    try:
        from .social.registry import list_platforms, load_adapter
        from .social.credentials import TokenStore
        from .social.base import UploadRequest
        from .social.queue import UploadQueue, JobStatus
        from .social.conformance import conformance_diff, auto_conform
        from .social.validator import validate as _validate_file
    except ImportError:
        _SOCIAL_AVAILABLE = False

    pub = ttk.Frame(notebook, padding=10)
    notebook.add(pub, text="  Publish  ")

    if not _SOCIAL_AVAILABLE:
        tk.Label(pub,
                 text=(
                     "Social publishing is not available.\n\n"
                     "Install the required extras with:\n\n"
                     "    pip install 'text-animator[social]'"
                 ),
                 bg=c["bg_primary"], fg=c["fg_secondary"],
                 font=("Segoe UI", 12), justify=tk.CENTER,
                 ).pack(expand=True)
        return

    # Keep state on the app object
    app._publish_queue_jobs: list[dict] = []          # list of row dicts for the UI
    app._upload_queue: Optional[UploadQueue] = None
    app._pub_store = TokenStore()

    # ---- TOP: Connected accounts strip ----
    acct_frame = ttk.LabelFrame(pub, text="Connected Accounts", padding=6)
    acct_frame.pack(fill=tk.X, pady=(0, 8))

    app._acct_chips_frame = tk.Frame(acct_frame, bg=c["bg_primary"])
    app._acct_chips_frame.pack(fill=tk.X, side=tk.LEFT, expand=True)

    ttk.Button(acct_frame, text="API Credentials…",
               command=lambda: _manage_api_credentials(app)).pack(side=tk.RIGHT, padx=4)
    ttk.Button(acct_frame, text="＋ Connect…",
               command=lambda: _connect_account(app)).pack(side=tk.RIGHT, padx=4)
    ttk.Button(acct_frame, text="Manage",
               command=lambda: _manage_accounts(app)).pack(side=tk.RIGHT, padx=4)

    _refresh_account_chips(app)

    # ---- SOURCE SELECTOR ----
    src_frame = ttk.LabelFrame(pub, text="Source Files", padding=6)
    src_frame.pack(fill=tk.X, pady=(0, 8))

    app._pub_source_var = tk.StringVar(value="batch")

    tk.Radiobutton(src_frame, text="Last Batch Results",
                   variable=app._pub_source_var, value="batch",
                   bg=c["bg_primary"], fg=c["fg_primary"],
                   selectcolor=c["bg_tertiary"],
                   command=lambda: _load_publish_source(app)).pack(side=tk.LEFT, padx=8)
    tk.Radiobutton(src_frame, text="Current Output",
                   variable=app._pub_source_var, value="single",
                   bg=c["bg_primary"], fg=c["fg_primary"],
                   selectcolor=c["bg_tertiary"],
                   command=lambda: _load_publish_source(app)).pack(side=tk.LEFT, padx=8)
    ttk.Button(src_frame, text="Add Files…",
               command=lambda: _add_publish_files(app)).pack(side=tk.LEFT, padx=8)
    ttk.Button(src_frame, text="Clear Queue",
               command=lambda: _clear_publish_queue(app)).pack(side=tk.RIGHT, padx=4)

    # ---- DESTINATION QUEUE TREEVIEW ----
    queue_frame = ttk.LabelFrame(pub, text="Upload Queue", padding=6)
    queue_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 8))

    cols = ("#", "File", "Platform", "Account", "Validity", "Status", "Post URL")
    app._pub_tree = ttk.Treeview(queue_frame, columns=cols, show="headings", height=10)
    col_widths = [40, 200, 100, 120, 80, 120, 200]
    for col, w in zip(cols, col_widths):
        app._pub_tree.heading(col, text=col)
        app._pub_tree.column(col, width=w, minwidth=40)

    app._pub_tree.tag_configure("done", background=c["row_done"])
    app._pub_tree.tag_configure("error", background=c["row_error"])
    app._pub_tree.tag_configure("running", background=c["row_run"])
    app._pub_tree.tag_configure("processing", background=c["row_run"])
    app._pub_tree.tag_configure("pending", background=c["bg_input"])
    app._pub_tree.tag_configure("needs_reauth", background="#5a4a2a")

    vsb = ttk.Scrollbar(queue_frame, orient=tk.VERTICAL, command=app._pub_tree.yview)
    app._pub_tree.configure(yscrollcommand=vsb.set)
    app._pub_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
    vsb.pack(side=tk.RIGHT, fill=tk.Y)

    app._pub_tree.bind("<Double-Button-1>", lambda e: _open_post_url(app))

    # ---- PER-ITEM EDITOR (right panel) ----
    editor_frame = ttk.LabelFrame(pub, text="Selected Item Details", padding=6)
    editor_frame.pack(fill=tk.X, pady=(0, 8))

    for label, attr in [("Title", "_pub_title"), ("Description", "_pub_desc"),
                         ("Tags (comma-sep)", "_pub_tags")]:
        row = tk.Frame(editor_frame, bg=c["bg_primary"])
        row.pack(fill=tk.X, pady=2)
        tk.Label(row, text=label, width=18, anchor=tk.W,
                 bg=c["bg_primary"], fg=c["fg_secondary"]).pack(side=tk.LEFT)
        var = tk.StringVar()
        setattr(app, attr, var)
        ttk.Entry(row, textvariable=var, width=50).pack(side=tk.LEFT, fill=tk.X, expand=True)

    vis_row = tk.Frame(editor_frame, bg=c["bg_primary"])
    vis_row.pack(fill=tk.X, pady=2)
    tk.Label(vis_row, text="Visibility", width=18, anchor=tk.W,
             bg=c["bg_primary"], fg=c["fg_secondary"]).pack(side=tk.LEFT)
    app._pub_vis_var = tk.StringVar(value="private")
    ttk.Combobox(vis_row, textvariable=app._pub_vis_var,
                 values=["private", "unlisted", "public"],
                 state="readonly", width=15).pack(side=tk.LEFT)
    tk.Label(
        editor_frame,
        text=("TikTok note: 'unlisted' maps to mutual followers, not a true unlisted post. "
              "Available privacy levels depend on your TikTok account and app approval."),
        bg=c["bg_primary"], fg=c["fg_dim"], font=("Segoe UI", 8),
        wraplength=760, justify=tk.LEFT,
    ).pack(anchor=tk.W, padx=4, pady=(0, 4))

    ttk.Button(vis_row, text="TikTok Options…",
               command=lambda: _tiktok_options_dialog(app)).pack(side=tk.LEFT, padx=(10, 4))

    app._pub_conform_var = tk.BooleanVar(value=False)
    ttk.Checkbutton(vis_row, text="Auto-conform to platform requirements",
                    variable=app._pub_conform_var).pack(side=tk.LEFT, padx=16)

    ttk.Button(editor_frame, text="Apply to Selected",
               command=lambda: _apply_pub_meta(app)).pack(side=tk.RIGHT, padx=4)

    # ---- ACTION BUTTONS ----
    btn_row = tk.Frame(pub, bg=c["bg_primary"])
    btn_row.pack(fill=tk.X)

    ttk.Button(btn_row, text="Validate All",
               command=lambda: _validate_all(app)).pack(side=tk.LEFT, padx=4)
    ttk.Button(btn_row, text="Upload Selected", style="Accent.TButton",
               command=lambda: _upload_selected(app)).pack(side=tk.LEFT, padx=4)
    ttk.Button(btn_row, text="Cancel Selected", style="Danger.TButton",
               command=lambda: _cancel_selected_uploads(app)).pack(side=tk.LEFT, padx=4)
    ttk.Button(btn_row, text="Retry Failed",
               command=lambda: _retry_failed(app)).pack(side=tk.LEFT, padx=4)
    ttk.Button(btn_row, text="Check TikTok Status",
               command=lambda: _refresh_tiktok_status(app)).pack(side=tk.LEFT, padx=4)

    # Empty-state label
    app._pub_empty_lbl = tk.Label(pub,
        text="Connect at least one account and load source files to publish.",
        bg=c["bg_primary"], fg=c["fg_dim"], font=("Segoe UI", 10))
    # Shown/hidden dynamically


# ---------------------------------------------------------------------------
# Publish tab helpers (all as module-level functions)
# ---------------------------------------------------------------------------

def _refresh_account_chips(app: "TextAnimatorApp") -> None:
    """Rebuild the account chips row from TokenStore."""
    try:
        from .social.credentials import TokenStore
        from .social.registry import get_capability
    except ImportError:
        return

    frame = app._acct_chips_frame
    for w in frame.winfo_children():
        w.destroy()

    store = TokenStore()
    accounts = store.list_accounts()
    if not accounts:
        tk.Label(frame, text="No accounts connected — click '＋ Connect…'",
                 bg=app._colors["bg_primary"], fg=app._colors["fg_dim"],
                 font=("Segoe UI", 9)).pack(side=tk.LEFT, padx=4)
        return

    for platform, account_id in accounts:
        bundle = store.load(platform, account_id)
        cap = get_capability(platform)
        name = cap.platform_name if cap else platform
        reauth = bundle.is_expired() if bundle else True

        chip_bg = app._colors["warning"] if reauth else app._colors["bg_tertiary"]
        chip = tk.Frame(frame, bg=chip_bg, padx=6, pady=3, relief=tk.RIDGE, bd=1)
        chip.pack(side=tk.LEFT, padx=4)
        label = f"⚠ {name}" if reauth else f"✓ {name}"
        tk.Label(chip, text=label, bg=chip_bg, fg="white",
                 font=("Segoe UI", 9, "bold")).pack(side=tk.LEFT)
        sub = account_id[:12] + "…" if len(account_id) > 12 else account_id
        tk.Label(chip, text=f" ({sub})", bg=chip_bg, fg="#ddd",
                 font=("Segoe UI", 8)).pack(side=tk.LEFT)


def _credentials_complete(platform_id: str, values: dict | None = None) -> bool:
    """Check whether the platform has the minimum developer-app config."""
    from .social.credentials import ClientCredentialStore, PLATFORM_CREDENTIAL_FIELDS

    config = values if values is not None else ClientCredentialStore().get(platform_id)
    fields = PLATFORM_CREDENTIAL_FIELDS.get(platform_id, [])
    if platform_id == "vimeo":
        return bool(config.get("access_token") or
                    (config.get("client_id") and config.get("client_secret")))
    required = [field["key"] for field in fields if field.get("required")]
    return bool(required) and all(config.get(key, "").strip() for key in required)


def _manage_api_credentials(
    app: "TextAnimatorApp",
    initial_platform: str | None = None,
    on_saved=None,
) -> None:
    """Show the in-app editor for social-platform developer credentials."""
    try:
        from .social.credentials import ClientCredentialStore, PLATFORM_CREDENTIAL_FIELDS
        from .social.registry import list_platforms
    except ImportError as exc:
        messagebox.showerror("Credentials unavailable", str(exc), parent=app)
        return

    platform_caps = list_platforms()
    if not platform_caps:
        messagebox.showinfo("No platforms", "No social platforms are registered.", parent=app)
        return

    names = {cap.platform_name: cap.platform_id for cap in platform_caps}
    labels = {cap.platform_id: cap.platform_name for cap in platform_caps}
    selected_id = initial_platform if initial_platform in labels else platform_caps[0].platform_id
    store = ClientCredentialStore()

    dlg = tk.Toplevel(app)
    dlg.title("Social API Credentials")
    dlg.geometry("650x500")
    dlg.minsize(570, 420)
    dlg.configure(bg=app._colors["bg_primary"])
    dlg.transient(app)
    dlg.grab_set()

    heading = tk.Label(
        dlg, text="Connect your developer apps",
        bg=app._colors["bg_primary"], fg=app._colors["fg_primary"],
        font=("Segoe UI", 14, "bold"),
    )
    heading.pack(anchor=tk.W, padx=18, pady=(16, 3))
    tk.Label(
        dlg,
        text=("Enter the API credentials from each platform's developer portal. "
              "TextAnimator uses these to start the account authorization flow."),
        bg=app._colors["bg_primary"], fg=app._colors["fg_secondary"],
        font=("Segoe UI", 9), wraplength=600, justify=tk.LEFT,
    ).pack(anchor=tk.W, padx=18, pady=(0, 12))

    selector = tk.Frame(dlg, bg=app._colors["bg_primary"])
    selector.pack(fill=tk.X, padx=18, pady=(0, 10))
    tk.Label(selector, text="Platform", width=16, anchor=tk.W,
             bg=app._colors["bg_primary"], fg=app._colors["fg_secondary"]).pack(side=tk.LEFT)
    selected_name = tk.StringVar(value=labels[selected_id])
    platform_box = ttk.Combobox(selector, textvariable=selected_name,
                                values=list(names), state="readonly", width=32)
    platform_box.pack(side=tk.LEFT, fill=tk.X, expand=True)

    form = ttk.LabelFrame(dlg, text="Application credentials", padding=12)
    form.pack(fill=tk.BOTH, expand=True, padx=18, pady=(0, 8))
    help_var = tk.StringVar(value="")
    help_lbl = tk.Label(dlg, textvariable=help_var, bg=app._colors["bg_primary"],
                        fg=app._colors["fg_dim"], font=("Segoe UI", 8),
                        wraplength=600, justify=tk.LEFT)
    help_lbl.pack(anchor=tk.W, padx=18, pady=(0, 8))

    entries: dict[str, tk.Entry] = {}
    field_vars: dict[str, tk.StringVar] = {}

    def render_fields(*_args):
        nonlocal selected_id
        selected_id = names.get(selected_name.get(), selected_id)
        for child in form.winfo_children():
            child.destroy()
        entries.clear()
        field_vars.clear()

        schema = PLATFORM_CREDENTIAL_FIELDS.get(selected_id, [])
        current = store.get(selected_id)
        for row_index, field in enumerate(schema):
            key = field["key"]
            row = tk.Frame(form, bg=app._colors["bg_primary"])
            row.grid(row=row_index, column=0, sticky="ew", pady=5)
            tk.Label(row, text=field["label"], width=25, anchor=tk.W,
                     bg=app._colors["bg_primary"], fg=app._colors["fg_secondary"]).pack(side=tk.LEFT)
            value = tk.StringVar(value=current.get(key, ""))
            entry = tk.Entry(
                row, textvariable=value, relief=tk.FLAT, bd=0,
                bg=app._colors["bg_input"], fg=app._colors["fg_primary"],
                insertbackground=app._colors["fg_primary"],
                show="•" if field.get("secret") else "",
            )
            entry.pack(side=tk.LEFT, fill=tk.X, expand=True, ipady=5, padx=(0, 8))
            if field.get("secret"):
                shown = {"value": False}
                def toggle_visibility(widget=entry, state=shown):
                    state["value"] = not state["value"]
                    widget.configure(show="" if state["value"] else "•")
                ttk.Button(row, text="Show", width=6, command=toggle_visibility).pack(side=tk.RIGHT)
            entries[key] = entry
            field_vars[key] = value

        if selected_id == "youtube":
            help_var.set("In Google Cloud Console, enable YouTube Data API v3 and create an OAuth client of type Desktop app. TextAnimator uses a random local loopback port with PKCE; do not create a Web application client.")
        elif selected_id == "tiktok":
            help_var.set("In TikTok for Developers, add Login Kit and Content Posting API. Register the desktop loopback redirect URI http://127.0.0.1:*/callback (wildcard port), and request user.info.basic plus video.publish. Public posting requires TikTok app audit; unaudited apps are private-only.")
        else:
            help_var.set("Create an app in the platform's developer portal and enable the permissions required for publishing. Redirect URI requirements are shown during OAuth connection.")
        form.columnconfigure(0, weight=1)

    def save_credentials():
        values = {key: var.get().strip() for key, var in field_vars.items()}
        store.save(selected_id, values)
        saved_config = store.get(selected_id)
        complete = _credentials_complete(selected_id, saved_config)
        if on_saved is not None and not complete:
            messagebox.showwarning(
                "Credentials incomplete",
                "The required credentials are still missing. Fill all required fields before connecting.",
                parent=dlg,
            )
            return
        messagebox.showinfo(
            "Credentials saved",
            f"{labels[selected_id]} developer credentials saved. "
            "They will be used automatically when connecting and publishing.",
            parent=dlg,
        )
        if on_saved is not None:
            callback = on_saved
            dlg.destroy()
            callback()

    def clear_credentials():
        if not messagebox.askyesno(
            "Clear credentials",
            f"Delete saved {labels[selected_id]} developer credentials? Connected account tokens are not removed.",
            parent=dlg,
        ):
            return
        store.delete(selected_id)
        render_fields()
        messagebox.showinfo("Credentials cleared", "Saved developer credentials were deleted.", parent=dlg)

    platform_box.bind("<<ComboboxSelected>>", render_fields)
    render_fields()

    buttons = tk.Frame(dlg, bg=app._colors["bg_primary"])
    buttons.pack(fill=tk.X, padx=18, pady=(0, 16))
    ttk.Button(buttons, text="Clear Saved Credentials", command=clear_credentials).pack(side=tk.LEFT)
    ttk.Button(buttons, text="Close", command=dlg.destroy).pack(side=tk.RIGHT, padx=(6, 0))
    ttk.Button(buttons, text="Save Credentials", style="Accent.TButton",
               command=save_credentials).pack(side=tk.RIGHT)


def _connect_account(app: "TextAnimatorApp") -> None:
    """Open a dialog to choose a platform and start OAuth flow."""
    try:
        from .social.registry import list_platforms
    except ImportError:
        messagebox.showwarning("Social not available",
                               "Install text-animator[social] to use publishing.")
        return

    platforms = list_platforms()
    if not platforms:
        messagebox.showinfo("No platforms", "No platform adapters found.")
        return

    dlg = tk.Toplevel(app)
    dlg.title("Connect Platform")
    dlg.geometry("420x300")
    dlg.configure(bg=app._colors["bg_primary"])
    dlg.grab_set()

    tk.Label(dlg, text="Choose a platform to connect:",
             bg=app._colors["bg_primary"], fg=app._colors["fg_primary"],
             font=("Segoe UI", 11)).pack(pady=(16, 8))

    platform_var = tk.StringVar()
    for cap in platforms:
        tk.Radiobutton(dlg, text=cap.platform_name,
                       variable=platform_var, value=cap.platform_id,
                       bg=app._colors["bg_primary"], fg=app._colors["fg_primary"],
                       selectcolor=app._colors["bg_tertiary"],
                       font=("Segoe UI", 10)).pack(anchor=tk.W, padx=32)

    def _start_oauth():
        pid = platform_var.get()
        if not pid:
            messagebox.showwarning("Select platform", "Choose a platform first.", parent=dlg)
            return
        dlg.destroy()
        if not _credentials_complete(pid):
            _manage_api_credentials(
                app, pid,
                on_saved=lambda p=pid: _run_oauth_flow(app, p),
            )
            return
        _run_oauth_flow(app, pid)

    ttk.Button(dlg, text="Connect →", style="Accent.TButton",
               command=_start_oauth).pack(pady=16)


def _run_oauth_flow(app: "TextAnimatorApp", platform_id: str) -> None:
    """Run OAuth in a background thread and open the browser."""
    try:
        from .social.registry import load_adapter
        from .social.oauth import generate_state, loopback_port
        from .social.credentials import TokenStore
    except ImportError:
        messagebox.showerror("Social error", "social extras not installed.")
        return

    def _worker():
        try:
            adapter = load_adapter(platform_id)
            state = generate_state()
            port, cancel_ev, result_q = loopback_port(state)
            redirect_uri = f"http://127.0.0.1:{port}/callback"
            url = adapter.auth_url(state, redirect_uri)
            webbrowser.open(url)
            app.after(0, lambda: app._set_status(
                f"Browser opened for {platform_id} — complete auth in your browser…"))

            # Wait up to 2 minutes
            import queue as _q
            try:
                result = result_q.get(timeout=120)
            except _q.Empty:
                cancel_ev.set()
                app.after(0, lambda: app._set_status("OAuth timed out"))
                return

            if result.error:
                app.after(0, lambda e=result.error: app._set_status(f"OAuth error: {e}"))
                return

            bundle = adapter.exchange_code(result.code, state, redirect_uri)
            account = adapter.fetch_account(bundle)
            bundle.account_id = account.account_id

            store = TokenStore()
            store.save(bundle)
            app.after(0, lambda n=account.display_name: (
                app._set_status(f"Connected: {n} on {platform_id}"),
                _refresh_account_chips(app),
            ))
        except Exception as exc:
            import traceback
            app.after(0, lambda e=str(exc): app._set_status(f"OAuth error: {e}"))

    threading.Thread(target=_worker, daemon=True).start()


def _manage_accounts(app: "TextAnimatorApp") -> None:
    """Open a simple account manager dialog."""
    try:
        from .social.credentials import TokenStore
        from .social.registry import get_capability
    except ImportError:
        return

    store = TokenStore()
    accounts = store.list_accounts()

    dlg = tk.Toplevel(app)
    dlg.title("Manage Accounts")
    dlg.geometry("480x360")
    dlg.configure(bg=app._colors["bg_primary"])
    dlg.grab_set()

    tk.Label(dlg, text="Connected Accounts",
             bg=app._colors["bg_primary"], fg=app._colors["fg_primary"],
             font=("Segoe UI", 12, "bold")).pack(pady=(12, 8))

    if not accounts:
        tk.Label(dlg, text="No accounts connected.",
                 bg=app._colors["bg_primary"], fg=app._colors["fg_dim"]).pack(pady=20)
        return

    for platform, account_id in accounts:
        cap = get_capability(platform)
        name = cap.platform_name if cap else platform

        row = tk.Frame(dlg, bg=app._colors["bg_secondary"], pady=4)
        row.pack(fill=tk.X, padx=12, pady=2)
        tk.Label(row, text=f"{name} — {account_id}",
                 bg=app._colors["bg_secondary"], fg=app._colors["fg_primary"],
                 font=("Segoe UI", 10)).pack(side=tk.LEFT, padx=8)

        def _disconnect(p=platform, a=account_id):
            if messagebox.askyesno("Disconnect",
                                   f"Remove credentials for {p}/{a}?", parent=dlg):
                store.delete(p, a)
                dlg.destroy()
                _manage_accounts(app)
                _refresh_account_chips(app)

        ttk.Button(row, text="Disconnect", style="Danger.TButton",
                   command=_disconnect).pack(side=tk.RIGHT, padx=4)

        def _reauth(p=platform, a=account_id):
            dlg.destroy()
            _run_oauth_flow(app, p)

        ttk.Button(row, text="Re-auth",
                   command=_reauth).pack(side=tk.RIGHT, padx=4)


def _load_publish_source(app: "TextAnimatorApp") -> None:
    """Load files from the selected source into the publish queue tree."""
    source = app._pub_source_var.get()
    rows = []

    if source == "batch":
        # Pull done results from last batch
        try:
            results = app.batch_renderer.last_results
            rows = [r for r in results if r.get("status") == "done" and r.get("path")]
        except Exception:
            pass
        if not rows:
            messagebox.showinfo("No batch results",
                                "No completed batch results found. Run a batch first.")
            return
    elif source == "single":
        path = getattr(app, "out_entry", None)
        path_str = path.get().strip() if path else ""
        if path_str and os.path.isfile(path_str):
            rows = [{"title": os.path.basename(path_str), "path": path_str}]
        else:
            messagebox.showinfo("No output", "No rendered output file found.")
            return

    _add_rows_to_publish_queue(app, rows)


def _add_publish_files(app: "TextAnimatorApp") -> None:
    paths = filedialog.askopenfilenames(
        title="Add video files",
        filetypes=[("Video files", "*.mp4 *.mov *.avi *.mkv"), ("All files", "*.*")],
    )
    rows = [{"title": os.path.basename(p), "path": p} for p in paths if os.path.isfile(p)]
    _add_rows_to_publish_queue(app, rows)


def _add_rows_to_publish_queue(app: "TextAnimatorApp", rows: list) -> None:
    """Add source file rows to the publish queue, one row per platform account."""
    try:
        from .social.credentials import TokenStore
    except ImportError:
        return

    store = TokenStore()
    accounts = store.list_accounts()
    if not accounts:
        messagebox.showinfo("No accounts",
                            "Connect at least one social account first (Publish tab).")
        return

    for row in rows:
        file_path = row.get("path", "")
        title = row.get("title", os.path.basename(file_path))
        for platform, account_id in accounts:
            iid = f"{file_path}::{platform}::{account_id}"
            if not app._pub_tree.exists(iid):
                app._pub_tree.insert("", tk.END, iid=iid, values=(
                    app._pub_tree.index(iid) + 1 if app._pub_tree.exists(iid) else
                    len(app._pub_tree.get_children()) + 1,
                    os.path.basename(file_path),
                    platform, account_id,
                    "—", "Pending", "",
                ), tags=("pending",))

    # Store metadata on the app
    if not hasattr(app, "_pub_meta"):
        app._pub_meta = {}


def _clear_publish_queue(app: "TextAnimatorApp") -> None:
    app._pub_tree.delete(*app._pub_tree.get_children())


def _apply_pub_meta(app: "TextAnimatorApp") -> None:
    """Apply editor fields to selected rows."""
    sel = app._pub_tree.selection()
    if not sel:
        messagebox.showinfo("No selection", "Select rows to apply metadata to.")
        return
    if not hasattr(app, "_pub_meta"):
        app._pub_meta = {}
    for iid in sel:
        previous = app._pub_meta.get(iid, {})
        app._pub_meta[iid] = {
            "title": app._pub_title.get(),
            "description": app._pub_desc.get(),
            "tags": [t.strip() for t in app._pub_tags.get().split(",") if t.strip()],
            "visibility": app._pub_vis_var.get(),
            "auto_conform": app._pub_conform_var.get(),
            "extra": dict(previous.get("extra", {})),
        }
    app._set_status(f"Metadata applied to {len(sel)} item(s)")


def _tiktok_options_dialog(app: "TextAnimatorApp") -> None:
    """Load creator-specific TikTok settings and let the user choose valid options."""
    try:
        from .social.credentials import TokenStore
        from .social.registry import load_adapter
    except ImportError as exc:
        messagebox.showerror("TikTok unavailable", str(exc), parent=app)
        return

    selected = app._pub_tree.selection()
    targets = []
    for iid in selected:
        values = list(app._pub_tree.item(iid, "values"))
        if len(values) > 3 and values[2] == "tiktok":
            targets.append((iid, values[3]))
    accounts = {account_id for _iid, account_id in targets}
    if not targets:
        messagebox.showinfo("Select TikTok rows", "Select one or more TikTok publishing rows first.", parent=app)
        return
    if len(accounts) != 1:
        messagebox.showwarning("Select one TikTok account",
                               "TikTok options must be loaded for one creator account at a time.", parent=app)
        return

    account_id = next(iter(accounts))
    dlg = tk.Toplevel(app)
    dlg.title("TikTok Creator & Posting Options")
    dlg.geometry("560x590")
    dlg.minsize(500, 500)
    dlg.configure(bg=app._colors["bg_primary"])
    dlg.transient(app)
    dlg.grab_set()
    tk.Label(dlg, text="Loading TikTok creator settings…",
             bg=app._colors["bg_primary"], fg=app._colors["fg_primary"],
             font=("Segoe UI", 11)).pack(padx=18, pady=24)

    def _load():
        try:
            bundle = TokenStore().load("tiktok", account_id)
            if bundle is None:
                raise RuntimeError("The selected TikTok account has no saved authorization. Reconnect it.")
            adapter = load_adapter("tiktok")
            creator = adapter.query_creator_info(bundle)
            options = creator.get("privacy_level_options", [])
            if not options:
                raise RuntimeError("TikTok did not return any available privacy levels for this creator.")
            app.after(0, lambda d=creator, o=options: _render(dlg, d, o))
        except Exception as exc:
            app.after(0, lambda e=str(exc): _show_error(e))

    def _show_error(message: str):
        if not dlg.winfo_exists():
            return
        for child in dlg.winfo_children():
            child.destroy()
        tk.Label(dlg, text=f"Unable to load TikTok creator settings:\n{message}",
                 bg=app._colors["bg_primary"], fg=app._colors["danger"],
                 wraplength=500, justify=tk.LEFT).pack(padx=18, pady=24, anchor=tk.W)
        ttk.Button(dlg, text="Close", command=dlg.destroy).pack(anchor=tk.E, padx=18, pady=12)

    def _render(parent, creator: dict, options: list[str]):
        if not parent.winfo_exists():
            return
        for child in parent.winfo_children():
            child.destroy()
        colors = app._colors
        username = creator.get("creator_username", "TikTok creator")
        tk.Label(parent, text=f"Creator: @{username}", bg=colors["bg_primary"],
                 fg=colors["fg_primary"], font=("Segoe UI", 12, "bold")).pack(
                     anchor=tk.W, padx=18, pady=(16, 4))
        max_duration = creator.get("max_video_post_duration_sec")
        duration_text = f"Maximum video duration: {int(max_duration)} seconds" if max_duration else "TikTok did not return a duration limit."
        tk.Label(parent, text=duration_text, bg=colors["bg_primary"],
                 fg=colors["fg_secondary"], font=("Segoe UI", 9)).pack(
                     anchor=tk.W, padx=18, pady=(0, 12))

        current_meta = getattr(app, "_pub_meta", {})
        saved_extra = {}
        for iid, _acct in targets:
            saved_extra = dict(current_meta.get(iid, {}).get("extra", {}))
            if saved_extra:
                break
        generic_visibility = current_meta.get(targets[0][0], {}).get("visibility", app._pub_vis_var.get())
        generic_to_exact = {
            "private": "SELF_ONLY", "unlisted": "MUTUAL_FOLLOW_FRIENDS",
            "public": "PUBLIC_TO_EVERYONE",
        }
        default_privacy = saved_extra.get("privacy_level") or generic_to_exact.get(generic_visibility, "SELF_ONLY")
        if default_privacy not in options:
            default_privacy = options[0]

        privacy_frame = ttk.LabelFrame(parent, text="Privacy levels available for this account", padding=10)
        privacy_frame.pack(fill=tk.X, padx=18, pady=(0, 10))
        privacy_var = tk.StringVar(value=default_privacy)
        privacy_labels = {
            "PUBLIC_TO_EVERYONE": "Public — anyone can view",
            "MUTUAL_FOLLOW_FRIENDS": "Mutual followers",
            "FOLLOWER_OF_CREATOR": "Followers of this creator",
            "SELF_ONLY": "Only you",
        }
        for code in options:
            ttk.Radiobutton(privacy_frame, text=privacy_labels.get(code, code.replace("_", " ").title()),
                            variable=privacy_var, value=code).pack(anchor=tk.W, pady=2)

        interactions = ttk.LabelFrame(parent, text="Interaction controls", padding=10)
        interactions.pack(fill=tk.X, padx=18, pady=(0, 10))
        control_vars = {}
        for key, label, creator_key in [
            ("disable_comment", "Disable comments", "comment_disabled"),
            ("disable_duet", "Disable Duet", "duet_disabled"),
            ("disable_stitch", "Disable Stitch", "stitch_disabled"),
        ]:
            locked = bool(creator.get(creator_key, False))
            var = tk.BooleanVar(value=bool(saved_extra.get(key, False)) or locked)
            control_vars[key] = var
            ttk.Checkbutton(interactions, text=(label + (" (disabled by creator settings)" if locked else "")),
                            variable=var, state="disabled" if locked else "normal").pack(anchor=tk.W, pady=2)

        labels = ttk.LabelFrame(parent, text="Content disclosures", padding=10)
        labels.pack(fill=tk.X, padx=18, pady=(0, 10))
        disclosure_vars = {}
        for key, label in [
            ("brand_content_toggle", "Paid partnership / branded content"),
            ("brand_organic_toggle", "Promoting my own business or brand"),
            ("is_aigc", "AI-generated content"),
        ]:
            var = tk.BooleanVar(value=bool(saved_extra.get(key, False)))
            disclosure_vars[key] = var
            ttk.Checkbutton(labels, text=label, variable=var).pack(anchor=tk.W, pady=2)

        tk.Label(parent,
                 text="TikTok may restrict unaudited developer apps to private posts. "
                      "These choices are revalidated against the creator account immediately before upload.",
                 bg=colors["bg_primary"], fg=colors["fg_dim"], wraplength=515,
                 justify=tk.LEFT, font=("Segoe UI", 8)).pack(anchor=tk.W, padx=18, pady=(0, 12))

        def _save():
            extra = {"privacy_level": privacy_var.get()}
            extra.update({key: var.get() for key, var in control_vars.items()})
            extra.update({key: var.get() for key, var in disclosure_vars.items()})
            if not hasattr(app, "_pub_meta"):
                app._pub_meta = {}
            for iid, _acct in targets:
                meta = dict(app._pub_meta.get(iid, {}))
                old_extra = dict(meta.get("extra", {}))
                old_extra.update(extra)
                meta["extra"] = old_extra
                app._pub_meta[iid] = meta
            app._set_status(f"TikTok options saved for {len(targets)} row(s): {privacy_var.get()}")
            parent.destroy()

        buttons = tk.Frame(parent, bg=colors["bg_primary"])
        buttons.pack(fill=tk.X, padx=18, pady=(0, 16))
        ttk.Button(buttons, text="Close", command=parent.destroy).pack(side=tk.RIGHT, padx=(6, 0))
        ttk.Button(buttons, text="Save TikTok Options", style="Accent.TButton", command=_save).pack(side=tk.RIGHT)

    threading.Thread(target=_load, daemon=True).start()


def _validate_all(app: "TextAnimatorApp") -> None:
    """Run ffprobe validation on all queued items."""
    try:
        from .social.registry import load_adapter
        from .social.base import UploadRequest
    except ImportError:
        return

    items = app._pub_tree.get_children()
    for iid in items:
        vals = list(app._pub_tree.item(iid, "values"))
        file_path = _iid_to_path(iid)
        platform = vals[2] if len(vals) > 2 else ""
        account_id = vals[3] if len(vals) > 3 else ""

        try:
            adapter = load_adapter(platform)
            errors = adapter.validate(UploadRequest(
                file_path=file_path, platform=platform, account_id=account_id))
            if errors:
                validity = "⚠ " + errors[0][:25]
                tag = "error"
            else:
                validity = "✓ Valid"
                tag = "pending"
        except Exception as exc:
            validity = f"✗ {str(exc)[:25]}"
            tag = "error"

        if len(vals) > 4:
            vals[4] = validity
            app._pub_tree.item(iid, values=vals, tags=(tag,))

    app._set_status("Validation complete")


def _upload_selected(app: "TextAnimatorApp") -> None:
    """Start upload jobs for selected rows."""
    try:
        from .social.queue import UploadQueue
        from .social.base import UploadRequest
        from .social.credentials import TokenStore
    except ImportError:
        messagebox.showerror("Error", "social extras not installed")
        return

    sel = app._pub_tree.selection()
    if not sel:
        messagebox.showinfo("No selection", "Select rows to upload.")
        return

    # First-publish consent
    if not messagebox.askyesno("Confirm Upload",
                               f"Upload {len(sel)} file(s) to social platforms?\n\n"
                               "Files will be uploaded with the configured visibility setting. "
                               "Review your selections before proceeding.",
                               icon="warning"):
        return

    if not hasattr(app, "_pub_meta"):
        app._pub_meta = {}

    store = TokenStore()

    def _status_cb(job_id: str, status: str, message: str):
        def _update():
            # Find the tree item matching this job
            for iid in app._pub_tree.get_children():
                stored_jid = getattr(app, "_pub_iid_to_job", {}).get(iid)
                if stored_jid == job_id:
                    vals = list(app._pub_tree.item(iid, "values"))
                    if len(vals) > 5:
                        vals[5] = {
                            "done": "✓ Done", "error": "✗ Error",
                            "running": "Uploading…", "pending": "Pending",
                            "processing": "⏳ Processing (check status)",
                            "needs_reauth": "⚠ Re-auth", "cancelled": "Cancelled",
                        }.get(status, status)
                    q = app._upload_queue
                    if q and status in ("done", "processing", "error", "cancelled"):
                        for qjob in q.results():
                            if qjob.job_id == job_id and qjob.result:
                                if len(vals) > 6:
                                    vals[6] = (qjob.result.post_url or qjob.result.media_id or
                                               qjob.result.error)
                    app._pub_tree.item(iid, values=vals,
                                       tags=(status if status in
                                             ("done", "error", "running", "pending", "processing") else "pending",))
                    if status in ("processing", "error", "cancelled"):
                        app._set_status(message)
        app.after(0, _update)

    q = UploadQueue(status_callback=_status_cb,
                    progress_callback=app._progress_cb)
    app._upload_queue = q

    if not hasattr(app, "_pub_iid_to_job"):
        app._pub_iid_to_job = {}

    requests_list = []
    for iid in sel:
        vals = list(app._pub_tree.item(iid, "values"))
        file_path = _iid_to_path(iid)
        platform = vals[2] if len(vals) > 2 else ""
        account_id = vals[3] if len(vals) > 3 else ""
        meta = app._pub_meta.get(iid, {})

        req = UploadRequest(
            file_path=file_path,
            platform=platform,
            account_id=account_id,
            title=meta.get("title", os.path.basename(file_path)),
            description=meta.get("description", ""),
            tags=meta.get("tags", []),
            visibility=meta.get("visibility", "private"),
            auto_conform=meta.get("auto_conform", False),
            extra=dict(meta.get("extra", {})),
        )
        job_id = q.enqueue(req)
        app._pub_iid_to_job[iid] = job_id
        vals[5] = "Queued"
        app._pub_tree.item(iid, values=vals, tags=("pending",))

    q.start()
    app._set_status(f"Started {len(sel)} upload job(s)")


def _cancel_selected_uploads(app: "TextAnimatorApp") -> None:
    sel = app._pub_tree.selection()
    q = getattr(app, "_upload_queue", None)
    if not q:
        return
    iid_map = getattr(app, "_pub_iid_to_job", {})
    for iid in sel:
        job_id = iid_map.get(iid)
        if job_id:
            q.cancel(job_id)


def _retry_failed(app: "TextAnimatorApp") -> None:
    """Select and re-enqueue only rows that are currently marked failed."""
    failed = []
    for iid in app._pub_tree.get_children():
        vals = list(app._pub_tree.item(iid, "values"))
        status = vals[5] if len(vals) > 5 else ""
        if "Error" in status or "Failed" in status:
            failed.append(iid)
            vals[5] = "Pending"
            app._pub_tree.item(iid, values=vals, tags=("pending",))
    if not failed:
        messagebox.showinfo("Nothing to retry", "There are no failed publishing rows.", parent=app)
        return
    app._pub_tree.selection_set(failed)
    _upload_selected(app)


def _refresh_tiktok_status(app: "TextAnimatorApp") -> None:
    """Refresh TikTok processing rows without accidentally re-uploading them."""
    try:
        from .social.credentials import TokenStore
        from .social.registry import load_adapter
    except ImportError:
        return

    selected = app._pub_tree.selection()
    if not selected:
        messagebox.showinfo("Select TikTok jobs", "Select one or more TikTok rows marked Processing.", parent=app)
        return

    targets = []
    for iid in selected:
        vals = list(app._pub_tree.item(iid, "values"))
        platform = vals[2] if len(vals) > 2 else ""
        status = vals[5] if len(vals) > 5 else ""
        publish_id = vals[6] if len(vals) > 6 else ""
        if platform == "tiktok" and "Processing" in status and publish_id:
            targets.append((iid, vals[3], publish_id))
    if not targets:
        messagebox.showinfo("No pending TikTok posts",
                            "Select TikTok rows marked Processing. The Post URL column stores their publish ID until posting completes.",
                            parent=app)
        return

    def _worker():
        try:
            adapter = load_adapter("tiktok")
            store = TokenStore()
            for iid, account_id, publish_id in targets:
                bundle = store.load("tiktok", account_id)
                if bundle is None:
                    raise RuntimeError(f"No saved TikTok authorization for {account_id}")
                data = adapter.fetch_publish_status(bundle, publish_id)
                remote_status = str(data.get("status", "")).upper()
                fail_reason = data.get("fail_reason", "")
                post_ids = data.get("publicaly_available_post_id", []) or []
                post_url = ""
                if remote_status == "PUBLISH_COMPLETE":
                    creator = adapter.query_creator_info(bundle)
                    username = creator.get("creator_username", "")
                    if post_ids and username:
                        post_url = f"https://www.tiktok.com/@{username}/video/{post_ids[0]}"
                    elif username:
                        post_url = f"https://www.tiktok.com/@{username}"
                    else:
                        post_url = "Published (private / URL unavailable)"
                    display_status = "✓ Done"
                    tag = "done"
                elif remote_status == "FAILED":
                    display_status = f"✗ Failed: {fail_reason}"[:120]
                    post_url = publish_id
                    tag = "error"
                else:
                    display_status = f"⏳ Processing: {remote_status or 'pending'}"
                    post_url = publish_id
                    tag = "processing"
                def _update(row=iid, label=display_status, link=post_url, row_tag=tag):
                    vals_now = list(app._pub_tree.item(row, "values"))
                    if len(vals_now) > 5:
                        vals_now[5] = label
                    if len(vals_now) > 6:
                        vals_now[6] = link
                    app._pub_tree.item(row, values=vals_now, tags=(row_tag,))
                    app._set_status(f"TikTok status: {label}")
                app.after(0, _update)
        except Exception as exc:
            app.after(0, lambda e=str(exc): app._set_status(f"TikTok status check failed: {e}"))

    threading.Thread(target=_worker, daemon=True).start()
    app._set_status(f"Checking {len(targets)} TikTok publish status(es)…")


def _open_post_url(app: "TextAnimatorApp") -> None:
    sel = app._pub_tree.selection()
    if not sel:
        return
    vals = list(app._pub_tree.item(sel[0], "values"))
    url = vals[6] if len(vals) > 6 else ""
    if url and url.startswith("http"):
        webbrowser.open(url)


def _iid_to_path(iid: str) -> str:
    """Extract file path from the composite IID (path::platform::account)."""
    parts = iid.split("::")
    return parts[0] if parts else iid


# ---------------------------------------------------------------------------
# Post-batch bridge: prompt to send to Publish queue
# ---------------------------------------------------------------------------

def _post_batch_publish_prompt(app: "TextAnimatorApp", done_count: int) -> None:
    """Called after batch completes — offer to send results to Publish tab."""
    if done_count == 0:
        return
    try:
        from .social.credentials import TokenStore
        accounts = TokenStore().list_accounts()
        if not accounts:
            return
    except ImportError:
        return

    answer = messagebox.askyesno(
        "Send to Publish?",
        f"{done_count} video(s) rendered successfully.\n\n"
        "Send them to the Publish queue?",
    )
    if answer:
        app.notebook.select(4)   # Publish tab (index 4)
        app._pub_source_var.set("batch")
        _load_publish_source(app)


# ---------------------------------------------------------------------------
# Inject into TextAnimatorApp at class-definition time
# ---------------------------------------------------------------------------

_orig_init = TextAnimatorApp.__init__


def _new_init(self, *args, **kwargs):
    _orig_init(self, *args, **kwargs)

    # Build publish tab
    _build_publish_tab(self, self.notebook)

    # Job strip in action bar (inject above status label)
    c = self._colors
    # Find the action bar frame (bottom)
    for child in self.winfo_children():
        if isinstance(child, tk.Frame) and child.cget("bg") == c["bg_secondary"]:
            # Insert job strip
            strip_frame = tk.Frame(child, bg=c["bg_secondary"])
            strip_frame.pack(side=tk.LEFT, fill=tk.X, expand=False, before=self.progress)
            self._job_strip_frame = strip_frame
            break

    # Patch job registry
    _patch_job_registry(self)
    if hasattr(self, "_job_strip_frame"):
        self._refresh_job_strip()

    # Keyboard shortcut for Publish tab
    self.bind("<Control-p>", lambda e: self.notebook.select(4))
    self.bind("<Control-P>", lambda e: self.notebook.select(4))


TextAnimatorApp.__init__ = _new_init


# Patch batch worker to call post-batch prompt
_orig_run_batch = TextAnimatorApp._run_batch if hasattr(TextAnimatorApp, "_run_batch") else None


def _patched_run_batch(self):
    """Wrapper that calls _run_batch then offers to send results to Publish."""
    # Delegate
    if _orig_run_batch:
        _orig_run_batch(self)
    # The actual batch call is async; we hook into the worker by wrapping
    # the showinfo that the existing code fires:
    # (this is handled by overriding messagebox in the batch worker via monkey-patching
    #  the after-call; simpler approach: use _refresh_job_strip after batch)
    # We rely on the modified batch worker below instead


