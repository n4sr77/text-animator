"""Structured rotating logger for TextAnimator.

Usage:
    from .log_setup import get_logger
    log = get_logger(__name__)
    log.info("Rendering started")
"""

from __future__ import annotations

import logging
import logging.handlers
from pathlib import Path

_LOG_DIR = Path.home() / ".textanimator" / "logs"
_LOG_FILE = _LOG_DIR / "textanimator.log"
_MAX_BYTES = 2 * 1024 * 1024   # 2 MB per file
_BACKUP_COUNT = 5
_FMT = "%(asctime)s  %(levelname)-8s  %(name)s  %(message)s"
_DATE_FMT = "%Y-%m-%d %H:%M:%S"

_root_configured = False


def _ensure_handler() -> None:
    global _root_configured
    if _root_configured:
        return
    _LOG_DIR.mkdir(parents=True, exist_ok=True)
    handler = logging.handlers.RotatingFileHandler(
        _LOG_FILE, maxBytes=_MAX_BYTES, backupCount=_BACKUP_COUNT, encoding="utf-8"
    )
    handler.setFormatter(logging.Formatter(_FMT, datefmt=_DATE_FMT))
    root = logging.getLogger("text_animator")
    root.setLevel(logging.DEBUG)
    if not root.handlers:
        root.addHandler(handler)
    _root_configured = True


def get_logger(name: str) -> logging.Logger:
    _ensure_handler()
    return logging.getLogger(name)


def log_dir() -> Path:
    return _LOG_DIR
