"""TextAnimator – kinetic black & white text video generator."""

__version__ = "3.2.0"
__all__ = ["TextAnimatorApp"]

def __getattr__(name):
    if name == "TextAnimatorApp":
        from .gui import TextAnimatorApp
        return TextAnimatorApp
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
