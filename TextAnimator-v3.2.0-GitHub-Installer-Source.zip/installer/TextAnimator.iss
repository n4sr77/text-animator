#define AppName "TextAnimator"
#define AppVersion "3.2.0"
#define AppPublisher "TextAnimator"

[Setup]
AppId={{E9D08F2A-65B7-4A70-AED7-9C78A7E5E9B4}
AppName={#AppName}
AppVersion={#AppVersion}
AppVerName={#AppName} {#AppVersion}
AppPublisher={#AppPublisher}
DefaultDirName={localappdata}\Programs\TextAnimator
DefaultGroupName=TextAnimator
DisableProgramGroupPage=yes
PrivilegesRequired=lowest
ArchitecturesAllowed=x64
ArchitecturesInstallIn64BitMode=x64
Uninstallable=yes
UninstallDisplayName=TextAnimator {#AppVersion}
UninstallDisplayIcon={app}\TextAnimator.exe
WizardStyle=modern
Compression=lzma2/ultra64
SolidCompression=yes
OutputDir=..\installer-output
OutputBaseFilename=TextAnimator-v{#AppVersion}-Setup
SetupLogging=yes
CloseApplications=yes
RestartApplications=no
UsePreviousAppDir=yes

[Tasks]
Name: "desktopicon"; Description: "Create a desktop shortcut"; GroupDescription: "Additional shortcuts:"; Flags: unchecked

[Files]
Source: "..\dist\TextAnimator\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{autoprograms}\TextAnimator"; Filename: "{app}\TextAnimator.exe"; WorkingDir: "{app}"
Name: "{autodesktop}\TextAnimator"; Filename: "{app}\TextAnimator.exe"; WorkingDir: "{app}"; Tasks: desktopicon

[Run]
Filename: "{app}\TextAnimator.exe"; Description: "Launch TextAnimator"; WorkingDir: "{app}"; Flags: nowait postinstall skipifsilent
