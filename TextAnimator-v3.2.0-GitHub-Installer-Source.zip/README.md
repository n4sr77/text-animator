# TextAnimator v3.2.0 — Kinetic Type Studio + Social Publishing

A desktop video animation tool that turns text into kinetic typography videos,
with a refreshed ttkbootstrap interface, hardware-aware H.264 encoding, batch soundtrack assignment and social publishing.

---

## Features

**Animation Studio**
- 11 animation presets (Classic, Typewriter, Bounce, Glitch, Zoom Pulse, …)
- Batch rendering from CSV with per-row overrides
- Background images, custom fonts, outline, shadow
- Preview engine for fast iteration
- Modern ttkbootstrap desktop theme (with native ttk fallback)
- Hardware-aware H.264 encoding: NVIDIA NVENC → Intel Quick Sync → CPU fallback
- Media Studio: convert, resize, trim, filter any video
- Replace video audio with one fixed track or random tracks from an audio folder
- Random audio uses a shuffled cycle without repeats until all eligible tracks are used
- CSV `audio` column overrides random selection per row for deterministic batch soundtrack choices

**Social Publishing (requires `[social]` extras)**
- 9 platform adapters: YouTube, TikTok, Instagram, Facebook, X/Twitter,
  LinkedIn, Threads, Pinterest, Vimeo
- OAuth 2.0 + PKCE loopback flow — in-app API credential editor and OS keyring storage
- ffprobe-based pre-upload validation
- Auto-conform (re-transcode) to meet platform specs
- Resumable chunked uploads with exponential backoff + retry
- Circuit breaker (auto `needs_reauth` after repeated auth failures)
- Persistent queue survives restarts (`~/.textanimator_queue.json`)
- Post-batch bridge: "12 rendered — send to Publish queue?"

---

## Installation

**Basic (animation only):**
```bash
pip install -r requirements.txt
python run.py
```

**With social publishing:**
```bash
pip install 'text-animator[social]'
# or:
pip install moviepy Pillow imageio-ffmpeg \
    keyring \
    google-api-python-client google-auth-oauthlib google-auth-httplib2 \
    tweepy requests requests-toolbelt
python run.py
```

---

## Platform Setup

You no longer need to create environment variables to connect a social account.
Open **Publish → API Credentials…**, select a platform, enter its developer-app
credentials, and choose **Save Credentials**. Then use **Connect…** to authorize
the social account in your browser. The same saved app credentials are reused
for account refreshes and uploads.

Credentials are stored in the operating system keyring when available. If no
usable keyring is installed, TextAnimator uses a separate file under
`~/.textanimator/` with owner-only permissions and displays a warning. Install
the social extras (which include `keyring`) to enable OS-backed storage.

Legacy environment variables are still supported as a fallback for existing
setups:

| Platform   | Environment variables |
|------------|-----------------------|
| YouTube    | `YT_CLIENT_ID`, `YT_CLIENT_SECRET` |
| TikTok     | `TIKTOK_CLIENT_KEY`, `TIKTOK_CLIENT_SECRET` |
| Instagram  | `IG_APP_ID`, `IG_APP_SECRET` |
| Facebook   | `FB_APP_ID`, `FB_APP_SECRET` |
| X/Twitter  | `TWITTER_API_KEY`, `TWITTER_API_SECRET`, `TWITTER_CLIENT_ID`, `TWITTER_CLIENT_SECRET` |
| LinkedIn   | `LI_CLIENT_ID`, `LI_CLIENT_SECRET` |
| Threads    | `THREADS_APP_ID`, `THREADS_APP_SECRET` |
| Pinterest  | `PINTEREST_APP_ID`, `PINTEREST_APP_SECRET` |
| Vimeo      | `VIMEO_CLIENT_ID`, `VIMEO_CLIENT_SECRET` or `VIMEO_ACCESS_TOKEN` |

Register each platform's redirect URI in its developer console as required.
TextAnimator starts a local loopback callback server during authorization. For
TikTok desktop Login Kit, register `http://127.0.0.1:*/callback` (wildcard port).
For YouTube, create an OAuth client of type **Desktop app**; Google permits the
loopback IP address with a random local port, so do not use a Web application client.

---

## OAuth Scopes

| Platform   | Required Scopes |
|------------|-----------------|
| YouTube    | `youtube.upload`, `youtube.readonly` |
| TikTok     | `user.info.basic`, `video.publish` |
| Instagram  | `instagram_basic`, `instagram_content_publish`, `pages_read_engagement` |
| Facebook   | `pages_manage_posts`, `pages_read_engagement`, `publish_video` |
| X/Twitter  | `tweet.write`, `tweet.read`, `users.read`, `offline.access` |
| LinkedIn   | `w_member_social`, `r_liteprofile` |
| Threads    | `threads_basic`, `threads_content_publish` |
| Pinterest  | `boards:read`, `pins:write`, `user_accounts:read` |
| Vimeo      | `public`, `private`, `upload` |

---

## Keyboard Shortcuts

| Shortcut | Action |
|----------|--------|
| Ctrl+Enter | Generate video |
| Ctrl+B | Run batch |
| Ctrl+O | Open CSV |
| Ctrl+P | Go to Publish tab |
| Ctrl+Shift+U | Upload selected |
| Esc | Cancel current job |
| Ctrl+Q | Quit |

---

## CSV Batch Format

```csv
title,sentence,preset,color_mode,font_size,word_duration,gap,end_hold,outline,shadow,audio
Quote One,Words become motion,classic,white_on_black,90,0.85,0.08,1.2,false,false,
```

Optional columns: `preset`, `color_mode`, `font`, `font_size`, `word_duration`,
`gap`, `end_hold`, `fps`, `outline`, `outline_width`, `shadow`, `shadow_offset`,
`auto_fit_font`, `resolution`, `transition`, `transition_duration`, `bg_image`,
`encode_preset`, `hardware_backend`, `audio`, `audio_volume`, `audio_fade_in`,
`audio_fade_out`, and `filename`.

The Batch tab has two sub-tabs: **Queue & Output** and **Batch Render Settings**.
The latter has independent defaults for every renderer setting; changing Single
settings does not change Batch. Use **Copy Single Settings → Batch** for a one-time
copy, then edit Batch independently. Settings can be saved explicitly or are saved
when a batch starts. Non-empty CSV values override the Batch default for that row;
blank CSV cells inherit the Batch default.

In Queue & Output, choose a fixed soundtrack or a random audio folder. Selection
priority is: explicit CSV row `audio` path → fixed Batch track (when enabled) →
random folder → no soundtrack. Relative CSV audio paths are resolved from the CSV
file's directory. Use `none` in a row's `audio` cell to force silence for that row,
even when random mode is enabled. Choosing **No fallback track** disables fallback
soundtracks even when a fixed path remains in the picker.

### Hardware encoding

TextAnimator prefers a system FFmpeg found on `PATH` because the small FFmpeg
binary bundled by `imageio-ffmpeg` may not include NVENC or Quick Sync. In Single,
choose an encoder in Settings; in Batch, choose it independently under **Batch →
Batch Render Settings**. **Auto (recommended)** tries NVIDIA NVENC, then Intel
Quick Sync, then CPU/x264. The selected encoder is shown after a successful render.
A GPU encoder
must be compiled into FFmpeg and supported by the installed graphics driver; a
failed hardware attempt automatically falls back to software. MoviePy/Pillow text
rasterization and compositing still run on the CPU; hardware acceleration applies
to the final H.264 encoding stage.

### Replacing audio in existing videos

In **Media Studio → Replace Video Audio**, choose:

- **Keep original**: preserve each video's existing audio stream.
- **Random from folder**: choose one track per video from the selected audio folder;
  each track is used once before the pool is reshuffled.
- **Use fixed track**: replace the audio on every queued video with the selected file.

The replacement soundtrack loops or trims automatically to match the video duration.
The replacement modes apply only to video inputs; queued images and audio files are
left unchanged. GIF exports cannot contain audio.

---

## Running Tests

```bash
./run_tests.sh
# or:
python -m pytest tests/ -v
```

---

## Architecture

```
text_animator/
├── gui.py              # ttkbootstrap UI (Single, Batch, Media Studio, Settings, Publish)
├── hardware.py         # FFmpeg encoder discovery and NVENC/QSV/CPU fallback plan
├── audio_library.py    # Audio-folder discovery and no-repeat random selection
├── renderer.py         # VideoRenderer — build_clip + render_to_file
├── batch.py            # BatchRenderer — CSV → MP4 pipeline
├── preview.py          # PreviewEngine — low-res preview
├── effects.py          # Easing, text styling, shadow compositing
├── presets/            # 11 animation presets
├── social/
│   ├── base.py         # MediaSpec, UploadRequest/Result, SocialAdapter ABC
│   ├── credentials.py  # TokenStore — keyring + 0600 plaintext fallback
│   ├── oauth.py        # PKCE, loopback redirect, device code, token refresh
│   ├── validator.py    # ffprobe-based MediaSpec validation
│   ├── registry.py     # Platform adapter discovery
│   ├── queue.py        # UploadQueue — backoff, circuit breaker, cancel
│   ├── conformance.py  # Auto-transcode to meet platform specs
│   ├── persistent_queue.py  # JSON-backed queue persistence
│   └── platforms/
│       ├── youtube.py
│       ├── tiktok.py
│       ├── instagram.py
│       ├── facebook.py
│       ├── x_twitter.py
│       ├── linkedin.py
│       ├── threads.py
│       ├── pinterest.py
│       └── vimeo.py
└── log_setup.py        # Rotating file logger → ~/.textanimator/logs/
```

---

## Privacy & Security

- Access tokens are stored exclusively in the OS keyring when available.
- Plaintext fallback (`~/.textanimator/credentials.json`) uses `0600` file
  permissions and warns the user on first use.
- `TokenBundle.__repr__` never reveals secrets — safe to log.
- No telemetry or external analytics of any kind.

---

## Changelog — v3.0.1

- Added the in-app **Publish → API Credentials…** editor for platform developer credentials.
- Added OS keyring storage with owner-only file fallback when a keyring is unavailable.
- Corrected TikTok desktop OAuth to use PKCE and the `video.publish` permission.
- Added TikTok creator-info preflight, creator-approved privacy options, disclosure controls,
  chunk-size handling, and asynchronous publish-status verification.
- Hardened YouTube Desktop OAuth, metadata validation, resumable upload retries, and API
  error classification.
- Fixed queue processing/cancellation reporting, OAuth callback waiting/state checks,
  and retry-failed selection behavior.
- Added mocked YouTube/TikTok integration and regression coverage (67 tests passing).


## Changelog — v3.1.0

- Adopted the ttkbootstrap Superhero theme while retaining a native ttk fallback.
- Added hardware-aware H.264 rendering with NVIDIA NVENC, Intel Quick Sync and CPU fallback.
- Added Media Studio soundtrack replacement: one fixed track for all queued videos or a no-repeat random folder cycle.
- Added Batch soundtrack controls and deterministic priority: CSV row override, selected Batch fixed track, random folder, then silence.
- Added relative-to-CSV audio path resolution and a fixed batch soundtrack picker.
- Added encoder detection and successful encoder reporting in rendering status.
- Added automated coverage for random/fixed audio assignment, CSV overrides, relative paths and media stream mapping.

### v3.0.0 baseline history

- **Phase 0**: Fixed shadow compositing bug (was discarding `_shadow_clip`);
  added structured rotating logger; added `pyproject.toml` with pinned deps.
- **Phase 1**: Full `social/` package — errors, dataclasses, ABC, credentials,
  ffprobe validator, platform registry.
- **Phase 2**: OAuth engine — PKCE, loopback redirect server, device code flow,
  proactive token refresh, rotation-safe persist.
- **Phase 3–8**: All 9 platform adapters (YouTube, TikTok, Instagram, Facebook,
  X/Twitter, LinkedIn, Threads, Pinterest, Vimeo).
- **Phase 4**: Upload queue with exponential backoff + jitter, circuit breaker,
  per-platform worker pools, independent cancel.
- **Phase 5**: Job registry — cancellable chip strip in action bar.
- **Phase 6**: Publish tab — account chips, in-app API credentials editor,
  source selector, Treeview queue, per-item editor, Validate All / Upload / Cancel / Retry.
- **Phase 7**: Post-batch publish bridge + auto-conform (ffmpeg re-transcode).
- **Phase 9**: Persistent queue; diagnostics export menu item.
- **Phase 10**: Full test suite (token store, validator, OAuth, queue, registry,
  YouTube mocked integration, shadow compositing).


## Changelog — v3.2.0

- Added a dedicated Batch Render Settings panel with independent, persistent defaults.
- Batch no longer reads its render configuration or soundtrack from the Single tab.
- Added explicit one-time copying from Single settings to Batch and a separate Batch reset action.
- Extended CSV row overrides to include outline/shadow dimensions, font auto-fit, transition duration, encoder preference, encoding preset and audio mix controls.
- Added Batch encoder detection status for NVIDIA NVENC, Intel Quick Sync and CPU fallback.

## Windows x64 Setup.exe installer

The Windows release is distributed as one persistent installer,
`TextAnimator-v3.2.0-Setup.exe`, not as a portable application folder. The Inno Setup
installer places the bundled application under `%LOCALAPPDATA%\Programs\TextAnimator`,
creates Start Menu shortcuts, offers an optional Desktop shortcut, and registers a
normal uninstaller. Settings, credentials and queue data are stored outside the
installation directory and survive application upgrades and normal uninstallation.

Build on Windows 10/11 x64 with CPython 3.11 x64 and Inno Setup 6/7:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\prepare_windows.ps1
.\build_windows.ps1
.\build_installer.ps1
```

The preparation step resolves and hash-locks Windows dependencies and downloads
binary wheels into `wheelhouse\windows-py311`. The build step installs only from
that wheelhouse, runs `pip check` and all regression tests, then creates the bundled
application in `dist\TextAnimator`. The final command compiles
`installer\TextAnimator.iss` into
`installer-output\TextAnimator-v3.2.0-Setup.exe`. Build dependencies stay isolated
in `.windows-build-venv`; no global Python packages are modified.

The GitHub Actions workflow `.github/workflows/build-windows.yml` runs on pushes to
`main` and can be started manually. It performs the same tests and packaging on a
native Windows runner, uploads the installer artifact, and publishes the direct
`.exe` file as a GitHub Release asset. See [`WINDOWS_BUILD_README.md`](WINDOWS_BUILD_README.md).

### Changelog — v3.2.0 Windows packaging

- Added a Windows x64 CPython 3.11 dependency input set with full hash-locked
  transitive resolution generated on the target platform.
- Added wheelhouse preparation and offline installation/build scripts.
- Added PyInstaller onedir spec bundling ttkbootstrap assets, MoviePy, imageio-ffmpeg,
  keyring, Google OAuth/API libraries, Tweepy and social adapters.
- Added build gates: `pip check`, complete pytest suite and packaged executable
  version smoke test.
- Added an Inno Setup per-user installer and GitHub Actions release workflow for a direct Setup.exe download.


For the GitHub Actions release workflow and direct Setup.exe download, see [GITHUB_RELEASE_BUILD.md](GITHUB_RELEASE_BUILD.md).
