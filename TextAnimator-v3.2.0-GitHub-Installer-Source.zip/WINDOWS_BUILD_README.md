# TextAnimator 3.2.0 — Windows x64 Setup.exe

## What you download

The release provides one file: `TextAnimator-v3.2.0-Setup.exe`. It is a real per-user Windows installer, not a portable archive. The installer deploys the complete PyInstaller application directory, including the bundled Python runtime, Python libraries, ttkbootstrap assets, social-publishing dependencies and imageio-ffmpeg binary.

The target computer does not need Python or separately installed Python wheels.

## Persistent installation behaviour

- Default install folder: `%LOCALAPPDATA%\Programs\TextAnimator`.
- Creates a Start Menu shortcut.
- Offers an optional Desktop shortcut.
- Registers a normal Windows uninstaller in the current user's installed-apps list.
- Supports installing an updated version over the same app directory.
- User preferences (`.textanimator_config.json`), queue data and credentials are kept outside the installation directory in the user's home profile/keyring. Upgrades and normal uninstall do not delete them.
- Installs per-user and does not require administrator elevation by default.

## Build from GitHub Actions

The repository workflow `.github/workflows/build-windows.yml` runs on pushes to `main` and can also be started manually from the GitHub Actions page. It:

1. Runs on a native Windows x64 GitHub-hosted runner.
2. Installs CPython 3.11 x64 and Inno Setup.
3. Resolves and hash-locks the dependencies for Windows, downloading wheels only.
4. Installs from the wheelhouse with `--no-index` and `--require-hashes`.
5. Runs `pip check` and the complete pytest suite.
6. Builds the bundled application with PyInstaller and smoke-tests `TextAnimator.exe --version`.
7. Compiles the Inno Setup script into `TextAnimator-v3.2.0-Setup.exe`.
8. Uploads that `.exe` as a workflow artifact and publishes it as a direct GitHub Release asset.

## Build locally on Windows

Requirements: Windows 10/11 x64, CPython 3.11 x64, Python Launcher, internet during initial dependency preparation, and Inno Setup 6 or 7.

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\prepare_windows.ps1
.\build_windows.ps1
.\build_installer.ps1
```

The final installer is written to `installer-output\TextAnimator-v3.2.0-Setup.exe`.

## Dependency isolation and conflicts

The builder uses `.windows-build-venv`, resolves a Windows/Python 3.11-specific lock with hashes, downloads binary wheels only, installs with `--no-index --require-hashes`, then runs `pip check`. It does not modify the global Python installation. The installed app bundles the resolved dependencies and has no dependency on the target PC's Python installation.

Pillow is pinned to 11.3.0 because MoviePy 2.2.1 requires Pillow below 12.

## GPU / FFmpeg

The installer includes imageio-ffmpeg's FFmpeg binary for CPU fallback. NVIDIA NVENC or Intel Quick Sync requires a compatible driver and a system FFmpeg build on PATH that exposes `h264_nvenc` or `h264_qsv`. GPU encoding is not guaranteed merely by installing the application; hardware support is checked at runtime.
