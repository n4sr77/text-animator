# Batch Render Settings (v3.2.0)

## Where to find the controls

Open **Batch → Batch Render Settings**. This page is independent from the Single tab and contains the complete render-control set:

- Typography: animation preset, color mode, font family and font size.
- Timing: word duration, inter-word gap and final hold.
- Output: resolution, frame rate, transition type and transition duration.
- Effects: outline, outline width, shadow, shadow offset and automatic font fitting.
- Background: default background image for rows without a CSV `bg_image` value.
- Encoding: quality preset and hardware preference (Auto, NVIDIA NVENC, Intel Quick Sync or CPU).
- Audio mix: volume, fade-in and fade-out.

Track assignment remains in **Batch → Queue & Output → Batch Soundtrack Assignment**.

## Independence and persistence

Batch uses its own values. Editing Single does not affect Batch, nor does editing Batch change Single. Use **Copy Single Settings → Batch** for an explicit one-time copy. **Save Batch Defaults** persists the current Batch panel; values are also saved when a batch starts. **Reset Batch Defaults** resets only Batch. The saved dictionary is stored under `batch_render_settings` in `~/.textanimator_config.json`.

## CSV precedence

For every supported setting, a non-empty CSV field overrides the Batch default for that row. Blank or omitted CSV fields inherit the Batch default. Numeric values are clamped to supported ranges for outline width, shadow offset, transition duration, audio volume and audio fades.

| CSV field | Description |
|---|---|
| `preset` | Animation preset key |
| `color_mode` | `white_on_black` or `black_on_white` |
| `font`, `font_size` | Font family and point/pixel size |
| `word_duration`, `gap`, `end_hold` | Timing in seconds |
| `fps`, `resolution` | Output frame rate and dimensions/known label |
| `outline`, `outline_width` | Outline switch and pixel width |
| `shadow`, `shadow_offset` | Shadow switch and pixel offset |
| `auto_fit_font` | Automatic fitting on/off |
| `transition`, `transition_duration` | `fade`, `cut`, `zoom` and seconds |
| `bg_image` | Background image path |
| `encode_preset` | `ultrafast`, `fast`, `medium`, `slow` |
| `hardware_backend` | `auto`, `nvidia`, `intel`, `cpu` |
| `audio` | Audio path or `none` for silence |
| `audio_volume`, `audio_fade_in`, `audio_fade_out` | Audio mix values |

## Soundtrack policy

The row soundtrack policy is: explicit CSV `audio` path → explicit CSV `none` (silence) → Batch fixed soundtrack when selected → random folder cycle when selected → no soundtrack. Selecting **No fallback track** disables the fixed/random fallback. Random assignment shuffles available tracks and cycles without repeats until the folder is exhausted.

## Hardware preference

Auto tries NVIDIA NVENC, then Intel Quick Sync, then CPU/x264, subject to which encoders are compiled into the selected FFmpeg and supported by the installed driver. Rendering/compositing frames remains CPU work; the hardware backend accelerates the final encoding stage. A hardware failure falls back to CPU encoding.
