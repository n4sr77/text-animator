#!/usr/bin/env python3
"""Compatibility launcher for TextAnimator."""
from main import main


if __name__ == "__main__":
    raise SystemExit(main())

