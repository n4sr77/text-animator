[CmdletBinding()]
param(
    [switch]$SkipTests,
    [switch]$RebuildWheelhouse,
    [string]$Wheelhouse = "wheelhouse\windows-py311"
)
$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

$required = @("requirements-windows.lock.txt", "requirements-build-windows.lock.txt")
$locksReady = ($required | ForEach-Object { Test-Path $_ } | Where-Object { -not $_ }).Count -eq 0
$wheelsReady = (Test-Path $Wheelhouse) -and ((Get-ChildItem $Wheelhouse -Filter *.whl -ErrorAction SilentlyContinue | Measure-Object).Count -gt 0)
if ($RebuildWheelhouse -or -not $locksReady -or -not $wheelsReady) {
    & powershell -NoProfile -ExecutionPolicy Bypass -File (Join-Path $PSScriptRoot "prepare_windows.ps1") -Wheelhouse $Wheelhouse
    if ($LASTEXITCODE -ne 0) { throw "Windows wheel preparation failed." }
}

$Venv = Join-Path $PSScriptRoot ".windows-build-venv"
if (-not (Test-Path (Join-Path $Venv "Scripts\python.exe"))) {
    & py -3.11 -m venv $Venv
    if ($LASTEXITCODE -ne 0) { throw "Could not create isolated build environment." }
}
$Py = Join-Path $Venv "Scripts\python.exe"
& $Py -m pip install --no-index --find-links $Wheelhouse --require-hashes `
    -r requirements-windows.lock.txt -r requirements-build-windows.lock.txt
if ($LASTEXITCODE -ne 0) { throw "Could not install the locked Windows wheels." }
& $Py -m pip check
if ($LASTEXITCODE -ne 0) { throw "pip check found incompatible or missing dependencies." }

if (-not $SkipTests) {
    & $Py -m pytest -q
    if ($LASTEXITCODE -ne 0) { throw "Regression tests failed; refusing to package." }
}

& $Py -m PyInstaller --noconfirm --clean TextAnimator.spec
if ($LASTEXITCODE -ne 0) { throw "PyInstaller build failed." }

$Dist = Join-Path $PSScriptRoot "dist\TextAnimator"
Copy-Item README.md, WINDOWS_BUILD_README.md, BATCH_RENDER_SETTINGS.md, PUBLISHING_AUDIT.md, WINDOWS_PACKAGE_STATUS.md, sample_batch.csv `
    -Destination $Dist -Force

# Sanity-check the actual Windows executable in version mode.
$Exe = Join-Path $Dist "TextAnimator.exe"
if (-not (Test-Path $Exe)) { throw "PyInstaller did not produce TextAnimator.exe." }
& $Exe --version
if ($LASTEXITCODE -ne 0) { throw "Packaged executable failed its --version smoke test." }

Write-Host "Windows application staging folder ready: $Dist" -ForegroundColor Green
Write-Host "Next: run .\build_installer.ps1 to create the persistent Windows Setup.exe installer." -ForegroundColor Cyan
