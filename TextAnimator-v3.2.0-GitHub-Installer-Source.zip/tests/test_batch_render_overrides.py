import csv
import threading
from pathlib import Path

from text_animator.batch import BatchRenderer


class FakeRenderer:
    def __init__(self):
        self._cancel = threading.Event()
        self.calls = []
        self.last_encoder_label = "test"

    def render_to_file(self, text, output, **kwargs):
        self.calls.append({"text": text, "output": output, **kwargs})
        Path(output).parent.mkdir(parents=True, exist_ok=True)
        Path(output).write_bytes(b"fake video")
        return output


def test_batch_csv_can_override_every_single_render_control(tmp_path):
    csv_path = tmp_path / "batch.csv"
    with csv_path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=[
            "title", "sentence", "outline_width", "shadow_offset", "auto_fit_font",
            "encode_preset", "hardware_backend", "transition_duration", "audio_volume",
            "audio_fade_in", "audio_fade_out",
        ])
        writer.writeheader()
        writer.writerow({
            "title": "overridden", "sentence": "All controls override",
            "outline_width": "7", "shadow_offset": "9", "auto_fit_font": "false",
            "encode_preset": "slow (better quality)", "hardware_backend": "intel",
            "transition_duration": "0.8", "audio_volume": "0.4",
            "audio_fade_in": "0.5", "audio_fade_out": "0.7",
        })

    batch = BatchRenderer()
    fake = FakeRenderer()
    batch.renderer = fake
    batch.run(
        str(csv_path), str(tmp_path / "out"),
        outline_width=2, shadow_offset=3, auto_fit_font=True,
        encode_preset="fast", hardware_backend="nvidia", transition_duration=0.2,
        audio_volume=0.9, audio_fade_in=0.1, audio_fade_out=0.2,
    )

    call = fake.calls[0]
    assert call["outline_width"] == 7
    assert call["shadow_offset"] == 9
    assert call["auto_fit_font"] is False
    assert call["encode_preset"] == "slow"
    assert call["hardware_backend"] == "intel"
    assert call["transition_duration"] == 0.8
    assert call["audio_volume"] == 0.4
    assert call["audio_fade_in"] == 0.5
    assert call["audio_fade_out"] == 0.7


def test_blank_extended_csv_fields_inherit_batch_defaults(tmp_path):
    csv_path = tmp_path / "batch.csv"
    with csv_path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=[
            "title", "sentence", "outline_width", "shadow_offset", "auto_fit_font",
            "encode_preset", "hardware_backend", "transition_duration", "audio_volume",
            "audio_fade_in", "audio_fade_out",
        ])
        writer.writeheader()
        writer.writerow({"title": "inherit", "sentence": "Use independent defaults"})

    batch = BatchRenderer()
    fake = FakeRenderer()
    batch.renderer = fake
    batch.run(
        str(csv_path), str(tmp_path / "out"),
        outline_width=6, shadow_offset=8, auto_fit_font=False,
        encode_preset="ultrafast", hardware_backend="cpu", transition_duration=0.6,
        audio_volume=0.3, audio_fade_in=1.0, audio_fade_out=1.2,
    )

    call = fake.calls[0]
    assert call["outline_width"] == 6
    assert call["shadow_offset"] == 8
    assert call["auto_fit_font"] is False
    assert call["encode_preset"] == "ultrafast"
    assert call["hardware_backend"] == "cpu"
    assert call["transition_duration"] == 0.6
    assert call["audio_volume"] == 0.3
    assert call["audio_fade_in"] == 1.0
    assert call["audio_fade_out"] == 1.2


def test_csv_clamps_numeric_render_overrides_to_supported_ranges(tmp_path):
    csv_path = tmp_path / "batch.csv"
    with csv_path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=[
            "title", "sentence", "outline_width", "shadow_offset", "transition_duration",
            "audio_volume", "audio_fade_in", "audio_fade_out",
        ])
        writer.writeheader()
        writer.writerow({
            "title": "clamp", "sentence": "Clamp out of range values",
            "outline_width": "99", "shadow_offset": "-5", "transition_duration": "5",
            "audio_volume": "2", "audio_fade_in": "-1", "audio_fade_out": "99",
        })

    batch = BatchRenderer()
    fake = FakeRenderer()
    batch.renderer = fake
    batch.run(str(csv_path), str(tmp_path / "out"))
    call = fake.calls[0]
    assert call["outline_width"] == 16
    assert call["shadow_offset"] == 1
    assert call["transition_duration"] == 1.5
    assert call["audio_volume"] == 1.0
    assert call["audio_fade_in"] == 0.0
    assert call["audio_fade_out"] == 10.0
