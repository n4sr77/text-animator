"""Unit tests: PKCE vectors, state mismatch rejection."""

from __future__ import annotations

import base64
import hashlib
import unittest

from text_animator.social.oauth import (
    generate_pkce,
    generate_state,
    verify_state,
    token_expires_at,
)


class TestPKCE(unittest.TestCase):

    def test_verifier_length(self):
        verifier, _ = generate_pkce()
        # Base64url encoding of 64 random bytes → 86 chars
        self.assertGreaterEqual(len(verifier), 43)
        self.assertLessEqual(len(verifier), 128)

    def test_challenge_is_sha256_of_verifier(self):
        verifier, challenge = generate_pkce()
        digest = hashlib.sha256(verifier.encode("ascii")).digest()
        expected = base64.urlsafe_b64encode(digest).rstrip(b"=").decode("ascii")
        self.assertEqual(challenge, expected)

    def test_verifier_chars(self):
        """Verifier must only contain URL-safe base64 characters."""
        verifier, _ = generate_pkce()
        allowed = set("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_=")
        self.assertTrue(all(c in allowed for c in verifier))

    def test_different_calls_produce_different_values(self):
        v1, c1 = generate_pkce()
        v2, c2 = generate_pkce()
        self.assertNotEqual(v1, v2)
        self.assertNotEqual(c1, c2)


class TestState(unittest.TestCase):

    def test_state_length(self):
        state = generate_state()
        # token_urlsafe(32) → 43 chars
        self.assertGreaterEqual(len(state), 32)

    def test_verify_state_match(self):
        state = generate_state()
        # Should not raise
        verify_state(state, state)

    def test_verify_state_mismatch_raises(self):
        state = generate_state()
        with self.assertRaises(ValueError):
            verify_state(state, "tampered_state_value")

    def test_verify_state_empty_mismatch(self):
        state = generate_state()
        with self.assertRaises(ValueError):
            verify_state(state, "")


class TestTokenExpiresAt(unittest.TestCase):

    def test_expires_at_in_future(self):
        import time
        at = token_expires_at({"expires_in": 3600})
        now = time.time()
        # Should be ~3540 seconds in the future (3600 - 60 buffer)
        self.assertGreater(at, now + 3400)
        self.assertLess(at, now + 3700)

    def test_zero_expires_in_uses_default(self):
        import time
        at = token_expires_at({"expires_in": 0})
        now = time.time()
        # 0 - 60 → negative, but we just check it's computed
        self.assertLess(at, now + 60)

    def test_missing_expires_in(self):
        import time
        at = token_expires_at({})
        now = time.time()
        # Defaults to 3600
        self.assertGreater(at, now + 3400)




class TestLoopbackServer(unittest.TestCase):

    def test_wait_for_redirect_keeps_listening_after_idle_timeout(self):
        import queue
        import time
        from unittest.mock import patch
        import text_animator.social.oauth as oauth_mod

        captured = {}

        def make_handler(result_queue, expected_state):
            captured["queue"] = result_queue
            captured["state"] = expected_state
            return object()

        class FakeServer:
            def __init__(self, address, handler):
                self.server_address = ("127.0.0.1", 54321)
                self.timeout = None
                self.calls = 0

            def handle_request(self):
                self.calls += 1
                time.sleep(0.01)
                if self.calls == 2:
                    captured["queue"].put(oauth_mod.RedirectResult(
                        code="oauth-code", state=captured["state"]
                    ))

            def server_close(self):
                pass

        with patch.object(oauth_mod, "_make_handler", side_effect=make_handler), \
             patch.object(oauth_mod.http.server, "HTTPServer", FakeServer):
            result = oauth_mod.wait_for_redirect("expected-state", timeout=1.0)

        self.assertEqual(result.code, "oauth-code")
        self.assertEqual(result.state, "expected-state")

if __name__ == "__main__":
    unittest.main()
