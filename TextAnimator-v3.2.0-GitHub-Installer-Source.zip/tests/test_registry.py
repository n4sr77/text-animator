"""Unit tests: platform registry discovery."""

from __future__ import annotations

import unittest
from unittest.mock import patch, MagicMock

from text_animator.social.registry import list_platforms, get_capability, load_adapter


class TestRegistryDiscovery(unittest.TestCase):

    def test_list_platforms_returns_all(self):
        caps = list_platforms()
        ids = {c.platform_id for c in caps}
        expected = {"youtube", "tiktok", "instagram", "facebook",
                    "x_twitter", "linkedin", "threads", "pinterest", "vimeo"}
        self.assertEqual(ids, expected)

    def test_get_capability_known(self):
        cap = get_capability("youtube")
        self.assertIsNotNone(cap)
        self.assertEqual(cap.platform_name, "YouTube")
        self.assertTrue(cap.supports_resume)

    def test_get_capability_unknown(self):
        cap = get_capability("nonexistent_platform_xyz")
        self.assertIsNone(cap)

    def test_load_adapter_unknown_raises(self):
        with self.assertRaises(ValueError):
            load_adapter("nonexistent_xyz")

    def test_load_adapter_missing_extras_raises_import_error(self):
        """If extras are not installed, ImportError with helpful message."""
        import importlib
        with patch("importlib.import_module", side_effect=ImportError("no module")):
            with self.assertRaises(ImportError) as ctx:
                load_adapter("youtube")
        self.assertIn("text-animator[social]", str(ctx.exception))

    def test_platform_capabilities_have_required_fields(self):
        for cap in list_platforms():
            self.assertTrue(cap.platform_id)
            self.assertTrue(cap.platform_name)
            self.assertIsInstance(cap.max_concurrent, int)
            self.assertGreaterEqual(cap.max_concurrent, 1)


if __name__ == "__main__":
    unittest.main()
