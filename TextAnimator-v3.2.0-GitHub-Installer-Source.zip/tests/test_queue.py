"""Unit tests: upload queue backoff, cancel, circuit-breaker."""

from __future__ import annotations

import threading
import time
import unittest
from unittest.mock import MagicMock, patch

from text_animator.social.base import UploadRequest, UploadResult
from text_animator.social.errors import AuthError, TransientError
from text_animator.social.queue import UploadQueue, JobStatus, _backoff


class TestBackoff(unittest.TestCase):

    def test_backoff_increases(self):
        d1 = _backoff(1)
        d2 = _backoff(2)
        d3 = _backoff(3)
        # With jitter removed (seed), just check ordering tendency
        # At least d3 mean > d1 mean (2^0 vs 2^2 base)
        self.assertLess(d1 * 0.5, d3)   # loose sanity check

    def test_backoff_bounded(self):
        for attempt in range(1, 20):
            d = _backoff(attempt)
            self.assertGreater(d, 0)
            # max _MAX_DELAY (300) + 25% jitter = 375; we cap at a safe ceiling
            self.assertLessEqual(d, 380)


class TestQueueCancel(unittest.TestCase):

    def _make_request(self, platform="youtube"):
        return UploadRequest(
            file_path="/tmp/fake.mp4",
            platform=platform,
            account_id="acct1",
        )

    def test_cancel_before_start_marks_cancelled(self):
        statuses = []
        q = UploadQueue(status_callback=lambda jid, s, m: statuses.append(s))

        # Mock adapter that never gets called
        with patch("text_animator.social.queue.load_adapter") as mock_load, \
             patch("text_animator.social.queue.TokenStore") as mock_store:

            mock_store.return_value.load.return_value = MagicMock(
                access_token="tok", refresh_token="ref",
                is_expired=MagicMock(return_value=False)
            )
            mock_adapter = MagicMock()
            mock_adapter.max_concurrent.return_value = 1
            mock_load.return_value = mock_adapter

            req = self._make_request()
            job_id = q.enqueue(req)
            q.cancel(job_id)   # cancel before start

            q.start()
            time.sleep(0.5)

        # Either cancelled or the adapter was never called
        # The key assertion: no "done" after cancel
        self.assertNotIn("done", statuses)

    def test_cancel_all(self):
        """cancel_all should set all cancel flags."""
        q = UploadQueue()
        ids = [q.enqueue(self._make_request()) for _ in range(3)]
        q.cancel_all()
        for jid in ids:
            with q._jobs_lock:
                job = q._jobs.get(jid)
            if job:
                self.assertTrue(job.cancel_flag.is_set())


class TestCircuitBreaker(unittest.TestCase):

    def test_circuit_breaker_trips_after_n_auth_failures(self):
        """After _CB_THRESHOLD consecutive AuthErrors, job → needs_reauth."""
        from text_animator.social.queue import _CB_THRESHOLD

        statuses = []

        def _status_cb(jid, status, msg):
            statuses.append(status)

        with patch("text_animator.social.queue.load_adapter") as mock_load, \
             patch("text_animator.social.queue.TokenStore") as mock_store:

            mock_store.return_value.load.return_value = MagicMock(
                access_token="tok", refresh_token="ref",
                is_expired=MagicMock(return_value=False)
            )
            mock_adapter = MagicMock()
            mock_adapter.max_concurrent.return_value = 1
            mock_adapter.upload.side_effect = AuthError("Token revoked", platform="youtube")
            mock_load.return_value = mock_adapter

            q = UploadQueue(status_callback=_status_cb)
            req = UploadRequest(file_path="/tmp/x.mp4", platform="youtube", account_id="u1")
            job_id = q.enqueue(req)

            # Manually bump the failure counter to threshold-1 to speed up test
            cb_key = "youtube:u1"
            with q._af_lock:
                q._auth_failures[cb_key] = _CB_THRESHOLD - 1

            q.start()
            # Give the worker time to run
            time.sleep(1.0)

        self.assertIn("needs_reauth", statuses)


class TestQueueResults(unittest.TestCase):

    def test_results_returns_all_jobs(self):
        q = UploadQueue()
        reqs = [
            UploadRequest(file_path=f"/tmp/{i}.mp4", platform="youtube", account_id="a")
            for i in range(5)
        ]
        ids = [q.enqueue(r) for r in reqs]
        results = q.results()
        self.assertEqual(len(results), 5)
        self.assertEqual({j.job_id for j in results}, set(ids))


if __name__ == "__main__":
    unittest.main()


class TestQueueUploadResultSemantics(unittest.TestCase):

    def _run_single_result(self, result):
        from text_animator.social.queue import QueueJob
        q = UploadQueue()
        req = UploadRequest(file_path="/tmp/video.mp4", platform="tiktok", account_id="acct1")
        job = QueueJob(request=req)
        q._jobs[job.job_id] = job
        adapter = MagicMock()
        adapter.upload.return_value = result
        with patch.object(q, "_refreshed_bundle", return_value=MagicMock()), \
             patch("text_animator.social.queue.load_adapter", return_value=adapter):
            q._process_job(job.job_id)
        return job

    def test_false_result_is_not_marked_done(self):
        result = UploadResult(platform="tiktok", account_id="acct1", file_path="/tmp/video.mp4",
                              success=False, error="TikTok rejected the upload")
        job = self._run_single_result(result)
        self.assertEqual(job.status, JobStatus.ERROR)

    def test_processing_result_is_not_marked_done_or_retried(self):
        result = UploadResult(platform="tiktok", account_id="acct1", file_path="/tmp/video.mp4",
                              success=False, status="processing", media_id="publish-123",
                              error="TikTok accepted the video but it is still processing")
        job = self._run_single_result(result)
        self.assertEqual(job.status, JobStatus.PROCESSING)
        self.assertEqual(job.attempt, 1)

    def test_cancelled_result_is_cancelled(self):
        result = UploadResult(platform="tiktok", account_id="acct1", file_path="/tmp/video.mp4",
                              success=False, status="cancelled", error="cancelled")
        job = self._run_single_result(result)
        self.assertEqual(job.status, JobStatus.CANCELLED)
