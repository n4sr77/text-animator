from pathlib import Path
import tomllib

ROOT = Path(__file__).resolve().parents[1]


def test_moviepy_pillow_dependency_bounds_prevent_known_conflict():
    project = tomllib.loads((ROOT / "pyproject.toml").read_text(encoding="utf-8"))
    dependencies = project["project"]["dependencies"]
    assert any(dep.startswith("moviepy>=2.2.1,<2.3.0") for dep in dependencies)
    assert any(dep.startswith("Pillow>=10.0.0,<12.0.0") for dep in dependencies)
    windows = (ROOT / "requirements-windows.in").read_text(encoding="utf-8")
    assert "Pillow==11.3.0" in windows
    assert "Pillow==12" not in windows


def test_windows_build_is_isolated_and_validates_before_packaging():
    build = (ROOT / "build_windows.ps1").read_text(encoding="utf-8")
    assert ".windows-build-venv" in build
    assert "--no-index" in build
    assert "--require-hashes" in build
    assert "pip check" in build
    assert "pytest -q" in build
    assert "PyInstaller" in build
    assert "TextAnimator.exe" in build


def test_windows_spec_collects_ui_ffmpeg_and_social_runtime():
    spec = (ROOT / "TextAnimator.spec").read_text(encoding="utf-8")
    for package in ("ttkbootstrap", "imageio_ffmpeg", "moviepy", "keyring", "googleapiclient", "tweepy"):
        assert f'"{package}"' in spec
    assert 'name="TextAnimator"' in spec


def test_installer_is_persistent_per_user_and_keeps_user_data_outside_install_dir():
    iss = (ROOT / "installer" / "TextAnimator.iss").read_text(encoding="utf-8")
    assert r"DefaultDirName={localappdata}\Programs\TextAnimator" in iss
    assert "PrivilegesRequired=lowest" in iss
    assert "Uninstallable=yes" in iss
    assert r"{autoprograms}\TextAnimator" in iss
    assert r"{autodesktop}\TextAnimator" in iss
    config = (ROOT / "text_animator" / "config.py").read_text(encoding="utf-8")
    assert 'Path.home() / ".textanimator_config.json"' in config


def test_github_workflow_publishes_a_direct_setup_exe_not_a_portable_zip():
    workflow = (ROOT / ".github" / "workflows" / "build-windows.yml").read_text(encoding="utf-8")
    assert "runs-on: windows-latest" in workflow
    assert "build_installer.ps1" in workflow
    assert "TextAnimator-v3.2.0-Setup.exe" in workflow
    assert "softprops/action-gh-release@v3" in workflow
    assert "contents: write" in workflow


def test_installer_build_script_requires_compiled_application():
    script = (ROOT / "build_installer.ps1").read_text(encoding="utf-8")
    assert '"dist\\TextAnimator"' in script
    assert '"TextAnimator.exe"' in script
    assert "Inno Setup compilation failed" in script
    assert "TextAnimator-v3.2.0-Setup.exe" in script
