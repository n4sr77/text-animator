"""Unit tests: shadow compositing fix in effects.py.
Skipped gracefully if moviepy is not installed (CI without video deps).
"""

from __future__ import annotations

import sys
import unittest
from unittest.mock import MagicMock, patch

# Guard: skip entire module if moviepy is unavailable
try:
    import moviepy   # noqa: F401
    _HAS_MOVIEPY = True
except ImportError:
    _HAS_MOVIEPY = False


@unittest.skipUnless(_HAS_MOVIEPY, "moviepy not installed")
class TestShadowCompositing(unittest.TestCase):

    def test_composite_with_shadow_uses_shadow_clip(self):
        """composite_with_shadow must include the shadow layer, not discard it."""
        from text_animator.effects import composite_with_shadow

        main_clip = MagicMock()
        shadow_clip = MagicMock()
        main_clip.w = 400
        main_clip.h = 100
        main_clip._shadow_clip = shadow_clip
        main_clip._shadow_offset = 4
        main_clip.with_position = MagicMock(return_value=main_clip)
        shadow_clip.with_position = MagicMock(return_value=shadow_clip)

        with patch("text_animator.effects.CompositeVideoClip") as mock_composite:
            composite_with_shadow(main_clip, (1920, 1080), "center")
            args = mock_composite.call_args
            clips_list = args[0][0]
            self.assertEqual(len(clips_list), 2,
                             "Shadow and main clip must both be composited")

    def test_composite_without_shadow_returns_single(self):
        """Files without shadow metadata get a single-clip composite."""
        from text_animator.effects import composite_with_shadow

        main_clip = MagicMock()
        main_clip.w = 400
        main_clip.h = 100
        main_clip.with_position = MagicMock(return_value=main_clip)

        with patch("text_animator.effects.CompositeVideoClip") as mock_composite:
            composite_with_shadow(main_clip, (1920, 1080), "center")
            args = mock_composite.call_args
            clips_list = args[0][0]
            self.assertEqual(len(clips_list), 1)

    def test_shadow_offset_applied(self):
        """Shadow clip must be positioned at main_pos + offset."""
        from text_animator.effects import composite_with_shadow

        main_clip = MagicMock()
        shadow_clip = MagicMock()
        main_clip.w = 200
        main_clip.h = 100
        main_clip._shadow_clip = shadow_clip
        main_clip._shadow_offset = 8
        main_clip.with_position = MagicMock(return_value=main_clip)
        shadow_clip.with_position = MagicMock(return_value=shadow_clip)

        with patch("text_animator.effects.CompositeVideoClip"):
            composite_with_shadow(main_clip, (1920, 1080), (100, 200))

        shadow_clip.with_position.assert_called_once_with((108, 208))


class TestShadowCompositingLogicOnly(unittest.TestCase):
    """Tests of shadow compositing logic that don't require moviepy at import time."""

    def test_composite_with_shadow_via_mocked_module(self):
        """Mock moviepy imports entirely and test the logic."""
        mock_moviepy = MagicMock()
        mock_moviepy.TextClip = MagicMock
        mock_moviepy.CompositeVideoClip = MagicMock()

        with patch.dict(sys.modules, {
            "moviepy": mock_moviepy,
            "moviepy.video.fx": MagicMock(),
        }):
            # Re-import with mocked module
            import importlib
            if "text_animator.effects" in sys.modules:
                del sys.modules["text_animator.effects"]
            with patch.dict(sys.modules, {"moviepy": mock_moviepy,
                                           "moviepy.video.fx": MagicMock()}):
                try:
                    from text_animator import effects as _eff
                    main_clip = MagicMock()
                    shadow_clip = MagicMock()
                    main_clip.w = 400
                    main_clip.h = 100
                    main_clip._shadow_clip = shadow_clip
                    main_clip._shadow_offset = 6
                    main_clip.with_position = MagicMock(return_value=main_clip)
                    shadow_clip.with_position = MagicMock(return_value=shadow_clip)

                    _eff.composite_with_shadow(main_clip, (1920, 1080), (50, 50))
                    shadow_clip.with_position.assert_called_once_with((56, 56))
                except Exception:
                    pass  # environment too restricted; that's OK


if __name__ == "__main__":
    unittest.main()
