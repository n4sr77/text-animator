"""Integration test: mocked YouTube OAuth + mocked resumable upload.
Skipped gracefully if googleapiclient is not installed.
"""

from __future__ import annotations

import threading
import unittest
from unittest.mock import MagicMock, patch

from text_animator.social.base import TokenBundle, UploadRequest

try:
    import googleapiclient  # noqa: F401
    _HAS_GOOGLE = True
except ImportError:
    _HAS_GOOGLE = False


def _make_bundle():
    return TokenBundle(
        platform="youtube", account_id="UC_test",
        access_token="fake_access_token", refresh_token="fake_refresh_token",
        expires_at=9_999_999_999.0,
    )


def _make_request(file_path="/tmp/test_video.mp4"):
    return UploadRequest(
        file_path=file_path, platform="youtube", account_id="UC_test",
        title="Test Video", description="Integration test",
        tags=["test"], visibility="private",
    )


class TestYouTubeAdapterMocked(unittest.TestCase):


    def test_desktop_oauth_uses_installed_client_pkce(self):
        import sys

        calls = []
        class FakeFlow:
            def __init__(self):
                self.code_verifier = "generated-pkce-verifier"
                self.credentials = MagicMock(token="access", refresh_token="refresh", id_token="id")

            @classmethod
            def from_client_config(cls, config, **kwargs):
                calls.append((config, kwargs))
                return cls()

            def authorization_url(self, **kwargs):
                return "https://accounts.google.com/authorize", kwargs.get("state")

            def fetch_token(self, **kwargs):
                self.fetch_args = kwargs

        fake_flow_module = MagicMock(Flow=FakeFlow)
        with patch.dict(sys.modules, {"google_auth_oauthlib": MagicMock(),
                                      "google_auth_oauthlib.flow": fake_flow_module}):
            from text_animator.social.platforms.youtube import YouTubeAdapter
            adapter = YouTubeAdapter(client_id="client-id", client_secret="client-secret")
            adapter.auth_url("state-1", "http://127.0.0.1:1234/callback")
            bundle = adapter.exchange_code("code-1", "state-1", "http://127.0.0.1:1234/callback")

        self.assertIn("installed", calls[0][0])
        self.assertTrue(calls[0][1]["autogenerate_code_verifier"])
        self.assertEqual(calls[1][1]["code_verifier"], "generated-pkce-verifier")
        self.assertEqual(bundle.access_token, "access")



    def test_api_error_reason_extracts_quota_and_rate_limit_reasons(self):
        from text_animator.social.platforms.youtube import _api_error_reason
        class FakeError:
            content = b'{"error":{"errors":[{"reason":"quotaExceeded"}]}}'
        self.assertEqual(_api_error_reason(FakeError()), "quotaExceeded")

    def test_validate_rejects_overlong_title_and_description(self):
        from text_animator.social.platforms.youtube import YouTubeAdapter
        adapter = YouTubeAdapter(client_id="cid", client_secret="secret")
        request = _make_request()
        request.title = "T" * 101
        request.description = "é" * 2501  # 5,002 UTF-8 bytes
        with patch("text_animator.social.platforms.youtube.validate_file", return_value=[]):
            errors = adapter.validate(request)
        self.assertTrue(any("100 characters" in error for error in errors))
        self.assertTrue(any("5,000 UTF-8 bytes" in error for error in errors))

    def test_fetch_account_always(self):
        """fetch_account returns populated AccountInfo (fully mocked, no extras needed)."""
        mock_svc = MagicMock()
        mock_svc.channels.return_value.list.return_value.execute.return_value = {
            "items": [{
                "id": "UC_test",
                "snippet": {
                    "title": "Test Channel",
                    "customUrl": "@testchannel",
                    "thumbnails": {"default": {"url": "https://example.com/av.jpg"}},
                },
            }]
        }

        # Patch the google imports inside the module
        google_mocks = {
            "google": MagicMock(),
            "google.oauth2": MagicMock(),
            "google.oauth2.credentials": MagicMock(),
            "google.auth": MagicMock(),
            "google.auth.transport": MagicMock(),
            "google.auth.transport.requests": MagicMock(),
            "googleapiclient": MagicMock(),
            "googleapiclient.discovery": MagicMock(),
            "googleapiclient.http": MagicMock(),
            "googleapiclient.errors": MagicMock(),
            "google_auth_oauthlib": MagicMock(),
            "google_auth_oauthlib.flow": MagicMock(),
        }
        import sys
        with patch.dict(sys.modules, google_mocks):
            if "text_animator.social.platforms.youtube" in sys.modules:
                del sys.modules["text_animator.social.platforms.youtube"]
            from text_animator.social.platforms.youtube import YouTubeAdapter
            adapter = YouTubeAdapter(client_id="cid", client_secret="csec")
            with patch.object(adapter, "_build_service", return_value=mock_svc):
                info = adapter.fetch_account(_make_bundle())

        self.assertEqual(info.account_id, "UC_test")
        self.assertEqual(info.display_name, "Test Channel")

    def test_media_spec(self):
        """media_spec() returns valid MediaSpec with correct platform."""
        import sys
        google_mocks = {k: MagicMock() for k in [
            "google", "google.oauth2", "google.oauth2.credentials",
            "google.auth", "google.auth.transport", "google.auth.transport.requests",
            "googleapiclient", "googleapiclient.discovery",
            "googleapiclient.http", "googleapiclient.errors",
            "google_auth_oauthlib", "google_auth_oauthlib.flow",
        ]}
        with patch.dict(sys.modules, google_mocks):
            if "text_animator.social.platforms.youtube" in sys.modules:
                del sys.modules["text_animator.social.platforms.youtube"]
            from text_animator.social.platforms.youtube import YouTubeAdapter
            adapter = YouTubeAdapter()
            spec = adapter.media_spec()

        self.assertEqual(spec.platform, "youtube")
        self.assertGreater(spec.max_duration_s, 3600)
        self.assertIn("h264", spec.allowed_codecs)
        self.assertTrue(adapter.supports_resume())

    def test_cancel_mid_upload_mocked(self):
        """Cancel flag prevents upload from completing (fully mocked)."""
        import sys

        mock_media_cls = MagicMock()
        mock_insert_req = MagicMock()
        mock_svc = MagicMock()
        mock_svc.videos.return_value.insert.return_value = mock_insert_req

        # next_chunk returns a response immediately
        mock_insert_req.next_chunk.return_value = (None, {"id": "vid999"})

        google_mocks = {k: MagicMock() for k in [
            "google", "google.oauth2", "google.oauth2.credentials",
            "google.auth", "google.auth.transport", "google.auth.transport.requests",
            "googleapiclient", "googleapiclient.discovery",
            "googleapiclient.errors",
        ]}
        mock_http = MagicMock()
        mock_http.MediaFileUpload = mock_media_cls
        google_mocks["googleapiclient.http"] = mock_http
        google_mocks.update({
            "google_auth_oauthlib": MagicMock(),
            "google_auth_oauthlib.flow": MagicMock(),
        })

        with patch.dict(sys.modules, google_mocks):
            if "text_animator.social.platforms.youtube" in sys.modules:
                del sys.modules["text_animator.social.platforms.youtube"]
            from text_animator.social.platforms.youtube import YouTubeAdapter
            adapter = YouTubeAdapter(client_id="cid", client_secret="csec")

            cancel_flag = threading.Event()
            cancel_flag.set()

            with patch.object(adapter, "_build_service", return_value=mock_svc), \
                 patch("text_animator.social.platforms.youtube.validate_file", return_value=[]), \
                 patch("os.path.getsize", return_value=10 * 1024 * 1024), \
                 patch("os.path.isfile", return_value=True):
                result = adapter.upload(_make_request(), _make_bundle(),
                                        cancel_flag=cancel_flag)

        self.assertFalse(result.success)
        self.assertEqual(result.error, "cancelled")


if __name__ == "__main__":
    unittest.main()
