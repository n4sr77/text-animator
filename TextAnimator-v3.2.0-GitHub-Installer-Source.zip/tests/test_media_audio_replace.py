from pathlib import Path
from unittest.mock import patch

from text_animator.media_tools import MediaProcessor


class DoneProcess:
    returncode = 0
    def poll(self):
        return 0


def test_media_ffmpeg_maps_replacement_audio_and_trims_to_video(tmp_path):
    source = tmp_path / "source.mp4"
    replacement = tmp_path / "music.mp3"
    output = tmp_path / "out.mp4"
    source.write_bytes(b"video")
    replacement.write_bytes(b"audio")
    processor = MediaProcessor()
    seen = {}

    def fake_popen(cmd, **kwargs):
        seen["cmd"] = cmd
        return DoneProcess()

    with patch("text_animator.media_tools.ffmpeg_binary", return_value="/usr/bin/ffmpeg"), \
         patch("text_animator.hardware.available_encoders", return_value=frozenset({"libx264"})), \
         patch("text_animator.media_tools.subprocess.Popen", side_effect=fake_popen):
        processor._process_ffmpeg(
            source, output, "video", None, None, "Fit", "None", 0, 0, 0,
            0, 0, "0°", 30, 1.0, 1.0, False, 20,
            replacement_audio_path=str(replacement), hardware_backend="cpu",
        )

    command = seen["cmd"]
    assert command[command.index("-stream_loop") + 1] == "-1"
    assert "1:a:0" in command
    assert "-shortest" in command
    assert str(replacement) in command


def test_media_random_audio_tracks_are_allocated_to_queued_videos(tmp_path):
    source_dir = tmp_path / "videos"
    audio_dir = tmp_path / "audios"
    source_dir.mkdir()
    audio_dir.mkdir()
    videos = [source_dir / "a.mp4", source_dir / "b.mp4"]
    tracks = [audio_dir / "one.mp3", audio_dir / "two.wav"]
    for item in videos + tracks:
        item.write_bytes(b"data")

    processor = MediaProcessor()
    captured = []
    def fake_process_one(source, output, **kwargs):
        captured.append((source, kwargs.get("replacement_audio_path")))
        return output

    with patch.object(processor, "process_one", side_effect=fake_process_one):
        processor.process_many(
            [str(p) for p in videos], str(tmp_path / "out"),
            audio_replace_mode="random", audio_folder=str(audio_dir),
        )

    selected = [audio for _, audio in captured]
    assert len(selected) == 2
    assert len(set(selected)) == 2
    assert set(selected) == {str(p.resolve()) for p in tracks}
    assert len(processor.last_audio_selections) == 2
