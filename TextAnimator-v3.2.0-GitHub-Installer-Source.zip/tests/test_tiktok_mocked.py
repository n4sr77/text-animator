"""Mocked TikTok desktop OAuth and Content Posting API tests."""

from __future__ import annotations

import hashlib
import tempfile
import unittest
from pathlib import Path
from unittest.mock import MagicMock, patch
from urllib.parse import parse_qs, urlparse

from text_animator.social.base import TokenBundle, UploadRequest
from text_animator.social.platforms.tiktok import TikTokAdapter, _chunk_layout, _build_caption


class FakeResponse:
    def __init__(self, payload, status_code=200, text=""):
        self._payload = payload
        self.status_code = status_code
        self.text = text

    def json(self):
        return self._payload


class TestTikTokDesktopOAuth(unittest.TestCase):

    def test_auth_url_contains_desktop_pkce_and_direct_publish_scope(self):
        adapter = TikTokAdapter(client_key="client-key", client_secret="client-secret")
        url = adapter.auth_url("random-state", "http://127.0.0.1:12345/callback")
        params = parse_qs(urlparse(url).query)
        self.assertEqual(params["client_key"], ["client-key"])
        self.assertEqual(params["state"], ["random-state"])
        self.assertEqual(params["scope"], ["user.info.basic,video.publish"])
        self.assertEqual(params["code_challenge_method"], ["S256"])
        verifier = adapter._code_verifier
        expected = hashlib.sha256(verifier.encode("ascii")).hexdigest()
        self.assertEqual(params["code_challenge"], [expected])

    def test_exchange_sends_pkce_verifier(self):
        adapter = TikTokAdapter(client_key="client-key", client_secret="client-secret")
        adapter.auth_url("state", "http://127.0.0.1:12345/callback")
        verifier = adapter._code_verifier
        response = FakeResponse({"data": {
            "open_id": "open-id", "access_token": "access", "refresh_token": "refresh",
            "expires_in": 86400, "scope": "user.info.basic,video.publish",
        }})
        with patch("text_animator.social.platforms.tiktok.requests.post", return_value=response) as post:
            bundle = adapter.exchange_code("auth-code", "state", "http://127.0.0.1:12345/callback")
        self.assertEqual(post.call_args.kwargs["data"]["code_verifier"], verifier)
        self.assertEqual(bundle.account_id, "open-id")
        self.assertEqual(bundle.access_token, "access")
        self.assertEqual(adapter._code_verifier, "")


class TestTikTokChunking(unittest.TestCase):

    def test_small_file_uses_one_exact_chunk(self):
        self.assertEqual(_chunk_layout(4_000_000), (4_000_000, 1))

    def test_files_up_to_64mb_use_one_chunk(self):
        self.assertEqual(_chunk_layout(64_000_000), (64_000_000, 1))

    def test_remainder_is_absorbed_into_final_chunk(self):
        # A 50 MB file is legal as one 50 MB chunk. For >64 MB, split
        # into chunks and absorb the remainder into the final chunk.
        self.assertEqual(_chunk_layout(50_000_123), (50_000_123, 1))
        self.assertEqual(_chunk_layout(65_000_001), (10_000_000, 6))


class TestTikTokCaption(unittest.TestCase):

    def test_caption_combines_title_description_and_hashtags(self):
        request = UploadRequest(
            file_path="clip.mp4", platform="tiktok", account_id="open-id",
            title="Main title", description="Extra context", tags=["animation", "#motion"],
        )
        self.assertEqual(_build_caption(request), "Main title\nExtra context\n#animation #motion")

    def test_caption_rejects_oversized_unicode_without_truncating(self):
        request = UploadRequest(
            file_path="clip.mp4", platform="tiktok", account_id="open-id",
            title="😀" * 1101,
        )
        from text_animator.social.errors import ValidationError
        with self.assertRaises(ValidationError):
            _build_caption(request)


class TestTikTokUpload(unittest.TestCase):

    def test_upload_queries_creator_uploads_and_confirms_publish(self):
        adapter = TikTokAdapter(client_key="client-key", client_secret="client-secret")
        bundle = TokenBundle(platform="tiktok", account_id="open-id", access_token="access")
        with tempfile.NamedTemporaryFile(suffix=".mp4", delete=False) as handle:
            handle.write(b"fake-video-data")
            path = handle.name
        self.addCleanup(lambda: Path(path).unlink(missing_ok=True))

        creator_response = FakeResponse({"data": {
            "creator_username": "sample.creator",
            "privacy_level_options": ["SELF_ONLY"],
            "max_video_post_duration_sec": 300,
            "duet_disabled": False,
            "comment_disabled": False,
            "stitch_disabled": False,
        }, "error": {"code": "ok", "message": ""}})
        init_response = FakeResponse({"data": {
            "publish_id": "publish-123", "upload_url": "https://upload.example/video?token=secret"
        }, "error": {"code": "ok", "message": ""}})
        status_response = FakeResponse({"data": {
            "status": "PUBLISH_COMPLETE", "publicaly_available_post_id": ["987654321"]
        }, "error": {"code": "ok", "message": ""}})
        request = UploadRequest(
            file_path=path, platform="tiktok", account_id="open-id",
            title="Test caption", description="Caption details", tags=["animation"],
            visibility="private",
            extra={"privacy_level": "SELF_ONLY", "brand_content_toggle": True, "is_aigc": True},
        )

        with patch("text_animator.social.platforms.tiktok.validate_file", return_value=[]), \
             patch("text_animator.social.validator.probe", return_value={"duration": 10.0}), \
             patch("text_animator.social.platforms.tiktok.requests.post",
                   side_effect=[creator_response, init_response, status_response]) as post, \
             patch("text_animator.social.platforms.tiktok.requests.put",
                   return_value=FakeResponse({}, status_code=201)) as put:
            result = adapter.upload(request, bundle)

        self.assertTrue(result.success)
        self.assertEqual(result.status, "published")
        self.assertEqual(result.media_id, "publish-123")
        self.assertEqual(result.post_url, "https://www.tiktok.com/@sample.creator/video/987654321")
        self.assertEqual(post.call_count, 3)  # creator info → init → status
        self.assertEqual(put.call_count, 1)
        post_info = post.call_args_list[1].kwargs["json"]["post_info"]
        self.assertEqual(post_info["privacy_level"], "SELF_ONLY")
        self.assertEqual(post_info["title"], "Test caption\nCaption details\n#animation")
        self.assertTrue(post_info["brand_content_toggle"])
        self.assertTrue(post_info["is_aigc"])
        self.assertEqual(put.call_args.kwargs["headers"]["Content-Range"], "bytes 0-14/15")


    def test_cancel_after_publish_id_does_not_claim_post_was_cancelled(self):
        import threading
        adapter = TikTokAdapter(client_key="client-key", client_secret="client-secret")
        bundle = TokenBundle(platform="tiktok", account_id="open-id", access_token="access")
        cancel = threading.Event()
        cancel.set()
        status, data = adapter._poll_status(bundle, "publish-123", None, cancel)
        self.assertEqual(status, "PROCESSING")
        self.assertTrue(data["local_cancel_requested"])

    def test_transient_status_error_does_not_trigger_duplicate_upload(self):
        from text_animator.social.errors import TransientError
        adapter = TikTokAdapter(client_key="client-key", client_secret="client-secret")
        bundle = TokenBundle(platform="tiktok", account_id="open-id", access_token="access")
        with patch.object(adapter, "fetch_publish_status", side_effect=TransientError("timeout")):
            status, data = adapter._poll_status(bundle, "publish-123", None, None)
        self.assertEqual(status, "PROCESSING_UNCONFIRMED")
        self.assertIn("timeout", data["status_check_error"])

    def test_unavailable_privacy_level_stops_before_upload_init(self):
        adapter = TikTokAdapter(client_key="client-key", client_secret="client-secret")
        bundle = TokenBundle(platform="tiktok", account_id="open-id", access_token="access")
        with tempfile.NamedTemporaryFile(suffix=".mp4", delete=False) as handle:
            handle.write(b"fake-video-data")
            path = handle.name
        self.addCleanup(lambda: Path(path).unlink(missing_ok=True))
        creator_response = FakeResponse({"data": {"privacy_level_options": ["SELF_ONLY"]},
                                          "error": {"code": "ok"}})
        request = UploadRequest(file_path=path, platform="tiktok", account_id="open-id",
                                visibility="public")
        with patch("text_animator.social.platforms.tiktok.validate_file", return_value=[]), \
             patch("text_animator.social.platforms.tiktok.requests.post",
                   return_value=creator_response) as post:
            from text_animator.social.errors import ValidationError
            with self.assertRaises(ValidationError):
                adapter.upload(request, bundle)
        self.assertEqual(post.call_count, 1)


if __name__ == "__main__":
    unittest.main()
