from types import SimpleNamespace

from text_animator.config import RESOLUTIONS
from text_animator.gui import TextAnimatorApp


class Var:
    def __init__(self, value):
        self.value = value

    def get(self):
        return self.value


def test_batch_gather_uses_only_batch_variables_and_preserves_single_isolation():
    fake = SimpleNamespace(
        batch_preset_var=Var("typewriter"),
        batch_color_var=Var("black_on_white"),
        batch_font_var=Var("Batch Font"),
        batch_font_size_var=Var(72),
        batch_word_duration_var=Var(0.6),
        batch_gap_var=Var(0.04),
        batch_end_hold_var=Var(1.8),
        batch_fps_var=Var(24),
        batch_resolution_var=Var("1080x1920 (vertical)"),
        batch_outline_var=Var(True),
        batch_shadow_var=Var(False),
        batch_outline_width_var=Var(5),
        batch_shadow_offset_var=Var(7),
        batch_autofit_var=Var(False),
        batch_bg_var=Var(""),
        batch_encode_var=Var("slow (better quality)"),
        batch_hardware_var=Var("Intel Quick Sync"),
        batch_hardware_label_to_key={"Intel Quick Sync": "intel"},
        batch_transition_var=Var("Zoom through"),
        batch_transition_label_to_key={"Zoom through": "zoom"},
        batch_transition_duration_var=Var(0.45),
        batch_audio_volume_var=Var(0.55),
        batch_audio_fade_in_var=Var(0.3),
        batch_audio_fade_out_var=Var(0.4),
    )
    fake._batch_render_settings_payload = lambda: TextAnimatorApp._batch_render_settings_payload(fake)

    params = TextAnimatorApp._gather_batch_params(fake)
    assert params["preset_name"] == "typewriter"
    assert params["size"] == RESOLUTIONS["1080x1920 (vertical)"]
    assert params["font_name_or_path"] == "Batch Font"
    assert params["font_size"] == 72
    assert params["hardware_backend"] == "intel"
    assert params["transition"] == "zoom"
    assert params["audio_path"] is None
    assert params["audio_volume"] == 0.55
