"""Unit tests: TokenStore round-trip (plaintext fallback, no keyring needed)."""

from __future__ import annotations

import json
import os
import stat
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from text_animator.social.base import TokenBundle


class TestTokenStoreRoundTrip(unittest.TestCase):

    def setUp(self):
        self.tmp_dir = tempfile.mkdtemp()
        self.cred_file = Path(self.tmp_dir) / "credentials.json"
        self.account_index = Path(self.tmp_dir) / "connected_accounts.json"

    def _make_store(self):
        """Return a TokenStore wired to our temp file."""
        import text_animator.social.credentials as creds_mod
        # Patch paths and keyring availability
        with patch.object(creds_mod, "_CRED_FILE", self.cred_file), \
             patch.object(creds_mod, "_CRED_DIR", Path(self.tmp_dir)), \
             patch.object(creds_mod, "_ACCOUNT_INDEX_FILE", self.account_index), \
             patch.object(creds_mod, "_keyring_available", return_value=False):
            from text_animator.social.credentials import TokenStore
            return TokenStore(), creds_mod

    def test_save_and_load_round_trip(self):
        store, creds_mod = self._make_store()
        bundle = TokenBundle(
            platform="youtube",
            account_id="UC12345",
            access_token="at_secret",
            refresh_token="rt_secret",
            expires_at=9_999_999_999.0,
        )
        import text_animator.social.credentials as creds_mod2
        with patch.object(creds_mod2, "_CRED_FILE", self.cred_file), \
             patch.object(creds_mod2, "_CRED_DIR", Path(self.tmp_dir)), \
             patch.object(creds_mod2, "_ACCOUNT_INDEX_FILE", self.account_index), \
             patch.object(creds_mod2, "_keyring_available", return_value=False):
            from text_animator.social.credentials import TokenStore as TS2
            s2 = TS2()
            s2.save(bundle)
            loaded = s2.load("youtube", "UC12345")

        self.assertIsNotNone(loaded)
        self.assertEqual(loaded.platform, "youtube")
        self.assertEqual(loaded.account_id, "UC12345")
        self.assertEqual(loaded.access_token, "at_secret")
        self.assertEqual(loaded.refresh_token, "rt_secret")
        self.assertAlmostEqual(loaded.expires_at, 9_999_999_999.0, places=0)

    def test_repr_redacts_secrets(self):
        bundle = TokenBundle(
            platform="tiktok", account_id="user1",
            access_token="super_secret", refresh_token="refresh_secret",
        )
        r = repr(bundle)
        self.assertIn("***", r)
        self.assertNotIn("super_secret", r)
        self.assertNotIn("refresh_secret", r)

    def test_load_missing_returns_none(self):
        import text_animator.social.credentials as creds_mod2
        with patch.object(creds_mod2, "_CRED_FILE", self.cred_file), \
             patch.object(creds_mod2, "_CRED_DIR", Path(self.tmp_dir)), \
             patch.object(creds_mod2, "_ACCOUNT_INDEX_FILE", self.account_index), \
             patch.object(creds_mod2, "_keyring_available", return_value=False):
            from text_animator.social.credentials import TokenStore as TS3
            s3 = TS3()
            result = s3.load("youtube", "nonexistent")
        self.assertIsNone(result)

    def test_delete(self):
        import text_animator.social.credentials as creds_mod2
        with patch.object(creds_mod2, "_CRED_FILE", self.cred_file), \
             patch.object(creds_mod2, "_CRED_DIR", Path(self.tmp_dir)), \
             patch.object(creds_mod2, "_ACCOUNT_INDEX_FILE", self.account_index), \
             patch.object(creds_mod2, "_keyring_available", return_value=False):
            from text_animator.social.credentials import TokenStore as TS4
            s4 = TS4()
            bundle = TokenBundle(platform="vimeo", account_id="v42",
                                 access_token="tok", refresh_token="ref")
            s4.save(bundle)
            self.assertIsNotNone(s4.load("vimeo", "v42"))
            s4.delete("vimeo", "v42")
            self.assertIsNone(s4.load("vimeo", "v42"))


    def test_account_index_lists_plaintext_saved_accounts(self):
        import text_animator.social.credentials as creds_mod
        with patch.object(creds_mod, "_CRED_FILE", self.cred_file), \
             patch.object(creds_mod, "_CRED_DIR", Path(self.tmp_dir)), \
             patch.object(creds_mod, "_ACCOUNT_INDEX_FILE", self.account_index), \
             patch.object(creds_mod, "_keyring_available", return_value=False):
            from text_animator.social.credentials import TokenStore
            store = TokenStore()
            store.save(TokenBundle(platform="youtube", account_id="channel-1", access_token="a"))
            self.assertIn(("youtube", "channel-1"), store.list_accounts())

    def test_file_permissions(self):
        import text_animator.social.credentials as creds_mod2
        with patch.object(creds_mod2, "_CRED_FILE", self.cred_file), \
             patch.object(creds_mod2, "_CRED_DIR", Path(self.tmp_dir)), \
             patch.object(creds_mod2, "_ACCOUNT_INDEX_FILE", self.account_index), \
             patch.object(creds_mod2, "_keyring_available", return_value=False):
            from text_animator.social.credentials import TokenStore as TS5
            s5 = TS5()
            bundle = TokenBundle(platform="linkedin", account_id="li1",
                                 access_token="tok", refresh_token="ref")
            s5.save(bundle)

        if os.name != "nt":   # chmod not meaningful on Windows
            mode = oct(stat.S_IMODE(os.stat(self.cred_file).st_mode))
            self.assertIn(mode, ("0o600", "0o400"))  # owner-only

    def tearDown(self):
        import shutil
        shutil.rmtree(self.tmp_dir, ignore_errors=True)


if __name__ == "__main__":
    unittest.main()


class TestClientCredentialStore(unittest.TestCase):

    def setUp(self):
        self.tmp_dir = tempfile.mkdtemp()
        self.client_file = Path(self.tmp_dir) / "client_credentials.json"
        self.account_index = Path(self.tmp_dir) / "connected_accounts.json"

    def _store(self):
        import text_animator.social.credentials as creds_mod
        from text_animator.social.credentials import ClientCredentialStore
        patches = [
            patch.object(creds_mod, "_CRED_DIR", Path(self.tmp_dir)),
            patch.object(creds_mod, "_CLIENT_CONFIG_FILE", self.client_file),
            patch.object(creds_mod, "_ACCOUNT_INDEX_FILE", self.account_index),
            patch.object(creds_mod, "_keyring_available", return_value=False),
        ]
        for item in patches:
            item.start()
            self.addCleanup(item.stop)
        return ClientCredentialStore()

    def test_save_and_get_client_credentials(self):
        store = self._store()
        store.save("youtube", {"client_id": "abc.apps.googleusercontent.com",
                                "client_secret": "top-secret"})
        loaded = store.get("youtube", include_environment=False)
        self.assertEqual(loaded["client_id"], "abc.apps.googleusercontent.com")
        self.assertEqual(loaded["client_secret"], "top-secret")

    def test_client_credentials_file_is_owner_only(self):
        store = self._store()
        store.save("tiktok", {"client_key": "key", "client_secret": "secret"})
        if os.name != "nt":
            mode = stat.S_IMODE(os.stat(self.client_file).st_mode)
            self.assertEqual(mode, 0o600)

    def test_delete_client_credentials(self):
        store = self._store()
        store.save("tiktok", {"client_key": "key", "client_secret": "secret"})
        store.delete("tiktok")
        self.assertEqual(store.get("tiktok", include_environment=False), {})

    def tearDown(self):
        import shutil
        shutil.rmtree(self.tmp_dir, ignore_errors=True)
