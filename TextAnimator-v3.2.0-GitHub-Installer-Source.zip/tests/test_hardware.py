from unittest.mock import patch

from text_animator import hardware


def test_encoder_plan_prefers_nvidia_then_qsv_then_cpu():
    encoders = frozenset({"h264_nvenc", "h264_qsv", "libx264"})
    with patch.object(hardware, "available_encoders", return_value=encoders):
        assert [e.key for e in hardware.encoder_plan("auto", "mock-ffmpeg")] == ["nvenc", "qsv", "cpu"]
        assert [e.key for e in hardware.encoder_plan("intel", "mock-ffmpeg")] == ["qsv", "nvenc", "cpu"]
        assert [e.key for e in hardware.encoder_plan("cpu", "mock-ffmpeg")] == ["cpu"]


def test_encoder_plan_falls_back_when_hardware_encoders_missing():
    with patch.object(hardware, "available_encoders", return_value=frozenset({"libx264"})):
        assert [e.codec for e in hardware.encoder_plan("auto", "mock-ffmpeg")] == ["libx264"]


def test_encoder_presets_are_backend_compatible():
    assert hardware.encoder_preset(hardware.ENCODERS["nvenc"], "ultrafast") == "fast"
    assert hardware.encoder_preset(hardware.ENCODERS["qsv"], "fast") == "faster"
    assert hardware.encoder_preset(hardware.ENCODERS["cpu"], "slow") == "slow"
