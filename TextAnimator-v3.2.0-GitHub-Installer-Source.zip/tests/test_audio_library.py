from pathlib import Path

from text_animator.audio_library import RandomAudioPool, discover_audio_files


def test_discover_audio_files_filters_extensions_and_sorts(tmp_path):
    (tmp_path / "z.mp3").write_bytes(b"x")
    (tmp_path / "a.wav").write_bytes(b"x")
    (tmp_path / "ignore.txt").write_text("x")
    nested = tmp_path / "nested"
    nested.mkdir()
    (nested / "b.flac").write_bytes(b"x")

    found = discover_audio_files(tmp_path)
    assert [Path(p).name for p in found] == ["a.wav", "b.flac", "z.mp3"]


def test_random_audio_pool_uses_each_track_once_before_reshuffle(tmp_path):
    paths = []
    for name in ("one.mp3", "two.wav", "three.flac"):
        path = tmp_path / name
        path.write_bytes(b"x")
        paths.append(str(path.resolve()))

    pool = RandomAudioPool(tmp_path, seed=42)
    first_cycle = [pool.next() for _ in range(3)]
    second_cycle = [pool.next() for _ in range(3)]

    assert set(first_cycle) == set(paths)
    assert set(second_cycle) == set(paths)
    assert len(first_cycle) == len(set(first_cycle))
    assert len(second_cycle) == len(set(second_cycle))
