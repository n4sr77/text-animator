"""Unit tests: MediaSpec validator against synthetic specs."""

from __future__ import annotations

import unittest
from unittest.mock import patch

from text_animator.social.base import MediaSpec, UploadRequest
from text_animator.social.validator import validate, _aspect_str, _gcd


class TestAspectHelpers(unittest.TestCase):

    def test_gcd(self):
        self.assertEqual(_gcd(1920, 1080), 120)
        self.assertEqual(_gcd(1080, 1920), 120)
        self.assertEqual(_gcd(1080, 1080), 1080)

    def test_aspect_str(self):
        self.assertEqual(_aspect_str(1920, 1080), "16:9")
        self.assertEqual(_aspect_str(1080, 1920), "9:16")
        self.assertEqual(_aspect_str(1080, 1080), "1:1")
        self.assertEqual(_aspect_str(0, 1080), "0:0")


class TestValidatorSyntheticSpec(unittest.TestCase):

    def _request(self, path="/tmp/fake.mp4"):
        return UploadRequest(file_path=path, platform="test", account_id="acct1")

    def _probe(self, **overrides):
        defaults = {
            "duration": 30.0,
            "size_bytes": 50 * 1024 * 1024,
            "width": 1920,
            "height": 1080,
            "fps": 30.0,
            "video_codec": "h264",
            "audio_codec": "aac",
            "container": "mp4",
        }
        defaults.update(overrides)
        return defaults

    def _spec(self, **overrides):
        defaults = dict(
            platform="test",
            max_duration_s=60.0,
            max_size_bytes=100 * 1024 * 1024,
            allowed_codecs=["h264"],
            allowed_containers=["mp4"],
            allowed_aspects=[],
            min_width=0, min_height=0,
            max_width=7680, max_height=4320,
            max_fps=60.0,
        )
        defaults.update(overrides)
        spec = MediaSpec.__new__(MediaSpec)
        for k, v in defaults.items():
            setattr(spec, k, v)
        return spec

    def test_valid_file_no_errors(self):
        with patch("text_animator.social.validator.probe", return_value=self._probe()), \
             patch("pathlib.Path.is_file", return_value=True):
            errors = validate(self._request(), self._spec())
        self.assertEqual(errors, [])

    def test_duration_exceeds_max(self):
        with patch("text_animator.social.validator.probe",
                   return_value=self._probe(duration=120.0)), \
             patch("pathlib.Path.is_file", return_value=True):
            errors = validate(self._request(), self._spec(max_duration_s=60.0))
        self.assertTrue(any("Duration" in e for e in errors))

    def test_size_exceeds_max(self):
        with patch("text_animator.social.validator.probe",
                   return_value=self._probe(size_bytes=200 * 1024 * 1024)), \
             patch("pathlib.Path.is_file", return_value=True):
            errors = validate(self._request(), self._spec(max_size_bytes=100 * 1024 * 1024))
        self.assertTrue(any("size" in e.lower() for e in errors))

    def test_codec_not_allowed(self):
        with patch("text_animator.social.validator.probe",
                   return_value=self._probe(video_codec="vp9")), \
             patch("pathlib.Path.is_file", return_value=True):
            errors = validate(self._request(), self._spec(allowed_codecs=["h264"]))
        self.assertTrue(any("codec" in e.lower() for e in errors))

    def test_aspect_blocked(self):
        # 16:9 file, only 9:16 allowed
        with patch("text_animator.social.validator.probe",
                   return_value=self._probe(width=1920, height=1080)), \
             patch("pathlib.Path.is_file", return_value=True):
            errors = validate(self._request(),
                              self._spec(allowed_aspects=["9:16", "1:1"]))
        self.assertTrue(any("16:9" in e for e in errors))

    def test_min_width_violation(self):
        with patch("text_animator.social.validator.probe",
                   return_value=self._probe(width=240, height=320)), \
             patch("pathlib.Path.is_file", return_value=True):
            errors = validate(self._request(), self._spec(min_width=360))
        self.assertTrue(any("Width" in e for e in errors))

    def test_file_not_found(self):
        errors = validate(self._request("/nonexistent/file.mp4"), self._spec())
        self.assertTrue(any("not found" in e.lower() for e in errors))

    def test_multiple_errors(self):
        with patch("text_animator.social.validator.probe",
                   return_value=self._probe(duration=999.0, size_bytes=999 * 1024 * 1024,
                                             video_codec="hevc")), \
             patch("pathlib.Path.is_file", return_value=True):
            errors = validate(self._request(),
                              self._spec(max_duration_s=60.0,
                                         max_size_bytes=100 * 1024 * 1024,
                                         allowed_codecs=["h264"]))
        self.assertGreaterEqual(len(errors), 3)


if __name__ == "__main__":
    unittest.main()
