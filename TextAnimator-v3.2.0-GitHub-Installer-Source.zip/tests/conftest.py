"""Shared pytest fixtures."""

import sys
import os

# Ensure the project root is on the path so tests can import text_animator
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
