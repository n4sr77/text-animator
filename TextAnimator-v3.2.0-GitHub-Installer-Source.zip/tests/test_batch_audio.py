import csv
import threading
from pathlib import Path

from text_animator.batch import BatchRenderer


class FakeRenderer:
    def __init__(self):
        self._cancel = threading.Event()
        self.calls = []
        self.last_encoder_label = "Test encoder"

    def cancel(self):
        self._cancel.set()

    def render_to_file(self, text, output, **kwargs):
        self.calls.append({"text": text, "output": output, **kwargs})
        Path(output).parent.mkdir(parents=True, exist_ok=True)
        Path(output).write_bytes(b"fake mp4")
        return output


def make_csv(path, rows):
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=["title", "sentence", "audio"])
        writer.writeheader()
        writer.writerows(rows)


def test_csv_audio_override_beats_random_folder_selection(tmp_path):
    fixed = tmp_path / "fixed.mp3"
    fixed.write_bytes(b"audio")
    audio_dir = tmp_path / "audios"
    audio_dir.mkdir()
    random_a = audio_dir / "a.mp3"
    random_b = audio_dir / "b.wav"
    random_a.write_bytes(b"a")
    random_b.write_bytes(b"b")
    csv_path = tmp_path / "batch.csv"
    make_csv(csv_path, [
        {"title": "pinned", "sentence": "Pinned soundtrack", "audio": str(fixed)},
        {"title": "random", "sentence": "Random soundtrack", "audio": ""},
    ])

    batch = BatchRenderer()
    fake = FakeRenderer()
    batch.renderer = fake
    batch.run(str(csv_path), str(tmp_path / "out"), audio_mode="random", audio_folder=str(audio_dir))

    assert fake.calls[0]["audio_path"] == str(fixed)
    assert fake.calls[1]["audio_path"] in {str(random_a.resolve()), str(random_b.resolve())}


def test_batch_selected_track_is_used_when_csv_audio_is_empty(tmp_path):
    fixed = tmp_path / "fallback.mp3"
    fixed.write_bytes(b"audio")
    csv_path = tmp_path / "batch.csv"
    make_csv(csv_path, [
        {"title": "one", "sentence": "First", "audio": ""},
        {"title": "two", "sentence": "Second", "audio": ""},
    ])
    batch = BatchRenderer()
    fake = FakeRenderer()
    batch.renderer = fake
    batch.run(str(csv_path), str(tmp_path / "out"), audio_mode="fixed", audio_path=str(fixed))

    assert [c["audio_path"] for c in fake.calls] == [str(fixed), str(fixed)]


def test_same_csv_row_variants_share_the_selected_track(tmp_path):
    audio_dir = tmp_path / "audios"
    audio_dir.mkdir()
    (audio_dir / "one.mp3").write_bytes(b"1")
    (audio_dir / "two.mp3").write_bytes(b"2")
    csv_path = tmp_path / "batch.csv"
    make_csv(csv_path, [{"title": "variants", "sentence": "Variants", "audio": ""}])

    batch = BatchRenderer()
    fake = FakeRenderer()
    batch.renderer = fake
    batch.run(str(csv_path), str(tmp_path / "out"), audio_mode="random",
              audio_folder=str(audio_dir), variants_per_row=3)

    assert len({call["audio_path"] for call in fake.calls}) == 1


def test_fixed_batch_track_overrides_random_folder_selection(tmp_path):
    fixed = tmp_path / "selected.mp3"
    fixed.write_bytes(b"selected")
    audio_dir = tmp_path / "audios"
    audio_dir.mkdir()
    (audio_dir / "random.mp3").write_bytes(b"random")
    csv_path = tmp_path / "batch.csv"
    make_csv(csv_path, [{"title": "fixed", "sentence": "Use selected soundtrack", "audio": ""}])

    batch = BatchRenderer()
    fake = FakeRenderer()
    batch.renderer = fake
    batch.run(str(csv_path), str(tmp_path / "out"), audio_mode="random",
              audio_folder=str(audio_dir), fixed_audio_path=str(fixed))

    assert fake.calls[0]["audio_path"] == str(fixed)


def test_csv_relative_audio_path_is_resolved_from_csv_folder(tmp_path):
    assets = tmp_path / "assets"
    assets.mkdir()
    track = assets / "voiceover.mp3"
    track.write_bytes(b"track")
    csv_path = tmp_path / "batch.csv"
    make_csv(csv_path, [{"title": "relative", "sentence": "Relative path", "audio": "assets/voiceover.mp3"}])

    batch = BatchRenderer()
    fake = FakeRenderer()
    batch.renderer = fake
    batch.run(str(csv_path), str(tmp_path / "out"), audio_mode="random",
              audio_folder=str(assets))

    assert fake.calls[0]["audio_path"] == str(track.resolve())


def test_fixed_batch_track_does_not_require_random_folder(tmp_path):
    fixed = tmp_path / "selected.mp3"
    fixed.write_bytes(b"selected")
    csv_path = tmp_path / "batch.csv"
    make_csv(csv_path, [{"title": "fixed", "sentence": "Use selected soundtrack", "audio": ""}])

    batch = BatchRenderer()
    fake = FakeRenderer()
    batch.renderer = fake
    batch.run(str(csv_path), str(tmp_path / "out"), audio_mode="random",
              audio_folder=str(tmp_path / "missing-folder"), fixed_audio_path=str(fixed))

    assert fake.calls[0]["audio_path"] == str(fixed)


def test_explicit_csv_rows_do_not_require_random_folder(tmp_path):
    track = tmp_path / "row.mp3"
    track.write_bytes(b"track")
    csv_path = tmp_path / "batch.csv"
    make_csv(csv_path, [{"title": "csv", "sentence": "CSV selected", "audio": str(track)}])

    batch = BatchRenderer()
    fake = FakeRenderer()
    batch.renderer = fake
    batch.run(str(csv_path), str(tmp_path / "out"), audio_mode="random",
              audio_folder=str(tmp_path / "missing-folder"))

    assert fake.calls[0]["audio_path"] == str(track)


def test_none_audio_mode_ignores_a_stale_fixed_track(tmp_path):
    fixed = tmp_path / "stale.mp3"
    fixed.write_bytes(b"audio")
    csv_path = tmp_path / "batch.csv"
    make_csv(csv_path, [{"title": "silent", "sentence": "No soundtrack", "audio": ""}])

    batch = BatchRenderer()
    fake = FakeRenderer()
    batch.renderer = fake
    batch.run(str(csv_path), str(tmp_path / "out"), audio_mode="none",
              fixed_audio_path=str(fixed))

    assert fake.calls[0]["audio_path"] is None
