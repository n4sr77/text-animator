#!/usr/bin/env python3
"""TextAnimator application launcher.

Run ``python main.py`` from the project directory to open the desktop app.
Use ``--version`` or ``--help`` for non-GUI checks.
"""
from __future__ import annotations

import argparse

from text_animator import __version__


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="TextAnimator",
        description="Create animated text videos and batch-process image, video and audio files.",
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"TextAnimator {__version__}",
    )
    parser.parse_args(argv)

    from text_animator.gui import TextAnimatorApp

    app = TextAnimatorApp()
    app.mainloop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
